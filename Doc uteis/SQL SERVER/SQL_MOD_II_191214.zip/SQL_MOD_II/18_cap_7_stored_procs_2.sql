CREATE DATABASE TESTE_PROCS
GO
USE TESTE_PROCS;
GO
--===================================================
-- LOOPS
-- 1. Gera os n�meros inteiros de 0 at� N
CREATE PROCEDURE STP_INTEIROS @LIMITE INT = 100
AS BEGIN
-- vari�vel de resultado
DECLARE @LISTA TABLE (NUMERO INT);
-- contador
DECLARE @CONT INT = 0;
-- enquanto o contador for menor ou igual ao limite
WHILE @CONT <= @LIMITE
    BEGIN
	-- inserir o contador na lista (vari�vel tabular)
	INSERT INTO @LISTA VALUES  (@CONT);
	-- incrementar o contador
	-- SET @CONT = @CONT + 1;
	-- OU
	SET @CONT += 1;
	END -- WHILE @CONT
-- retornar com a lista gerada
SELECT * FROM @LISTA;
END
GO
-- testando
EXEC STP_INTEIROS
EXEC STP_INTEIROS 10
GO
------------------------------------------------------
-- 2. Crie a procedure STP_INTEIROS_DESC
-- Idem anterior mas deve mostrar os n�meros em ordem decrescente
CREATE PROCEDURE STP_INTEIROS_DESC @LIMITE INT = 100
AS BEGIN
-- vari�vel de resultado
DECLARE @LISTA TABLE (NUMERO INT);
-- contador
DECLARE @CONT INT = @LIMITE;
-- enquanto o contador for maior ou igual a 0
WHILE @CONT >= 0
    BEGIN
	-- inserir o contador na lista (vari�vel tabular)
	INSERT INTO @LISTA VALUES  (@CONT);
	-- DEcrementar o contador
	-- SET @CONT = @CONT - 1;
	-- OU
	SET @CONT -= 1;
	END -- WHILE @CONT
-- retornar com a lista gerada
SELECT * FROM @LISTA;
END
GO


-- testando
EXEC STP_INTEIROS_DESC
GO
-----------------------------------------------------
-- 3. STP_PARES: Gera os n�meros pares de 0 at� N
CREATE PROCEDURE STP_PARES @LIMITE INT = 100
AS BEGIN
-- vari�vel de resultado
DECLARE @LISTA TABLE (NUMERO INT);
-- contador
DECLARE @CONT INT = 0;
-- enquanto o contador for menor ou igual ao limite
WHILE @CONT <= @LIMITE
    BEGIN
	-- inserir o contador na lista (vari�vel tabular)
	INSERT INTO @LISTA VALUES  (@CONT);
	-- incrementar o contador
	-- SET @CONT = @CONT + 2;
	-- OU
	SET @CONT += 2;
	END -- WHILE @CONT
-- retornar com a lista gerada
SELECT * FROM @LISTA;
END
GO



-- testando
EXEC STP_PARES 10
GO
-----------------------------------------------------
-- 4. STP_IMPARES: Gera os n�meros �mpares entre 0 e N
CREATE PROCEDURE STP_IMPARES @LIMITE INT = 100
AS BEGIN
-- vari�vel de resultado
DECLARE @LISTA TABLE (NUMERO INT);
-- contador
DECLARE @CONT INT = 1;
-- enquanto o contador for menor ou igual ao limite
WHILE @CONT <= @LIMITE
    BEGIN
	-- inserir o contador na lista (vari�vel tabular)
	INSERT INTO @LISTA VALUES  (@CONT);
	-- incrementar o contador
	-- SET @CONT = @CONT + 2;
	-- OU
	SET @CONT += 2;
	END -- WHILE @CONT
-- retornar com a lista gerada
SELECT * FROM @LISTA;
END
GO



-- testando
EXEC STP_IMPARES
GO
-- 4.1. extra
CREATE PROCEDURE STP_IMPARES_2 @INICIO INT = 1, @LIMITE INT = 100 -- valor default
AS BEGIN

-- vari�vel de resultado
DECLARE @LISTA TABLE (NUMERO INT);
-- contador
DECLARE @CONT INT = @INICIO;

-- operador % calcula o resto de uma divis�o inteira
-- se o resto da divis�o for 0, o n�mero � par
IF @CONT % 2 = 0 SET @CONT += 1;


-- enquanto o contador for menor ou igual ao limite
WHILE @CONT <= @LIMITE
    BEGIN
	-- inserir o contador na lista (vari�vel tabular)
	INSERT INTO @LISTA VALUES  (@CONT);
	-- incrementar o contador
	-- SET @CONT = @CONT + 2;
	-- OU
	SET @CONT += 2;
	END -- WHILE @CONT
-- retornar com a lista gerada
SELECT * FROM @LISTA;

END
GO
---------------------------
--- TESTANDO
EXEC STP_IMPARES_2 1, 30
EXEC STP_IMPARES_2 50, 100

EXEC STP_IMPARES_2

EXEC STP_IMPARES_2 50

-- passagem de par�metros declarativa, colocando o nome das vari�veis
EXEC STP_IMPARES_2 @LIMITE = 50, @INICIO = 10
EXEC STP_IMPARES_2 @LIMITE = 50

GO


----------------------------------------------------
-- 5. Calcula a soma dos n�meros de 1 at� N
-- Exemplo: Se N = 5 deve calcular 1+2+3+4+5 = 15
CREATE PROCEDURE STP_SOMA @LIMITE INT
AS BEGIN
DECLARE @CONT INT = 1, @SOMA INT = 0;

WHILE @CONT <= @LIMITE
    BEGIN
	SET @SOMA += @CONT;
	SET @CONT += 1;
	END -- WHILE

SELECT @SOMA AS SOMA;
END
GO
-- testando
EXEC STP_SOMA 5
GO
----------------------------------------------------
-- 6. Calcula o FATORIAL de N
-- Exemplo: Se N = 5 deve calcular 1*2*3*4*5 = 120
ALTER PROCEDURE STP_FAT @LIMITE INT
AS BEGIN
DECLARE @CONT INT = 1, @FAT BIGINT = 1;

WHILE @CONT <= @LIMITE
    BEGIN
	SET @FAT *= @CONT;
	SET @CONT += 1;
	END -- WHILE

SELECT @FAT AS FAT;
END
GO

-- testando
EXEC STP_FAT 20 -- limite para BIGINT
GO
------------------------------------------------------
-- 7. Criar procedure STP_TABUADAS que imprima as tabuadas do 1 ao 10
-- Precisa utilizar Loops encadeados. O resultado esperado �:
/*
TABUADA DO 1
1 x 1 = 1
1 x 2 = 2
1 x 3 = 3
1 x 4 = 4
1 x 5 = 5
1 x 6 = 6
1 x 7 = 7
1 x 8 = 8
1 x 9 = 9
1 x 10 = 10
----------------------
TABUADA DO 2
2 x 1 = 2
2 x 2 = 4
2 x 3 = 6
2 x 4 = 8
2 x 5 = 10
...
...
*/
CREATE PROCEDURE STP_TABUADAS
AS BEGIN
-- armazena a lista resultante (tabuadas do 1 ao 10)
DECLARE @LISTA TABLE ( LINHA VARCHAR(30) );
-- contador de tabuadas
DECLARE @T INT = 1;
-- loop para gerar cada tabuada
WHILE @T <= 10
    BEGIN
	-- inserir o t�tulo da tabuada
	INSERT INTO @LISTA VALUES ('TABUADA DO ' + 
	                              CAST(@T AS VARCHAR(2)));

	-- declarar contador interno de cada tabuada
	DECLARE @N INT = 1;
	
	-- loop interno de cada tabuada
	WHILE @N <= 10
	    BEGIN

		-- inserir a linha de cada tabuada
		INSERT INTO @LISTA VALUES
		                   (
		   --CAST(@T AS CHAR(2)) + ' x ' + CAST(@N AS CHAR(2)) + ' = ' +
		   --CAST( @T * @N AS CHAR(3))   
		   --SQL 2012
		           CONCAT( @T, ' x ', @N, ' = ', @T * @N )
						   );

		-- incrementar o contador
		SET @N += 1;
		END -- WHILE @N
	-- incrementar o contador
	SET @T += 1;
	END -- WHILE @T
-- retornar com a lista gerada
SELECT * FROM @LISTA;
END
GO

--- TESTANDO
EXEC STP_TABUADAS
GO

-- 7.1. Altere a procedure STP_TABUADAS de modo que possamos passar
--      os n�meros da tabuada inicial at� a tabuada final, assumindo
--      de 1 a 10 como default
ALTER PROCEDURE STP_TABUADAS @T_INIC INT = 1, @T_FIN INT = 10
AS BEGIN
-- armazena a lista resultante (tabuadas do 1 ao 10)
DECLARE @LISTA TABLE ( LINHA VARCHAR(30) );
-- contador de tabuadas
DECLARE @T INT = @T_INIC;
-- loop para gerar cada tabuada
WHILE @T <= @T_FIN
    BEGIN
	-- inserir o t�tulo da tabuada
	INSERT INTO @LISTA VALUES ('TABUADA DO ' + 
	                              CAST(@T AS VARCHAR(2)));

	-- declarar contador interno de cada tabuada
	DECLARE @N INT = 1;
	
	-- loop interno de cada tabuada
	WHILE @N <= 10
	    BEGIN

		-- inserir a linha de cada tabuada
		INSERT INTO @LISTA VALUES
		                   (
		   --CAST(@T AS CHAR(2)) + ' x ' + CAST(@N AS CHAR(2)) + ' = ' +
		   --CAST( @T * @N AS CHAR(3))   
		   --SQL 2012
		           CONCAT( @T, ' x ', @N, ' = ', @T * @N )
						   );

		-- incrementar o contador
		SET @N += 1;
		END -- WHILE @N
	-- incrementar o contador
	SET @T += 1;
	END -- WHILE @T
-- retornar com a lista gerada
SELECT * FROM @LISTA;
END
GO

-- testando - mostra as tabuadas do 2 ao 8
EXEC STP_TABUADAS 2, 8
-- mostra todas as tabuadas
EXEC STP_TABUADAS

------------------------------------------------------------------ megasena
DECLARE @N INT = 60 * RAND() + 1
PRINT @N

PRINT RAND() -- 0..... 0.999999 x 60
             -- 0.....59.999999 se colocar em var tipo INT
			 -- 0.....59 + 1
GO
-- 8. Criar procedure STP_MEGASENA que receba como par�metro
-- a quantidade de cart�es que queremos jogar
CREATE PROCEDURE STP_MEGASENA @TOT_CARTOES INT = 10
AS BEGIN
-- lista resultante
DECLARE @CARTOES TABLE (NUM_CARTAO INT, NUM_DEZENA INT );
-- contador de cart�es
DECLARE @CONT_CAR INT = 1;
-- loop para gerar cada cart�o
WHILE @CONT_CAR <= @TOT_CARTOES
    BEGIN

	-- contador de dezenas dentro de cada cart�o
	DECLARE @CONT_DEZ INT = 1;
	-- loop para gerar as 6 dezenas de 1 cart�o
	WHILE @CONT_DEZ <= 6
	   BEGIN

	   -- gerar dezena no intervalo de 1 a 60
	   DECLARE @SORTEIO INT = 1 + 60 * RAND();

	   IF EXISTS(SELECT * FROM @CARTOES
	            WHERE NUM_CARTAO = @CONT_CAR 
				      AND NUM_DEZENA = @SORTEIO)
		  CONTINUE; -- volta para o topo do loop


	   -- inserir na tabela de cart�es
	   INSERT INTO @CARTOES VALUES (@CONT_CAR, @SORTEIO);

	   -- incrementar o contador
	   SET @CONT_DEZ += 1;
	   END -- WHILE @CONT_DEZ

	-- incrementar o contador
	SET @CONT_CAR += 1;
	END -- WHILE @CONT_CAR
-- retornar com a lista gerada
SELECT * FROM @CARTOES ORDER BY NUM_CARTAO, NUM_DEZENA;
END
GO
--
EXEC STP_MEGASENA 10
go
----







