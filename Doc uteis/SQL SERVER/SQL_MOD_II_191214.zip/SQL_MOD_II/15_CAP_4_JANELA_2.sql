--=====================================================
-- CONCORR�NCIA - JANELA 2
--=====================================================
USE PEDIDOS

--SET TRANSACTION ISOLATION LEVEL READ COMMITTED

--SELECT @@TRANCOUNT

--DBCC USEROPTIONS

--por sess�o. Em outra sess�o permanece o padr�o, ou seja, esperar at� que desbloqueie
SET LOCK_TIMEOUT 5000 -- 5 segundos

SELECT * FROM VIE_BLOQUEIOS

-- EXEMPLO 1 -----------------------------------------------------------------
-- Vai esgotar o temp de TIMEOUT porque existem registros bloqueados
SELECT * FROM PRODUTOS_TMP
ORDER BY COD_TIPO;
--
-- A estrutura da tabela tamb�m est� bloqueada
ALTER TABLE PRODUTOS_TMP ADD TESTE INT;

-- Consulta os registros n�o bloqueados
SELECT * FROM PRODUTOS_TMP WITH (READPAST)
ORDER BY COD_TIPO;

-- Consulta inclusive os registros bloqueados
-- "Dirty-read" (leitura suja)
SELECT * FROM PRODUTOS_TMP WITH (NOLOCK)
ORDER BY COD_TIPO;
-- voltar para a janela 1

-- EXEMPLO 2 -----------------------------------------------------------------
SELECT * FROM PRODUTOS ORDER BY COD_TIPO
/* N�o consegue ler porque algumas linhas da tabela est�o bloqueadas
   em outro processo de transa��o. */

-- L� os registros n�o bloqueados. Veja que n�o aparece nenhum registro com 
-- COD_TIPO = 1 
SELECT * FROM PRODUTOS WITH (READPAST)
ORDER BY COD_TIPO 

-- "Dirty-read" (leitura suja)
-- L� os registros ainda n�o "comitados" por outra transa��o
SELECT * FROM PRODUTOS WITH (NOLOCK)
ORDER BY COD_TIPO 

--
BEGIN TRAN

UPDATE PRODUTOS  SET PRECO_VENDA = 10
WHERE COD_TIPO = 5

UPDATE PRODUTOS WITH (READPAST) SET PRECO_VENDA = 10
WHERE COD_TIPO = 5

UPDATE PRODUTOS WITH (READPAST) SET PRECO_VENDA = 10
WHERE COD_TIPO = 1

ROLLBACK

--- Tendando novamente
SELECT * FROM PRODUTOS ORDER BY COD_TIPO
--- Consultar os bloqueios 
SELECT * FROM VIE_BLOQUEIOS

-- (*) Pode n�o ser o mesmo n�mero                         
-- O processo n�mero 54 (*) est� bloqueando a tabela produtos
KILL 53 -- "Mata" o processo 54 (*)
-- Consultar novamente
SELECT * FROM PRODUTOS ORDER BY COD_TIPO

-- voltar para a janela 1


-- EXEMPLO 3 -------------------------------------------------------------------
SELECT * FROM PEDIDOS  WITH (READPAST) 
-- Os registros at� 999 est�o bloquedos

SELECT * FROM PEDIDOS  WITH  (NOLOCK)
ORDER BY NUM_PEDIDO
-- voltar para a janela 1

-- EXEMPLO 4 -------------------------------------------------------------------
SELECT * FROM PEDIDOS  WITH (READPAST) 
WHERE NUM_PEDIDO >= 1079
--

SELECT * FROM PEDIDOS  WITH (READPAST) 
WHERE NUM_PEDIDO >= 1000
ORDER BY NUM_PEDIDO DESC
-- Observe que n�o s� os registros at� 1000 est�o bloqueados
-- alguns registros acima de 1000 tamb�m est�o porque fazem 
-- parte da mesma p�gina

SELECT * FROM PEDIDOS  WITH  (NOLOCK)
ORDER BY NUM_PEDIDO

-- EXEMPLO 5 -------------------------------------------------------------------
SELECT * FROM PEDIDOS  WITH (READPAST) 

SELECT * FROM PEDIDOS  WITH  (NOLOCK)
ORDER BY NUM_PEDIDO

-- EXEMPLO 6 -------------------------------------------------------------------
BEGIN TRAN

UPDATE PRODUTOS SET PRECO_VENDA = 10
WHERE COD_TIPO = 1
-- Agora volte para a janela 1 e consulte a tabela PRODUTOS

ROLLBACK


