--================================================
-- Cap. 6 - VIEWS - P�g 200
-- Uma view serve para armazenar uma instru��o SELECT.
-- Para que utilizar uma VIEW?
--    .Centralizar a instru��o SELECT para que n�o
--     seja necess�rio digit�-la repetidas vezes.
--    .Proteger informa��es (colunas e/ou linhas)
--    .Simplifica��o de c�digo no caso de SELECTs
--     muito complexos.
--------------------------------------------------- 

USE PEDIDOS
GO
-- 1.
CREATE VIEW VIE_EMP1 AS
SELECT CODFUN, NOME, DATA_ADMISSAO, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
GO
-- Testando a VIEW
SELECT * FROM VIE_EMP1
--
SELECT CODFUN, NOME FROM VIE_EMP1
GO

-- N�O PODE ...
ALTER VIEW VIE_EMP1 AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
ORDER BY NOME
GO

-- MAS PODE !!!
ALTER VIEW VIE_EMP1 AS
SELECT TOP 9999 CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
ORDER BY NOME
GO

SELECT * FROM SYSCOMMENTS -- COLUNA TEXT POSSUI O COMANDO
WHERE ID = OBJECT_ID('VIE_EMP1')
GO

EXEC sp_helptext VIE_EMP1
GO
-- Procure esta view no Object Explorer e 
-- d� om click direito sobre ela


-- 2.
CREATE VIEW VIE_EMP2 WITH ENCRYPTION
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
GO

EXEC sp_helptext VIE_EMP2

SELECT * FROM SYSCOMMENTS
WHERE ID = OBJECT_ID('VIE_EMP2')
GO

-- Procure esta view no Object Explorer e 
-- d� om click direito sobre ela


-- VOLTA AO NORMAL
ALTER VIEW VIE_EMP2 
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
GO

-- 3.
CREATE VIEW VIE_EMP3 --WITH ENCRYPTION
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
WHERE COD_DEPTO = 2
GO
--
SELECT * FROM VIE_EMP3
--
INSERT INTO VIE_EMP3( NOME, DATA_ADMISSAO,COD_DEPTO, COD_CARGO, SALARIO)
VALUES ('TESTE INCLUS�O', GETDATE(), 3, 1, 1000)
-- 
SELECT * FROM EMPREGADOS
--
SELECT * FROM VIE_EMP3
GO
--
ALTER VIEW VIE_EMP3 WITH ENCRYPTION
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
WHERE COD_DEPTO = 2
-- impede a inclus�o de dados que a view n�o possa mostrar
WITH CHECK OPTION
GO

SELECT * FROM VIE_EMP3
ORDER BY NOME
go
-------------------------------------------------------------
CREATE VIEW VIE_EMP4 AS
SELECT E.CODFUN, E.NOME, E.DATA_ADMISSAO, 
       E.COD_DEPTO, E.COD_CARGO, E.SALARIO, D.DEPTO
FROM EMPREGADOS E 
     JOIN TABELADEP D ON E.COD_DEPTO = D.COD_DEPTO
GO     
---- FUNCIONA (somente campos de EMPREGADOS)
INSERT INTO VIE_EMP4
( NOME, DATA_ADMISSAO, COD_DEPTO, COD_CARGO, SALARIO)
VALUES ('TESTE INCLUS�O', GETDATE(), 1, 1, 1000)
-- 
SELECT * FROM EMPREGADOS
GO

---- FUNCIONA (somente campos de TABELADEP)
INSERT INTO VIE_EMP4 (DEPTO) VALUES ('TESTE...')
-- TESTE
SELECT * FROM TABELADEP
GO

---- N�O FUNCIONA. INSERT EM MULTIPLAS TABELAS
INSERT INTO VIE_EMP4
( NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO, DEPTO)
VALUES
('TESTE INCLUS�O', GETDATE(), 1, 1, 1000, 'TESTE1')
GO

--=============================================
-- Cria depend�ncia entre a view e as tabela que ela utiliza
alter VIEW VIE_EMP5 WITH SCHEMABINDING
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM DBO.EMPREGADOS
WHERE COD_DEPTO = 2
WITH CHECK OPTION
GO
--
-- renomear a tabela EMPREGADOS
EXEC sp_rename 'EMPREGADOS', 'FUNCIONARIOS';
-- renomear o campo CODFUN
EXEC sp_rename @OBJNAME = 'EMPREGADOS.CODFUN', 
               @NEWNAME = 'COD_FUNC', @objtype  = 'COLUMN';

GO

select * from empregados order by cod_depto, nome
go

CREATE VIEW VIE_EMP6
WITH SCHEMABINDING
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO,
       SALARIO + PREMIO_MENSAL AS RENDA_MES
FROM DBO.EMPREGADOS
GO

SELECT * FROM VIE_EMP6
ORDER BY RENDA_MES

-- Este tipop de view pode ser indexada

-- Primeiro temos que criar um �ndice do tipo chave prim�ria
CREATE UNIQUE CLUSTERED INDEX IX_VIE_EMP6_CODFUN
ON VIE_EMP6(CODFUN)
-- Para depois criarmos os outros
CREATE INDEX IX_VIE_EMP6_RENDA_MES
ON VIE_EMP6(RENDA_MES)

--==================== MAIS SOBRE �NDICES ===========================
SELECT CODFUN, NOME, SALARIO
FROM EMPREGADOS
ORDER BY NOME

-- inclui a coluna SALARIO no pr�prio �ndice do NOME
CREATE INDEX IX_EMPREGADOS_NOME_I_SALARIO 
ON EMPREGADOS(NOME) INCLUDE (SALARIO)

SELECT CODFUN, NOME, SALARIO
FROM EMPREGADOS
ORDER BY NOME

-- Observe o plano de execu��o
SELECT P.NUM_PEDIDO, P.DATA_EMISSAO, P.VLR_TOTAL,
       V.NOME AS VENDEDOR
FROM PEDIDOS P 
     JOIN VENDEDORES V ON P.CODVEN = V.CODVEN
WHERE V.NOME LIKE '%MARCELO%'

-- Observe o plano de execu��o
SELECT I.*, PR.DESCRICAO, PE.DATA_EMISSAO,
       C.NOME AS CLIENTE, V.NOME AS VENDEDOR 
FROM ITENSPEDIDO I 
     JOIN PRODUTOS PR ON I.ID_PRODUTO = PR.ID_PRODUTO
	 JOIN PEDIDOS PE ON I.NUM_PEDIDO = PE.NUM_PEDIDO
	 JOIN VENDEDORES V ON PE.CODVEN = PE.CODVEN
	 JOIN CLIENTES C ON PE.CODCLI = C.CODCLI
WHERE PE.DATA_EMISSAO BETWEEN '2007.1.1' AND '2007.1.31'
      AND I.DESCONTO > 7

-- Observe o plano de execu��o
SELECT * FROM CLIENTES
WHERE CODCLI NOT IN
(
SELECT CODCLI FROM PEDIDOS
WHERE DATA_EMISSAO BETWEEN '2007.1.1' AND '2007.1.31'
)

--==============================================================
select * from syscolumns
-- name   : nome da coluna
-- id     : id da tabela que � dona da coluna
-- colid  : id ca coluna dentro da tabela. Come�a do 1 para cada tabela

select * from sys.indexes
-- object_id: id da tabela a qual o �ndice pertence (join com sysobjects)
-- name     : nome do �ndice
-- index_id : id do �ndice dentro desta tabela, come�a sempre do 1 para cada tabela 

select * from sys.index_columns
-- object_id: id da tabela a qual o �ndice pertence (join com sysobjects e com sys.indexes)
-- index_id : id do �ndice dentro desta tabela (join com sys.indexes)
-- column_id: id da coluna da tabela usada no �ndice (join com colid de syscolumns)

select so.name TABELA, si.name INDICE, sc.name CAMPOS
from sysobjects so 
     join sys.indexes si on so.id = si.object_id
     join sys.index_columns ic on ic.object_id = si.object_id and
				                                ic.index_id = si.index_id
	 join syscolumns sc on ic.object_id = sc.id and ic.column_id = sc.colid
where so.xtype in ('U' , 'V')
      and si.is_primary_key = 1 -- s� PK
	  and so.name = 'ITENSPEDIDO' -- qual tabela















     