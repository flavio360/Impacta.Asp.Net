-- PIVOT - P�G 59
USE PEDIDOS
-- Totalizar as vendas do vendedor por m�s forma tradicional
SELECT CODVEN, MONTH(DATA_EMISSAO) AS MES, 
      SUM(VLR_TOTAL) AS TOT_VENDIDO
FROM PEDIDOS
WHERE YEAR(DATA_EMISSAO) = 2006
GROUP BY CODVEN, MONTH(DATA_EMISSAO)
ORDER BY CODVEN, MES

-- "PIVOTANDO"
-- Ex. 1a:
/*
CODVEN Jan                 Fev               Mar               Abr              Mai                Jun                                     Jul                                     Ago                                     Set                                     Out                                     Nov                                     Dez
------ ------------------- ----------------- ----------------- ---------------- ------------------ --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- ---------------------------------------
1      27277.69            5602.95           7804.10           31677.07         2071.00            60138.60                                68065.71                                69616.42                                82577.92                                91679.38                                59630.11                                71136.14
2      28763.98            24608.88          4050.04           67258.92         12721.74           51360.99                                55870.67                                60765.34                                76958.05                                94153.17                                56309.05                                71050.53
3      139812.07           43914.90          40072.51          90164.08         95070.46           50638.78                                50771.24                                73199.02                                82207.58                                91418.18                                67775.07                                81446.21
4      NULL                15.39             706.52            NULL             NULL               55776.76                                74320.54                                85432.22                                70640.89                                90206.81                                87055.15                                90447.16
5      NULL                NULL              NULL              2908.03          NULL               52691.86                                55303.11                                66772.15                                87451.77                                88946.53                                85663.65                                97389.11

*/
--[1] Jan, [2] Fev, [3] Mar, [4] Abr, [5] Mai, [6] Jun, [7] Jul, [8] Ago, [9] 'Set', [10] 'Out', [11] Nov, [12] Dez
SELECT CODVEN, [1] Jan, [2] Fev, [3] Mar, [4] Abr, [5] Mai, [6] Jun, 
               [7] Jul, [8] Ago, [9] 'Set', [10] 'Out', [11] Nov, [12] Dez
FROM
	(SELECT CODVEN, MONTH(DATA_EMISSAO) AS MES, VLR_TOTAL
	 FROM PEDIDOS
	 WHERE YEAR(DATA_EMISSAO) = 2006) X
PIVOT(SUM(VLR_TOTAL) FOR MES IN ([1], [2], [3], [4], [5], [6], 
           [7], [8], [9], [10], [11], [12] )) Y

-- Ex. 1b: Idem anterior mostrando o nome do vendedor ---------------
SELECT CODVEN, NOME, [1] Jan, [2] Fev, [3] Mar, [4] Abr, [5] Mai, [6] Jun, 
               [7] Jul, [8] Ago, [9] 'Set', [10] 'Out', [11] Nov, [12] Dez
FROM
	(SELECT P.CODVEN, V.NOME, MONTH(P.DATA_EMISSAO) AS MES, P.VLR_TOTAL
	 FROM PEDIDOS P JOIN VENDEDORES V ON P.CODVEN = V.CODVEN
	 WHERE YEAR(P.DATA_EMISSAO) = 2006) X
PIVOT(SUM(VLR_TOTAL) FOR MES IN ([1], [2], [3], [4], [5], [6], 
           [7], [8], [9], [10], [11], [12] )) Y

-- 1c: Total que cada vendedor vendeu por ano (de 2005 a 2012)
-- [2005],[2006],[2007],[2008],[2009],[2010],[2011],[2012]
SELECT CODVEN, NOME, [2005],[2006],[2007],[2008],[2009],[2010],[2011],[2012]
FROM
	(SELECT P.CODVEN, V.NOME, YEAR(P.DATA_EMISSAO) AS ANO, P.VLR_TOTAL
	 FROM PEDIDOS P JOIN VENDEDORES V ON P.CODVEN = V.CODVEN
	 WHERE YEAR(P.DATA_EMISSAO) BETWEEN 2005 AND 2012) X
PIVOT(SUM(VLR_TOTAL) FOR ANO IN ([2005],[2006],[2007],[2008],
                                 [2009],[2010],[2011],[2012] )) Y
    
-- Ex. 2: Totalizar compras do cliente por m�s (SOMENTE 2006)
/*
CODCLI      NOME                                               MES1                                    MES2                                    MES3                                    MES4                                    MES5                                    MES6                                    MES7                                    MES8                                    MES9                                    MES10                                   MES11                                   MES12
----------- -------------------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- ---------------------------------------
3           AUGUSTO'S FOLHINHAS LTDA                           NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    3406.64                                 NULL                                    48.44                                   NULL
4           ASSIS BRINDES COMERCIO INDUSTRIA LTDA              0.00                                    NULL                                    NULL                                    399.00                                  13.30                                   NULL                                    2615.02                                 NULL                                    892.34                                  NULL                                    2380.24                                 1789.41
5           AVEL APOLIMARIO VEICULOS S.A                       NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    5601.63                                 1609.05                                 1339.54                                 NULL                                    NULL                                    5686.07
6           ANTONIO M.DE SOUZA                                 NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    1319.75                                 NULL                                    NULL                                    NULL                                    NULL                                    2525.97
*/
-- 546 LINHAS
SELECT CODCLI, NOME, [1] Jan, [2] Fev, [3] Mar, [4] Abr, [5] Mai, [6] Jun, 
               [7] Jul, [8] Ago, [9] 'Set', [10] 'Out', [11] Nov, [12] Dez
FROM
	(SELECT P.CODCLI, C.NOME, MONTH(P.DATA_EMISSAO) AS MES, P.VLR_TOTAL
	 FROM PEDIDOS P JOIN CLIENTES C ON P.CODCLI = C.CODCLI
	 WHERE YEAR(P.DATA_EMISSAO) = 2006) X
PIVOT(SUM(VLR_TOTAL) FOR MES IN ([1], [2], [3], [4], [5], [6], 
           [7], [8], [9], [10], [11], [12] )) Y


-- Ex. 3: Quanto cada cliente comprou por ano (de 2005 a 2012)
/*
CODCLI      CLIENTE                                            2005                                    2006                                    2007                                    2008
----------- -------------------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- ---------------------------------------
438         (NINO) ANTONIO ROSA FILHO                          NULL                                    2624.95                                 2043.71                                 NULL
372         3R (ARISTEU,ADALTON)                               152.47                                  7234.74                                 13170.89                                NULL
15          A. LUZ DE ALMEIDA                                  NULL                                    1035.28                                 7111.59                                 NULL
*/
-- 561 LINHAS
SELECT CODCLI, NOME, [2005],[2006],[2007],[2008],[2009],[2010],[2011],[2012]
FROM
	(SELECT P.CODCLI, C.NOME, YEAR(P.DATA_EMISSAO) AS ANO, P.VLR_TOTAL
	 FROM PEDIDOS P JOIN CLIENTES C ON P.CODCLI = C.CODCLI
	 WHERE YEAR(P.DATA_EMISSAO) BETWEEN 2005 AND 2012) X
PIVOT(SUM(VLR_TOTAL) FOR ANO IN ([2005],[2006],[2007],[2008],
                                 [2009],[2010],[2011],[2012] )) Y



-- Ex. 4: Totalizar valor vendido por m�s por cada produto (2006)
/*
ID_PRODUTO  DESCRICAO                                Jan                    Fev                    Mar                    Abr                    Mai                    Jun                    Jul                    Ago                    Set                    Out                    Nov                    Dez
----------- ---------------------------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ---------------------- ----------------------
1           ABRIDOR SACA-ROLHA TESTE ADO             3,99                   NULL                   2,85                   1,425                  5,7                    81,69                  205,5285               153,0228               167,3271               309,429                198,7143               228,7452
2           PORTA-LAPIS COM PEZINHO                  2420,6095              2278,67                830,6325               1683,5425              862,4575               4721,5168              2503,1133              4779,9877              3494,9277              4475,6536              4005,6017              4130,7443
3           REGUA DE 20 CM                           3826,41                187,53                 1151,115               1292,76                2228,415               2002,9044              2481,7254              2912,9352              3516,7524              2144,9316              1381,7034              1356,2262
4           PENTE PEQUENO                            506,73                 159,6                  1715,7                 957,6                  1795,5                 2546,6784              5628,1764              4200,7644              5170,6704              6992,4036              2735,04                8001,5796
*/

SELECT ID_PRODUTO, DESCRICAO, [1] Jan, [2] Fev, [3] Mar, [4] Abr, 
                     [5] Mai, [6] Jun, [7] Jul, [8] Ago,  
                     [9] 'Set', [10] 'Out', [11] Nov, [12] Dez
FROM (SELECT I.ID_PRODUTO, PR.DESCRICAO, MONTH(PE.DATA_EMISSAO) AS MES,
             I.QUANTIDADE * I.PR_UNITARIO AS VALOR
             FROM ITENSPEDIDO I 
                  JOIN PEDIDOS PE ON I.NUM_PEDIDO = PE.NUM_PEDIDO
                  JOIN PRODUTOS PR ON I.ID_PRODUTO = PR.ID_PRODUTO
             WHERE YEAR(PE.DATA_EMISSAO) = 2006) AS P
      PIVOT( SUM(VALOR) FOR MES IN ([1],[2],[3],[4],[5],[6],
                     [7],[8],[9],[10],[11],[12])) AS PVT             
ORDER BY 1
-- Ex. 5: Idem anterior, mas totalizando por ANO (de 2005 a 2012)
/*
ID_PRODUTO  DESCRICAO                                2005                   2006                   2007                   2008
----------- ---------------------------------------- ---------------------- ---------------------- ---------------------- ----------------------
1           ABRIDOR SACA-ROLHA TESTE ADO             NULL                   1358,4219              1423,4235              NULL
2           PORTA-LAPIS COM PEZINHO                  1398,3905              36187,4571             30727,0777             NULL
3           REGUA DE 20 CM                           572,58                 24483,4086             19015,5294             NULL
*/
SELECT ID_PRODUTO, DESCRICAO, [2005],[2006],[2007],[2008],
                                 [2009],[2010],[2011],[2012]
FROM (SELECT I.ID_PRODUTO, PR.DESCRICAO, YEAR(PE.DATA_EMISSAO) AS ANO,
             I.QUANTIDADE * I.PR_UNITARIO AS VALOR
             FROM ITENSPEDIDO I 
                  JOIN PEDIDOS PE ON I.NUM_PEDIDO = PE.NUM_PEDIDO
                  JOIN PRODUTOS PR ON I.ID_PRODUTO = PR.ID_PRODUTO
             WHERE YEAR(PE.DATA_EMISSAO) BETWEEN 2005 AND 2012) AS P
      PIVOT( SUM(VALOR) FOR ANO IN ([2005],[2006],[2007],[2008],
                                 [2009],[2010],[2011],[2012])) AS PVT             
ORDER BY 1





-- Ex. 6: Obter este resultado (DE 2005 A 2012)
/*
ANO         Jan                                     Fev                                     Mar                                     Abr                                     Mai                                     Jun                                     Jul                                     Ago                                     Set                                     Out                                     Nov                                     Dez
----------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- ---------------------------------------
1998        NULL                                    NULL                                    2.00                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL
2005        NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    123057.86
2006        195853.74                               74142.12                                52633.17                                192008.10                               109863.20                               270606.99                               304331.27                               355785.15                               399836.21                               456404.07                               356433.03                               411469.15
2007        413277.09                               308839.70                               346366.62                               307256.40                               300144.52                               361180.14                               340396.51                               299765.85                               201110.01                               NULL                                    NULL                                    NULL
2009        NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    NULL                                    1454.99                                 NULL
*/
SELECT ANO, [1] Jan, [2] Fev, [3] Mar, [4] Abr, 
            [5] Mai, [6] Jun, [7] Jul, [8] Ago,  
            [9] 'Set', [10] 'Out', [11] Nov, [12] Dez
FROM
	(SELECT YEAR(DATA_EMISSAO) AS ANO, MONTH(DATA_EMISSAO) AS MES,
	       VLR_TOTAL
	 FROM PEDIDOS 
	 WHERE YEAR(DATA_EMISSAO) BETWEEN 2005 AND 2012) X
PIVOT(SUM(VLR_TOTAL) FOR MES IN ([1], [2], [3], [4], [5], [6], 
           [7], [8], [9], [10], [11], [12] )) Y



-- Ex. 7: Semelhante ao anterior mas mostrando os dados como mostrado abaixo
/*
MES         2005             2006           2007        2008 ... (at� 2012)   
----------- -------------- -------------- ------------ ----------- 
1           NULL           195853.74      413277.09                
2           NULL           74142.12       308839.70                
...               
8           NULL           355785.15      299765.85                
9           NULL           399836.21      201110.01                
10          NULL           456404.07      NULL                     
11          NULL           356433.03      NULL                     
12          123057.86      411469.15      NULL                     
*/                              

---------------------------------------------------------------------------------
SELECT MES,  [2005],[2006],[2007],[2008],
             [2009],[2010],[2011],[2012]
FROM
	(SELECT YEAR(DATA_EMISSAO) AS ANO, MONTH(DATA_EMISSAO) AS MES,
	       VLR_TOTAL
	 FROM PEDIDOS 
	 WHERE YEAR(DATA_EMISSAO) BETWEEN 2005 AND 2012) X
PIVOT(SUM(VLR_TOTAL) FOR ANO IN ([2005],[2006],[2007],[2008],
                                 [2009],[2010],[2011],[2012] )) Y

------------------------------------------------------------------------------

