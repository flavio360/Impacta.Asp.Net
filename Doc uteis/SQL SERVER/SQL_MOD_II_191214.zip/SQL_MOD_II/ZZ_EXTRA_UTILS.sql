USE Pedidos
GO


-- schema onde ser�o criados os objetos destinados a 
-- consulta de estruturas internas do nosso banco de dados.
-- Documenta��o e automa��o dos processos de desenvolvimento
create schema utils
go

/*
	view para consultar todas as foreign keys do banco de dados
*/
create view utils.vu_foreign_keys as
select fk.name as fk_name, fkt.name as fk_table,
fkcl.name as fk_column, 
       fkr.name as fk_refer_table ,
	   rcl.name as fk_refer_column
from sys.foreign_key_columns fkc
join sysobjects fk on fkc.constraint_object_id = fk.id
join sysobjects fkt on fkc.parent_object_id = fkt.id
join sysobjects fkr on fkc.referenced_object_id = fkr.id
join syscolumns fkcl on fkc.parent_object_id = fkcl.id and
                        fkc.parent_column_id = fkcl.colid
join syscolumns rcl on fkc.referenced_object_id = rcl.id and
                       fkc.referenced_column_id = rcl.colid
go
-- testando
select * from utils.vu_foreign_keys
go


-- consulta todos os objetos do banco de dados que n�o sejam do schema sys (internos do sql)
/*
-- SIGLAS PARA A COLUNA "Tipo"
AF = Aggregate function (CLR)
C = CHECK constraint
D = Default or DEFAULT constraint
F = FOREIGN KEY constraint
L = Log
FN = Scalar function
FS = Assembly (CLR) scalar-function
FT = Assembly (CLR) table-valued function
IF = In-lined table-function
IT = Internal table
P = Stored procedure
PC = Assembly (CLR) stored-procedure
PK = PRIMARY KEY constraint (type is K)
RF = Replication filter stored procedure
S = System table
SN = Synonym
SQ = Service queue
TA = Assembly (CLR) DML trigger
TF = Table function
TR = SQL DML Trigger
TT = Table type
U = User table
UQ = UNIQUE constraint (type is K)
V = View
X = Extended stored procedure
*/
create view utils.vu_consulta_objetos as
select a.object_id as ObjectId, b.name [Schema], a.name Nome, a.type Tipo, a.type_desc TipoObj, 
c.name Dono 
from sys.objects a join sys.schemas b on a.schema_id = b.schema_id
                   left join sys.objects c on a.parent_object_id = c.object_id
where b.name <> 'sys'
go
--
select * from utils.vu_consulta_objetos where tipo = 'u';

select * from utils.vu_consulta_objetos where [schema] = 'utils';

select * from utils.vu_consulta_objetos order by [schema], nome
--

select * from vendas.sys.sysobjects where xtype = 'C'
go

