--============================================================ MERGE (P�g. 58)
-- Coloca o banco PEDIDOS em uso
USE PEDIDOS;
--==============================================================
-- 1. Gerar uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
CREATE TABLE EMP_TEMP
( CODFUN    INT PRIMARY KEY,
  NOME      VARCHAR(30),
  COD_DEPTO INT,
  COD_CARGO	INT,
  SALARIO	NUMERIC(10,2) )
GO  

SELECT * FROM EMPREGADOS

-- 2. Inserir dados e exibir os registros inseridos
INSERT INTO EMP_TEMP OUTPUT INSERTED.*
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
WHERE COD_DEPTO = 2
GO

SELECT * FROM EMP_TEMP

-- 3. Excluir todos os registros
DELETE FROM EMP_TEMP;

-- 4. Inserir dados e exibir algumas colunas
INSERT INTO EMP_TEMP 
OUTPUT INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS WHERE COD_DEPTO = 2;
GO

 
--============================================================ OUTPUT com DELETE
-- 5. Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
DROP TABLE EMP_TEMP;

SELECT * INTO EMP_TEMP FROM EMPREGADOS

-- 6. Deleta registros e mostra os registros deletados
BEGIN TRANSACTION

SELECT @@TRANCOUNT

DELETE FROM EMP_TEMP OUTPUT DELETED.*
WHERE COD_DEPTO = 2
GO

-- OK
COMMIT
-- ERRADO
ROLLBACK

-- 7. Deleta registros e mostra alguns campos dos registros deletados
DELETE FROM EMP_TEMP 
OUTPUT DELETED.CODFUN, DELETED.NOME, DELETED.COD_DEPTO
WHERE COD_DEPTO = 3
GO

--============================================================ OUTPUT com UPDATE
-- 8. Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
DROP TABLE EMP_TEMP;
SELECT * INTO EMP_TEMP FROM EMPREGADOS;

-- 9. Altera registros e mostra os dados antes e depois da altera��o
BEGIN TRAN
                 -- SALARIO = SALARIO * 1.5   
UPDATE EMP_TEMP SET SALARIO *= 1.5
OUTPUT 
   INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO, 
   DELETED.SALARIO AS SALARIO_ANTIGO, 
   INSERTED.SALARIO AS SALARIO_NOVO
WHERE COD_DEPTO = 3;
GO

COMMIT -- ou ROLLBACK se der errado
--------------------------------------------- 
-- MERGE Cap 2 - P�g 55 
-- 10. Insere registro na tabela EMPREGADOS
INSERT INTO EMPREGADOS 
(NOME, COD_DEPTO, COD_CARGO, SALARIO, DATA_ADMISSAO)
VALUES ('Z� MAN�', 1, 1, 1000, GETDATE() )
--
SELECT * FROM EMPREGADOS 
SELECT @@IDENTITY -- 73

-- 11. Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
DROP TABLE EMP_TEMP
SELECT * INTO EMP_TEMP FROM EMPREGADOS; 
-- Testando
SELECT * FROM EMP_TEMP;

-- 12. Exclui o funcion�rio de c�digo 3 de EMP_TEMP
DELETE FROM EMP_TEMP WHERE COD_CARGO = 3;
-- 9 LINHAS A MENOS

-- 13. Altera os sal�rios de EMP_TEMP dos funcion�rios do departamento 2
UPDATE EMP_TEMP SET SALARIO *= 1.2
WHERE COD_DEPTO = 2
-- 8 LINHAS DIFERENTES

-- 14. Deleta um registro da tabela fonte (EMPREGADOS)
DELETE FROM EMPREGADOS WHERE CODFUN = 73
-- 1 LINHA A MAIS


begin tran;
-- 15. Habilita a insers�o de dados no campo identidade
SET IDENTITY_INSERT EMP_TEMP ON;
----------------------------------------------------------------
-- 16. Faz com que a tabela EMP_TEMP fique igual a tabela EMPREGADOS
MERGE EMP_TEMP AS ET    -- Tabela alvo
USING EMPREGADOS AS E   -- Tabela fonte
ON ET.CODFUN = E.CODFUN -- Condi��o de compara��o
-- Quando o registro existir nas 2 tabelas E o SALARIO for diferente
WHEN MATCHED AND E.SALARIO <> ET.SALARIO THEN
     -- Alterar o campo sal�rio de EMP_TEMP
     UPDATE SET ET.SALARIO = E.SALARIO
-- Quando o registro n�o existir em EMP_TEMP     
WHEN NOT MATCHED THEN
     -- Insere o registro em EMP_TEMP
     INSERT (CODFUN,NOME,COD_DEPTO,COD_CARGO,DATA_ADMISSAO, DATA_NASCIMENTO, 
             SALARIO, NUM_DEPEND, SINDICALIZADO, OBS, FOTO)     
     VALUES (CODFUN,NOME,COD_DEPTO,COD_CARGO,DATA_ADMISSAO, DATA_NASCIMENTO, 
             SALARIO, NUM_DEPEND, SINDICALIZADO, OBS, FOTO)
-- Quando existir o c�digo na tabela alvo e n�o existir
-- na tabela fonte             
WHEN NOT MATCHED BY SOURCE THEN
     DELETE
OUTPUT 
  INSERTED.CODFUN, DELETED.CODFUN, DELETED.SALARIO AS SALARIO_ANTIGO,
  INSERTED.SALARIO AS SALARIO_NOVO, $ACTION AS ACAO_EXECUTADA ;             
--INTO TABELA_LOG
----------------------------------------------------------------

           
-- Desabilita a insers�o de dados no campo identidade                         
SET IDENTITY_INSERT EMP_TEMP OFF;

commit

--CODFUN, NOME, NUM_DEPEND, DATA_NASCIMENTO, COD_DEPTO, COD_CARGO, DATA_ADMISSAO, SALARIO, PREMIO_MENSAL, SINDICALIZADO, OBS, FOTO, COD_SUPERVISOR












