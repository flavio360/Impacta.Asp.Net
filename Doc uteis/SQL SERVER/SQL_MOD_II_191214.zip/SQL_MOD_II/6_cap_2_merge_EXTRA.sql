USE PEDIDOS

CREATE TABLE EMPREG
(
	CODFUN			INT,
	NOME			VARCHAR(40),
	DEPARTAMENTO	VARCHAR(40),
	CARGO			VARCHAR(40),
	SALARIO			NUMERIC(12,2),
	DATA_ADMISSAO	DATETIME,
	COD_SUPERVISOR	INT
)

--NUM_PEDIDO, NUM_ITEM, ID_PRODUTO, COD_PRODUTO, CODCOR, QUANTIDADE, PR_UNITARIO, DATA_ENTREGA, SITUACAO, DESCONTO

-- Executar MERGE ------------------------------------
BEGIN TRAN;

MERGE EMPREG TA -- tabela alvo
-- tabela de refer�ncia, neste caso um SELECT para gerar a mesma
-- estrutura da tabela alvo
USING (SELECT E.CODFUN, E.NOME, D.DEPTO, C.CARGO, 
              E.SALARIO, E.DATA_ADMISSAO, E.COD_SUPERVISOR
	   FROM EMPREGADOS E JOIN TABELADEP D ON E.COD_DEPTO = D.COD_DEPTO
	                     JOIN TABELACAR C ON E.COD_CARGO = C.COD_CARGO) TR
-- chave de relacionamento entre as tabelas
ON TA.CODFUN = TR.CODFUN
-- se existir na tabela de refer�ncia e n�o existir na tabela alvo
WHEN NOT MATCHED THEN
     INSERT (CODFUN, NOME, DEPARTAMENTO, CARGO, SALARIO, DATA_ADMISSAO, COD_SUPERVISOR )
	 VALUES (CODFUN, NOME, DEPTO, CARGO, SALARIO, DATA_ADMISSAO, COD_SUPERVISOR )

-- quando existir na tabela alvo e n�o existir na tabela de refer�ncia
WHEN NOT MATCHED BY SOURCE THEN DELETE
-- se existir nas duas tabelas mas algum campo estiver diferente...
WHEN MATCHED AND ( TA.NOME <> TR.NOME OR TA.DEPARTAMENTO <> TR.DEPTO OR
                   TA.CARGO <> TR.CARGO OR TA.SALARIO <> TR.SALARIO OR 
				   TA.DATA_ADMISSAO <> tr.DATA_ADMISSAO OR 
				   TA.COD_SUPERVISOR <> TR.COD_SUPERVISOR ) THEN
     UPDATE SET TA.CODFUN		= TR.CODFUN,		
	            TA.NOME			= TR.NOME,
				TA.DEPARTAMENTO	= TR.DEPTO,
				TA.CARGO		= TR.CARGO,		
				TA.SALARIO		= TR.SALARIO,		
				TA.DATA_ADMISSAO= TR.DATA_ADMISSAO,
				TA.COD_SUPERVISOR  = TR.COD_SUPERVISOR

-- exibir relat�rio das altera��es efetuadas
OUTPUT DELETED.CODFUN AS CODFUN_OLD, INSERTED.CODFUN AS CODFUN_NEW,
       $ACTION AS COMANDO_EXECUTADO; 


-- Executar o MERGE. Vai gerar 58 INSERTs
------------------------------------------------------
-- Fazer mais altera��es
UPDATE EMPREGADOS SET SALARIO = SALARIO * 1.1 
WHERE CODFUN IN (3,5)

UPDATE EMPREGADOS SET COD_CARGO = 4 WHERE CODFUN IN (1,2)

DELETE EMPREG WHERE CODFUN IN (2,5,7)

-- Executar MERGE novamente ---------------------------
-- vai gerar 2 UPDATES e 3 INSERTS

SELECT @@TRANCOUNT

COMMIT