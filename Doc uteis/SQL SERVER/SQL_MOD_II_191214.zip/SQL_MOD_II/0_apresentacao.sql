/*
INSTRUTOR: .Carlos Magno (MAGNO)         
           .delphimagno@gmail.com
     
.M�quina Virtual

.Criar uma pasta de exerc�cios em C:\

     Windows - R (digitar o IP): \\172.16.20.56 (OK)
                                 Aparecer� a pasta SQL_MOD_II                                                
     Copiar todos os arquivos da pasta para a sua
	 pasta de exerc�cios

LOGINS e SENHAS
           
MAQUINA REAL           
	Login: di47?? (onde ?? � o n�mero da sua m�quina)
	Senha: vazia
MAQUINA VIRTUAL
    Login: Administrator
    Senha: Imp@ct@
SQL SERVER
	Login: sa    
    Senha: Imp@ct@	
INTERNET EXPLORER
    Login: internet
    Senha: internet    	
                   
.Apostila / scripts do curso                                

.Sequ�ncia do treinamento
                
Qualquer reclama��o sobre o andamento do treinamento, problemas de assimila��o, 
fale com o instrutor ou descreva o problema na AVALIA��O DI�RIA

www.impacta.com.br/avaliacao



*/









