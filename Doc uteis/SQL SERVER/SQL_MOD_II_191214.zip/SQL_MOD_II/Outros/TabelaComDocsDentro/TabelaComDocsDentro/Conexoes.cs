﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace TabelaComDocsDentro
{
    // internal: visível dentro de todo o assembly (este projeto)
    class Conexoes
    {
        // SqlConnection conn = new SqlConnection(Conexoes.SqlConnectionString );
        public static string SqlConnectionString =
            // lê a o parâmetro ConnectionString da conexão chamada conSql criada
            // dentro do App.config
            ConfigurationManager.ConnectionStrings["conSql"].ConnectionString;

        // SqlConnection conn = Conexoes.GetSqlConnection();
        public static SqlConnection GetSqlConnection()
        {
            return new SqlConnection(SqlConnectionString);
        }



    }
}
