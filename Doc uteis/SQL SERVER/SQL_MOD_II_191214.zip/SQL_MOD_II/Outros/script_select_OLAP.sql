USE [V_TESTE]
GO

CREATE TABLE [dbo].[tb_magno_estatistica_vendas](
	[id_est_venda] [int] IDENTITY(1,1) NOT NULL,
	[Matricula] [varchar](20) NULL,
	[VlrSemJuros] [money] NULL,
	[VlrComJuros] [money] NULL,
	[TipoPessoa] [char](1) NULL,
	[QtParcelas] [tinyint] NULL,
	[dtCadastro] [datetime] NULL,
	[Vendedor] [varchar](200) NULL,
	[Cliente] [varchar](200) NULL,
	[Cidade] [varchar](100) NULL,
	[SgEstado] [char](2) NULL,
	[Curso] [varchar](300) NULL,
	[Periodo] [varchar](50) NULL,
	[Modalidade] [varchar](100) NULL,
	[Categoria] [varchar](200) NULL,
	[idCliente] [int] NULL,
	[idCurso] [int] NULL,
	[fonte] [tinyint] NULL,
 CONSTRAINT [pk_tb_magno_estatistica_vendas] PRIMARY KEY ([id_est_venda])
GO

CREATE procedure [dbo].[sp_magno_carrega_tb_magno_estatistica_vendas](@dtInicio datetime = '1980.1.1')
as begin
-- 1. Insere os dados referentes a compras efetuadas no site por pessoas f�sicas
insert into v_teste.dbo.tb_magno_estatistica_vendas
(Matricula, VlrSemJuros, VlrComJuros, TipoPessoa, QtParcelas, dtCadastro, Vendedor, Cliente, Cidade, SgEstado, Curso, 
 Periodo, Modalidade, Categoria, idCliente, idCurso, fonte)
select a.Matricula, g.nrvalor, g.nrvalor + (g.nrvalor * n.nrporcentagem) * n.nrcoeficiente, a.InTipo, a.QtParcelas, b.dtcadastro, 'Carrinho Site' as Vendedor, c.NmAluno as Cliente,
       c.DesCidade, c.SgEstado, l.DesCurso as Curso, m.DesPeriodo, i.desprodutotipo, 
	   	   isnull(
	   (
	   select top 1 p.descategoria from saturn.vendas.dbo.tb_cursosversoesmoduloscursos n 
              left join saturn.vendas.dbo.tb_cursoscategorias o on n.idmodulo = o.idmodulo
              left join saturn.simpacweb.dbo.tb_categorias p on o.idcategoria = p.idcategoria
			  where l.IdCurso = n.idcurso and p.descategoria <> 'Online'
		order by p.parentid desc
	   ),'SEM CATEGORIA'),
	   c.idAluno, l.idCurso, 0	    
from SATURN.simpac.dbo.tb_ControleFinanceiro a
     join SATURN.Vendas.dbo.tb_clientespagamentosrecibosmatriculas b on a.Matricula = b.matricula
     join SATURN.simpac.dbo.tb_Aluno c on a.IdCliente = c.IdAluno
	 join SATURN.Vendas.dbo.tb_clientespagamentosrecibos d on b.idrecibo = d.idrecibo
	 join SATURN.Vendas.dbo.tb_clientescarrinhos e on d.dessession = e.dessession
	 join SATURN.Vendas.dbo.tb_clientescarrinhosprodutos f on e.idcarrinho = f.idcarrinho and f.inremovido = 0
	 join SATURN.Vendas.dbo.tb_valores g on f.idvalor = g.idvalor
	 join SATURN.Vendas.dbo.tb_produtos h on g.idproduto = h.idproduto
	 join SATURN.Vendas.dbo.tb_produtotipos i on h.idprodutotipo = i.idprodutotipo
	 join SATURN.Vendas.dbo.tb_produtoscursosagendados j on h.idproduto = j.idproduto
	 join SATURN.Simpac.dbo.tb_CursosAgendados k on j.idcursoagendado = k.IdCursoAgendado
	 join SATURN.Simpac.dbo.tb_Cursos l on k.IDCurso = l.IdCurso
	 join SATURN.Simpac.dbo.tb_periodo m on k.idPeriodo  = m.idPeriodo
	 join saturn.simpac.dbo.tb_parcelajuros n on a.QtParcelas = n.idparcela
	 --left join V_TESTE.DBO.tb_categoriascursos n on l.IdCurso = n.idcurso
	 --join SATURN.simpacweb.dbo.tb_categorias o on n.idcategoria = o.idcategoria
where b.dtCadastro >= @dtInicio and a.InTipo = 'F'
-- 2. Insere os dados referentes a compras efetuadas no site por pessoas jur�dicas
insert into v_teste.dbo.tb_magno_estatistica_vendas
(Matricula, VlrSemJuros, VlrComJuros, TipoPessoa, QtParcelas, dtCadastro, Vendedor, Cliente, Cidade, SgEstado, Curso, 
 Periodo, Modalidade, Categoria, idCliente, idCurso, fonte)
select a.Matricula, g.nrvalor, g.nrvalor + (g.nrvalor * n.nrporcentagem) * n.nrcoeficiente, a.InTipo, a.QtParcelas, b.dtcadastro, 'Carrinho Site' as Vendedor, c.NmEmpresa as Cliente,
       c.DesCidade, c.SgEstado, l.Descurso as Curso, m.DesPeriodo, i.desprodutotipo, 
	  	   isnull(
	   (
	   select top 1 p.descategoria from saturn.vendas.dbo.tb_cursosversoesmoduloscursos n 
              left join saturn.vendas.dbo.tb_cursoscategorias o on n.idmodulo = o.idmodulo
              left join saturn.simpacweb.dbo.tb_categorias p on o.idcategoria = p.idcategoria
			  where l.IdCurso = n.idcurso and p.descategoria <> 'Online'
		order by p.parentid desc
	   ),'SEM CATEGORIA')   ,
	   a.idCliente, l.IdCurso, 1
from SATURN.simpac.dbo.tb_ControleFinanceiro a
     join SATURN.Vendas.dbo.tb_clientespagamentosrecibosmatriculas b on a.Matricula = b.matricula
     join SATURN.simpac.dbo.tb_Empresa c on a.IdCliente = c.IdEmpresa
	 join SATURN.Vendas.dbo.tb_clientespagamentosrecibos d on b.idrecibo = d.idrecibo
	 join SATURN.Vendas.dbo.tb_clientescarrinhos e on d.dessession = e.dessession
	 join SATURN.Vendas.dbo.tb_clientescarrinhosprodutos f on e.idcarrinho = f.idcarrinho and f.inremovido = 0
	 join SATURN.Vendas.dbo.tb_valores g on f.idvalor = g.idvalor
	 join SATURN.Vendas.dbo.tb_produtos h on g.idproduto = h.idproduto
	 join SATURN.Vendas.dbo.tb_produtotipos i on h.idprodutotipo = i.idprodutotipo
	 join SATURN.Vendas.dbo.tb_produtoscursosagendados j on h.idproduto = j.idproduto
	 join SATURN.Simpac.dbo.tb_CursosAgendados k on j.idcursoagendado = k.IdCursoAgendado
	 join SATURN.Simpac.dbo.tb_Cursos l on k.IDCurso = l.IdCurso
	 join SATURN.Simpac.dbo.tb_periodo m on k.idPeriodo  = m.idPeriodo
	 join saturn.simpac.dbo.tb_parcelajuros n on a.QtParcelas = n.idparcela
	 --left join V_TESTE.DBO.tb_categoriascursos n on l.IdCurso = n.idcurso
	 --join SATURN.simpacweb.dbo.tb_categorias o on n.idcategoria = o.idcategoria
where b.dtCadastro > @dtInicio and a.InTipo = 'J'
-- 3. Insere os dados referentes a compras efetuadas internamente por pessoas f�sicas
insert into v_teste.dbo.tb_magno_estatistica_vendas
(Matricula, VlrSemJuros, VlrComJuros, TipoPessoa, QtParcelas, dtCadastro, Vendedor, Cliente, Cidade, SgEstado, Curso, 
 Periodo, Modalidade, Categoria, idCliente, idCurso, fonte)
select a.Matricula,  e.Unitario * e.Qtde , e.Unitario * e.Qtde + (e.Unitario * e.Qtde * l.nrporcentagem) * l.nrcoeficiente , a.InTipo, a.QtParcelas, b.dtCadastro, c.NmCompleto as Vendedor, d.NmAluno as Cliente,
       -- a mesma cidade est� escrita de formas diferentes
       d.DesCidade, d.SgEstado, k.DesCurso as Curso, j.DesPeriodo as Periodo, g.DesTipo, 
	   	   isnull(
	   (
	   select top 1 p.descategoria from saturn.vendas.dbo.tb_cursosversoesmoduloscursos n 
              left join saturn.vendas.dbo.tb_cursoscategorias o on n.idmodulo = o.idmodulo
              left join saturn.simpacweb.dbo.tb_categorias p on o.idcategoria = p.idcategoria
			  where e.IdCurso = n.idcurso and p.descategoria <> 'Online'
		order by p.parentid desc
	   ),'SEM CATEGORIA'),
	   a.IdCliente, e.IdCurso, 2
from SATURN.simpac.dbo.tb_ControleFinanceiro a
     join SATURN.simpac.dbo.tb_Pedidos b on a.IdPedido = b.IdPedido + 15000  
	 join SATURN.simpac.dbo.tb_Usuario c on b.IdVendedor = c.IdUsuario
	 join SATURN.simpac.dbo.tb_Aluno d on a.IdCliente = d.IdAluno 
	 join SATURN.simpac.dbo.tb_PedidoCursos e on b.IdPedido = e.IdPedido  
	 join SATURN.simpac.dbo.tb_CursoCalendario f on e.IdCurso = f.IdCurso
	 join SATURN.simpac.dbo.tb_CursoTipo g on f.IdTipo = g.IdTipo
	 --left join V_TESTE.DBO.tb_categoriascursos h on e.IdCurso = h.idcurso
	 --join SATURN.simpacweb.dbo.tb_categorias i on h.idcategoria = i.idcategoria
	 join SATURN.simpac.dbo.tb_periodo j on e.IdPeriodo = j.IdPeriodo
	 join SATURN.simpac.dbo.tb_cursos k on e.IdCurso = k.IdCurso
	 join saturn.simpac.dbo.tb_parcelajuros l on a.QtParcelas = l.idparcela
where b.dtCadastro > @dtInicio and a.InTipo = 'F'
-- 4. Insere os dados referentes a compras efetuadas internamente por pessoas jur�dicas
insert into v_teste.dbo.tb_magno_estatistica_vendas
(Matricula, VlrSemJuros, VlrComJuros, TipoPessoa, QtParcelas, dtCadastro, Vendedor, Cliente, Cidade, SgEstado, Curso, 
 Periodo, Modalidade, Categoria, idCliente, idCurso, fonte)
select a.Matricula,  e.Unitario * e.Qtde, e.Unitario * e.Qtde + (e.Unitario * e.Qtde * l.nrporcentagem) * l.nrcoeficiente , a.InTipo, a.QtParcelas, b.dtCadastro, c.NmCompleto as Vendedor, d.NmEmpresa,
       -- a mesma cidade est� escrita de formas diferentes
       d.DesCidade, d.SgEstado, k.DesCurso as Curso, j.DesPeriodo as Periodo, 
	   g.DesTipo, 	   isnull(
	   (
	   select top 1 p.descategoria from saturn.vendas.dbo.tb_cursosversoesmoduloscursos n 
              left join saturn.vendas.dbo.tb_cursoscategorias o on n.idmodulo = o.idmodulo
              left join saturn.simpacweb.dbo.tb_categorias p on o.idcategoria = p.idcategoria
			  where e.IdCurso = n.idcurso and p.descategoria <> 'Online'
		order by p.parentid desc
	   ),'SEM CATEGORIA'),
	   a.IdCliente, e.IdCurso, 3
from SATURN.simpac.dbo.tb_ControleFinanceiro a
     join SATURN.simpac.dbo.tb_Pedidos b on a.IdPedido = b.IdPedido + 15000  
	 join SATURN.simpac.dbo.tb_Usuario c on b.IdVendedor = c.IdUsuario
	 join SATURN.simpac.dbo.tb_Empresa d on a.IdCliente = d.IdEmpresa 
	 join SATURN.simpac.dbo.tb_PedidoCursos e on b.IdPedido = e.IdPedido  
	 join SATURN.simpac.dbo.tb_CursoCalendario f on e.IdCurso = f.IdCurso
	 join SATURN.simpac.dbo.tb_CursoTipo g on f.IdTipo = g.IdTipo
	 --left join V_TESTE.DBO.tb_categoriascursos h on e.IdCurso = h.idcurso
	 --join SATURN.simpacweb.dbo.tb_categorias i on h.idcategoria = i.idcategoria
	 join SATURN.simpac.dbo.tb_periodo j on e.IdPeriodo = j.IdPeriodo
	 join SATURN.simpac.dbo.tb_cursos k on e.IdCurso = k.IdCurso
	 join saturn.simpac.dbo.tb_parcelajuros l on a.QtParcelas = l.idparcela
where b.dtCadastro > @dtInicio and a.InTipo = 'J'
end 
GO


