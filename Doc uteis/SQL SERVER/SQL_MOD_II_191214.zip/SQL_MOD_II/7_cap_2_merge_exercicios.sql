USE PEDIDOS;
-- Dicas importantes ------------------------------------------
SELECT * INTO EMPREG_TEMP FROM EMPREGADOS

SELECT * FROM Empregados

SELECT * FROM TABELADEP
--SOLU��O COM SUB-QUERY
DELETE FROM EMPREG_TEMP 
WHERE COD_DEPTO = (SELECT COD_DEPTO FROM TABELADEP 
                   WHERE DEPTO = 'PESSOAL' )
-- SOLU��O COM JOIN
DELETE FROM EMPREG_TEMP 
--SELECT *
FROM EMPREG_TEMP E JOIN TABELADEP D ON E.COD_DEPTO = D.COD_DEPTO
WHERE D.DEPTO = 'PESSOAL'           

-- 
UPDATE EMPREG_TEMP SET SALARIO = SALARIO * 1.2
WHERE COD_DEPTO = (SELECT COD_DEPTO FROM TABELADEP 
                   WHERE DEPTO = 'PESSOAL' )
--FROM EMPREG_TEMP E JOIN TABELADEP D ON E.COD_DEPTO = D.COD_DEPTO
--WHERE D.DEPTO = 'PESSOAL'    

---------------------------------------------------------------
-- 1. Colocar em uso o banco de dados PEDIDOS
-- Resp.:
USE PEDIDOS

SELECT @@TRANCOUNT
-- 2. Gere uma c�pia da tabela PRODUTOS chamada PRODUTOS_COPIA
-- Resp.:     


-- 3. Exclua da tabela PRODUTOS_COPIA os produtos que sejam do tipo 'CANETA'
--    exibindo (OUTPUT) os registros que foram exclu�dos.
-- Resp.:





-- 4. Aumente em 10% ( * 1.10) os pre�os de venda dos produtos do tipo REGUA
--    mostrando com OUTPUT as seguintes colunas:
--    ID_PRODUTO, DESCRICAO, PRECO_VENDA_ANTIGO e PRECO_VENDA_NOVO
-- Resp.:



-- 5. Exclua de PROD_FORN os registros com ID_PRODUTO = 48.
--    Gere OUTPUT dos registros excluidos.
-- 2 LINHAS




-- 5b. Exclua de ITENSPEDIDO os registros com ID_PRODUTO = 48.
--    Gere OUTPUT dos registros excluidos.
-- 492 LINHAS




-- 6. Exclua de PRODUTOS (e n�o da c�pia) o produto com ID_PRODUTO = 48
--    Gere OUTPUT dos registros excluidos.
-- 1 LINHA




-- 7. Utilizando o comando MERGE, fa�a com que a tabela PRODUTOS_COPIA
--    volte a ficar id�ntica a tabela PRODUTOS, ou seja, o que foi deletado
--    de PRODUTOS_COPIA deve ser reinserido os produtos que tiverem seus
--    pre�os alterados devem ser alterados novamente para que voltem ao
--    pre�o anterior e se algum produto foi deletado da tabela fonte (PRODUTOS)
--    deve ser deletado tamb�m da tabela alvo. 
-- Resp.:
BEGIN TRAN;

SET IDENTITY_INSERT PRODUTOS_COPIA ON;

MERGE PRODUTOS_COPIA AS TA USING PRODUTOS TR
ON TA.ID_PRODUTO = TR.ID_PRODUTO
-- quando o ID_PRODUTO existir nas duas mas o pre�o for diferente
WHEN MATCHED AND (TA.COD_PRODUTO	<> TR.COD_PRODUTO	OR 
                  TA.DESCRICAO		<> TR.DESCRICAO		OR 
				  TA.COD_UNIDADE	<> TR.COD_UNIDADE	OR
				  TA.COD_TIPO		<> TR.COD_TIPO		OR
				  TA.PRECO_CUSTO	<> TR.PRECO_CUSTO	OR
				  TA.PRECO_VENDA	<> TR.PRECO_VENDA	OR
				  TA.QTD_ESTIMADA	<> TR.QTD_ESTIMADA	OR
				  TA.QTD_REAL		<> TR.QTD_REAL		OR
				  TA.QTD_MINIMA		<> TR.QTD_MINIMA    OR
				  TA.CLAS_FISC		<> TR.CLAS_FISC		OR
				  TA.IPI			<> TR.IPI			OR
				  TA.PESO_LIQ		<> TR.PESO_LIQ	
				  ) THEN
    UPDATE SET TA.COD_PRODUTO	= TR.COD_PRODUTO,
			   TA.DESCRICAO		= TR.DESCRICAO	,	
			   TA.COD_UNIDADE	= TR.COD_UNIDADE,
			   TA.COD_TIPO		= TR.COD_TIPO	,	
			   TA.PRECO_CUSTO	= TR.PRECO_CUSTO,
			   TA.PRECO_VENDA	= TR.PRECO_VENDA,
			   TA.QTD_ESTIMADA	= TR.QTD_ESTIMADA,
			   TA.QTD_REAL		= TR.QTD_REAL		,
			   TA.QTD_MINIMA		= TR.QTD_MINIMA  ,
			   TA.CLAS_FISC		= TR.CLAS_FISC		,
			   TA.IPI			= TR.IPI			,
			   TA.PESO_LIQ		= TR.PESO_LIQ	
WHEN NOT MATCHED THEN
     INSERT (ID_PRODUTO, COD_PRODUTO, DESCRICAO, COD_UNIDADE, COD_TIPO, PRECO_CUSTO, PRECO_VENDA, QTD_ESTIMADA, QTD_REAL, QTD_MINIMA, CLAS_FISC, IPI, PESO_LIQ )
	 VALUES (ID_PRODUTO, COD_PRODUTO, DESCRICAO, COD_UNIDADE, COD_TIPO, PRECO_CUSTO, PRECO_VENDA, QTD_ESTIMADA, QTD_REAL, QTD_MINIMA, CLAS_FISC, IPI, PESO_LIQ )

WHEN NOT MATCHED BY SOURCE THEN DELETE

OUTPUT DELETED.ID_PRODUTO, INSERTED.ID_PRODUTO, DELETED.PRECO_VENDA,
       INSERTED.PRECO_VENDA, $ACTION, GETDATE(); 

SET IDENTITY_INSERT PRODUTOS_COPIA OFF

-- OK
COMMIT;
-- ERRADO
ROLLBACK;