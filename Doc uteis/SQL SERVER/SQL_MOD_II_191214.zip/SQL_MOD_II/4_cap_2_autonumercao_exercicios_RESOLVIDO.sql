-- 0. Criar banco de dados chamado EXERC_IDENTITY e coloc�-lo em uso
CREATE DATABASE EXERC_IDENTITY
GO
USE EXERC_IDENTITY
-- 1. Criar a tabela PESSOAS
/*
	PESSOAS
	
	Obs.: A numera��o do campo c�digo precisa iniciar em 10
	
	COD_PESSOA			INT		autonumera��o		chave prim�ria
	NOME				VARCHAR(30)
	ENDERECO			VARCHAR(50)
	SEXO				CHAR(1)
	------------------------------------------------------------------------
*/
CREATE TABLE PESSOAS
(
	COD_PESSOA			INT		IDENTITY(10,1),
	NOME				VARCHAR(30),
	ENDERECO			VARCHAR(50),
	SEXO				CHAR(1)
	CONSTRAINT PK_PESSOAS PRIMARY KEY(COD_PESSOA)
)
-- 2. Insira 5 registros na tabela PESSOAS
INSERT INTO PESSOAS (NOME, ENDERECO, SEXO)
VALUES ('CARLOS MAGNO','RUA A, No 1','M'), 
       ('MARIANGELA','RUA B, No 2','F'),
	   ('GUSTAVO','RUA C, No. 3','M'),
       ('J�SSICA','RUA D, No 4','F'),
	   ('RAFAELA','RUA E, No 5','F')

-- Listar a tabela PESSOAS
SELECT * FROM PESSOAS

-- 3. Apague os registros da tabela PESSOAS com c�digo 11 e 13
DELETE FROM PESSOAS WHERE COD_PESSOA IN (11,13)
-- OU
DELETE FROM PESSOAS WHERE COD_PESSOA = 11 OR COD_PESSOA = 13

-- Listar a tabela PESSOAS
SELECT * FROM PESSOAS
-- 4. Na tabela PESSOAS, insira os seguintes registros nos c�digos 11 e 13
    /*
       CODIGO		NOME				ENDERECO			SEXO
       11			PEDRO DE OLIVEIRA	AV. PAULISTA, 1009	M
       13			MARIA LUIZA			AV. PAULISTA, 1009	F
    */ 
SET IDENTITY_INSERT PESSOAS ON

INSERT INTO PESSOAS (COD_PESSOA, NOME, ENDERECO, SEXO)
VALUES 
  (11, 'PEDRO DE OLIVEIRA', 'AV. PAULISTA, 1009', 'M'),
  (13, 'MARIA LUIZA', 'AV. PAULISTA, 1009', 'F')

SET IDENTITY_INSERT PESSOAS OFF
-- Listar a tabela PESSOAS
SELECT * FROM PESSOAS

-- 5. Alterar o contador de IDENTITY da tabela PESSOAS de modo que o pr�ximo INSERT.
--    gere o c�digo 100
DBCC CHECKIDENT('PESSOAS', RESEED, 99)
--     Insira mais 2 linhas na tabela PESSOAS 
INSERT INTO PESSOAS (NOME, ENDERECO, SEXO)
VALUES 
  ('PEDRO PAULO', 'AV. PAULISTA, 1009', 'M'),
  ('MARCO ANTONIO', 'AV. PAULISTA, 1009', 'M')
--
SELECT * FROM PESSOAS


-- USANDO SEQUENCE ----------------------------------------

-- 1. Criar a tabela PESSOAS
/*
	PESSOAS
	
	Obs.: A numera��o do campo c�digo precisa iniciar em 10
	
	COD_PESSOA			INT		chave prim�ria
	NOME				VARCHAR(30)
	ENDERECO			VARCHAR(50)
	SEXO				CHAR(1)
	------------------------------------------------------------------------
*/
DROP TABLE PESSOAS
GO
CREATE TABLE PESSOAS -- com SEQUENCE
(
	COD_PESSOA			INT, -- n�o usa IDENTITY
	NOME				VARCHAR(30),
	ENDERECO			VARCHAR(50),
	SEXO				CHAR(1)
	CONSTRAINT PK_PESSOAS PRIMARY KEY(COD_PESSOA)
)
--
CREATE SEQUENCE SEQ_PESSOAS START WITH 10 INCREMENT BY 1

-- 2. Insira 5 registros na tabela PESSOAS
INSERT INTO PESSOAS (COD_PESSOA, NOME, ENDERECO, SEXO)
VALUES (NEXT VALUE FOR SEQ_PESSOAS, 'CARLOS MAGNO','RUA A, No 1','M'), 
       (NEXT VALUE FOR SEQ_PESSOAS, 'MARIANGELA','RUA B, No 2','F'),
	   (NEXT VALUE FOR SEQ_PESSOAS, 'GUSTAVO','RUA C, No. 3','M'),
       (NEXT VALUE FOR SEQ_PESSOAS, 'J�SSICA','RUA D, No 4','F'),
	   (NEXT VALUE FOR SEQ_PESSOAS, 'RAFAELA','RUA E, No 5','F')

-- Listar a tabela PESSOAS
SELECT * FROM PESSOAS
-- 3. Apague os registros da tabela PESSOAS com c�digo 11 e 13
DELETE FROM PESSOAS WHERE COD_PESSOA IN (11,13)
-- Listar a tabela PESSOAS
SELECT * FROM PESSOAS
-- 4. Na tabela PESSOAS, insira os seguintes registros nos c�digos 11 e 13
    /*
       CODIGO		NOME				ENDERECO			SEXO
       11			PEDRO DE OLIVEIRA	AV. PAULISTA, 1009	M
       13			MARIA LUIZA			AV. PAULISTA, 1009	F
    */ 
INSERT INTO PESSOAS (COD_PESSOA,NOME, ENDERECO, SEXO)
VALUES 
  (11,'PEDRO PAULO', 'AV. PAULISTA, 1009', 'M'),
  (13,'MARCO ANTONIO', 'AV. PAULISTA, 1009', 'M')
-- Listar a tabela PESSOAS
SELECT * FROM PESSOAS
-- 5. Alterar o contador da SEQUENCE de modo que o pr�ximo INSERT.
--    gere o c�digo 100
ALTER SEQUENCE SEQ_PESSOAS RESTART WITH 100
--     Insira mais 2 linhas na tabela PESSOAS 
INSERT INTO PESSOAS (COD_PESSOA, NOME, ENDERECO, SEXO)
VALUES 
  (NEXT VALUE FOR SEQ_PESSOAS, 'PEDRO PAULO', 'AV. PAULISTA, 1009', 'M'),
  (NEXT VALUE FOR SEQ_PESSOAS,'MARCO ANTONIO', 'AV. PAULISTA, 1009', 'M')
--
SELECT * FROM PESSOAS
