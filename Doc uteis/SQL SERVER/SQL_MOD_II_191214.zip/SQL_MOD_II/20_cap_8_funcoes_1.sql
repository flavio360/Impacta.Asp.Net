/*
	Stored Procedure: Executar tarefas nas tabelas do banco de dados
	                  Normalmente devolve informa��es sobre a tarefa executada
	                  
	                  Executa com EXEC nomeProcedure listaParametros
	                  
	Fun��o: Retornar valor � a principal finalidade da fun��o. Toda fun��o
	        tem que retornar valor. Uma fun��o N�O PODE executar INSERT,
	        DELETE, UPDATE em tabelas permanentes do banco de dados
	        
	        Fun��o pode ser executada dentro de qualquer comando, onde o dado
	        que ela retorna possa ser usado, por ex:
	        
				UPDATE tabela SET campoINT = Fun��oRetornaInt()
				...
				SELECT ...
				WHERE campoDATETIME > Fun��oRetornaData()
				...
				WHILE @varString <> Fun��oRetornaString()
				 
    
                                 +--- Determin�sticas
                                 |
                                 |
             +------- Escalares -|
             |        (1 valor)  |
             |                   |
	FUN��ES -|                   +--- N�o Determin�sticas
             |
             |
             +------- Tabulares (executada com SELECT)
                   (linhas e colunas)

*/

--FUN��ES DETERMIN�STICAS: Resultado previs�vel
SELECT PI()
SELECT LEN('CARLOS MAGNO')
SELECT SQRT(144)
SELECT RAND(1456)
SELECT SQUARE( 12 )


--FUN��ES N�O DETERMIN�STICAS: Resultado n�o previs�vel
SELECT RAND()
SELECT GETDATE()
SELECT NEWID()

--====================================================
-- Cria��o de FUN��ES ESCALARES
--====================================================
USE PEDIDOS;
GO
------------------------------------------------------
-- 1. Fun��o que recebe 2 n�meros e retorna o maior deles
------------------------------------------------------
-- No SQL 2012
-- os par�metros de uma fun��o precisam estar entre par�nteses
-- se a fun��o n�o receber par�metros � obrigat�rio colocar o par
-- de par�nteses vazio
CREATE FUNCTION FN_MAIOR(@N1 FLOAT, @N2 FLOAT)
   -- precisa declarar o tipo de dado retornado
   RETURNS FLOAT
AS BEGIN
-- vari�vel para o resultado
DECLARE @MAIOR FLOAT;

--IF @N1 > @N2 SET @MAIOR = @N1;
--ELSE SET @MAIOR = @N2;

-- A partir do SQL 2012
SET @MAIOR = IIF(@N1 > @N2, @N1, @N2);
-- uma fun��o TEM QUE TER ter 1 �NICO comando RETURN que tem que estar na
-- �ltima linha do c�digo
RETURN @MAIOR;
END
GO
-------------------------------------------------
CREATE FUNCTION FN_MAIOR(@N1 FLOAT, @N2 FLOAT)
   -- precisa declarar o tipo de dado retornado
   RETURNS FLOAT
AS BEGIN
RETURN IIF(@N1 > @N2, @N1, @N2);
END
GO

-- ERRADO --------------------------------------------
CREATE FUNCTION FN_MAIOR_ERRADO(@N1 FLOAT, @N2 FLOAT)
   -- precisa declarar o tipo de dado retornado
   RETURNS FLOAT
AS BEGIN

IF @N1 > @N2 RETURN @N1
ELSE RETURN @N2

END
GO

-- Testando
-- Os par�metros tem que ser passados entre par�nteses
-- � obrigat�rio colocar o nome do SCHEMA (dbo.) antes do nome da fun��o
SELECT DBO.FN_MAIOR( 5,3 )
SELECT DBO.FN_MAIOR( 7,11 )

SELECT NOME, dbo.FN_MAIOR(SALARIO, PREMIO_MENSAL) AS MAIOR,
       CASE 
         WHEN SALARIO > PREMIO_MENSAL THEN 'SALARIO'
         ELSE 'PREMIO'
       END   AS  [Qual � Maior?]
FROM EMPREGADOS
GO
-----------------------------------------------------------------
-- 2. EXERC�CIO: Criar fun��o FN_MEDIA que receba 2 n�meros e 
-- retorne a m�dia aritm�tica entre ambos
-----------------------------------------------------------------
CREATE FUNCTION FN_MEDIA(@N1 NUMERIC(18,2), @N2 NUMERIC(18,2))
    RETURNS NUMERIC(18,4)
AS BEGIN

RETURN ( @N1 + @N2 ) / 2;

END
GO
-- Testando
SELECT DBO.FN_MEDIA( 5,3 )
SELECT DBO.FN_MEDIA( 7,11 )
SELECT DBO.FN_MEDIA( 6.234,10.567 )

GO

--------------------------------------------------------------
-- 3. Fun��o que retorna com o nome do dia da semana de uma data
-- em portugu�s
--------------------------------------------------------------
CREATE FUNCTION FN_NOME_DIA_SEMANA(@DT DATETIME) 
    RETURNS VARCHAR(15)
AS BEGIN
-- pegar o n�mero do dia da semana
DECLARE @NUM_DS INT = DATEPART(WEEKDAY, @DT);
-- vari�vel para o nome do dia da semana
DECLARE @NOME_DS VARCHAR(15) = CASE @NUM_DS
                                   WHEN 1 THEN 'DOMINGO'
                                   WHEN 2 THEN 'SEGUNDA-FEIRA'
								   WHEN 3 THEN 'TER�A-FEIRA'
								   WHEN 4 THEN 'QUARTA-FEIRA'
								   WHEN 5 THEN 'QUINTA-FEIRA'
								   WHEN 6 THEN 'SEXTA-FEIRA'
								   WHEN 7 THEN 'S�BADO'								   
                               END
RETURN @NOME_DS;
END
GO
--- SOLU��O 2
ALTER FUNCTION FN_NOME_DIA_SEMANA(@DT DATETIME) 
    RETURNS VARCHAR(15)
AS BEGIN
RETURN  CASE DATEPART(WEEKDAY, @DT)
                                   WHEN 1 THEN 'DOMINGO'
                                   WHEN 2 THEN 'SEGUNDA-FEIRA'
								   WHEN 3 THEN 'TER�A-FEIRA'
								   WHEN 4 THEN 'QUARTA-FEIRA'
								   WHEN 5 THEN 'QUINTA-FEIRA'
								   WHEN 6 THEN 'SEXTA-FEIRA'
								   WHEN 7 THEN 'S�BADO'								   
         END
END
GO


--- SOLU��O 3 - SQL 2012 em diante
CREATE FUNCTION FN_NOME_DIA_SEMANA(@DT DATETIME) 
    RETURNS VARCHAR(15)
AS BEGIN
RETURN CHOOSE(DATEPART(WEEKDAY, @DT), 'DOMINGO', 'SEGUNDA-FEIRA',
			  'TER�A-FEIRA', 'QUARTA-FEIRA', 'QUINTA-FEIRA',
    		  'SEXTA-FEIRA', 'S�BADO');
END
GO
-- TESTANDO
SELECT NOME, DATA_ADMISSAO, DATENAME(WEEKDAY,DATA_ADMISSAO),
       DBO.FN_NOME_DIA_SEMANA( DATA_ADMISSAO ) AS DIA_SEMANA
FROM EMPREGADOS
--
GO
-----------------------------------------------------------
-- 4. EXERC�CIO: Criar fun��o FN_NOME_MES que retorne com o nome do M�S
-- MONTH( DATA ) -> retorna o n�mero do m�s
-----------------------------------------------------------
CREATE FUNCTION FN_NOME_MES(@DT DATETIME) RETURNS VARCHAR(15)
AS BEGIN

RETURN CHOOSE(MONTH(@DT), 'JANEIRO', 'FEVEREIRO', 'MAR�O', 'ABRIL', 
                          'MAIO', 'JUNHO', 'JULHO', 'AGOSTO', 
						  'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO');

END
GO
-- Testando
SELECT NOME, DATA_ADMISSAO, DATENAME(MONTH,DATA_ADMISSAO) MES_SQL,
       DBO.FN_NOME_MES(DATA_ADMISSAO) MES_NOSSA_FUNC
FROM EMPREGADOS

SELECT DBO.FN_NOME_MES(DATA_ADMISSAO), SUM(SALARIO)
FROM EMPREGADOS
GROUP BY DBO.FN_NOME_MES(DATA_ADMISSAO)


--============================================================
INSERT INTO EMPREGADOS
(NOME, COD_DEPTO, COD_CARGO, SALARIO, DATA_ADMISSAO)
VALUES ('ZERO BERTO', 1, 1, 1000, GETDATE()) 
--
SELECT * FROM EMPREGADOS   
WHERE DATA_ADMISSAO = '2019.12.14'
---
SELECT * FROM EMPREGADOS   
WHERE DATA_ADMISSAO = GETDATE()
--
SELECT * FROM EMPREGADOS 
WHERE DATA_ADMISSAO BETWEEN '2019.12.14' AND '2019.12.14 23:59'

-- 5. EXERC�CIO: Criar uma fun��o que trunque uma data desprezando a parte da hora
-- Dica:
SELECT GETDATE()


SELECT CAST(GETDATE() AS FLOAT)

SELECT FLOOR( CAST(GETDATE() AS FLOAT) )

SELECT CAST( FLOOR( CAST(GETDATE() AS FLOAT) ) AS DATETIME )
GO

SELECT CAST(GETDATE() AS DATE)
GO
------------------ CRIAR A FUN��O -------------------
CREATE FUNCTION FN_TRUNCA_DATA(@DT DATETIME) RETURNS DATETIME
AS BEGIN
RETURN CAST( FLOOR( CAST(@DT AS FLOAT) ) AS DATETIME )
END
GO
------------------ Testando -------------------------
SELECT * FROM EMPREGADOS   
WHERE DBO.FN_TRUNCA_DATA( DATA_ADMISSAO ) = '2019.12.14'
--
SELECT * FROM EMPREGADOS   
WHERE DBO.FN_TRUNCA_DATA( DATA_ADMISSAO ) =
      DBO.FN_TRUNCA_DATA( GETDATE() )
GO      
-------------------------------------------------------------------------
-- 6. Fun��o que retorna com uma data a partir dos n�meros 
--    do ANO, M�S e DIA
------------------------------------------------------------------------- 
CREATE FUNCTION FN_MONTA_DATA(@ANO INT, @MES INT, @DIA INT) RETURNS DATETIME
AS BEGIN
-- criar string concatenando dia, m�s e ano
DECLARE @STR_DATA CHAR(10) = CAST(@DIA AS CHAR(2)) + '/' +
                             CAST(@MES AS CHAR(2)) + '/' +
							 CAST(@ANO AS CHAR(4));

-- converter o string para DATETIME
-- DECLARE @DT DATETIME = CAST(@STR_DATA AS DATETIME);							 
DECLARE @DT DATETIME = CONVERT(DATETIME, @STR_DATA, 103);							  

RETURN @DT;
END
GO
--

SELECT DBO.FN_MONTA_DATA( 2009, 5, 28 )
-- no SQL 2012 use DateFromParts( ano, mes, dia)
SELECT DATEFROMPARTS(2013,2,6)
-- ou
SELECT DATETIMEFROMPARTS(2013,2,6,15,10,20,123)

---------------------------------------------------------------------------
SELECT NOME, DATA_ADMISSAO, CONVERT( VARCHAR(10), 
                             DATA_ADMISSAO, 103 ) AS DATA
FROM EMPREGADOS
-- no SQL 2012 ---------------------------------------------
SELECT NOME, DATA_ADMISSAO, 
       FORMAT(DATA_ADMISSAO, 'dddd - dd/MM/yyyy - HH:mm:ss' ) AS DATA,
	   FORMAT(SALARIO, 'R$ #,##0.00')
FROM EMPREGADOS
/*
	Caracteres para formata��o de n�meros:
		0: define uma posi��o num�rica. Se n�o existir n�mero na posi��o aparece o zero
		#: define uma posi��o num�rica. Se n�o existir n�mero na posi��o fica vazio
		.: separador de decimal
		,: separador de milhar
		%: mostra o sinal e o n�mero multiplicado por 100

        qualquer outro caractere inserido na m�scara de formata��o
		set� exibido normalmente na posi��o em que foi colocado

	Caracteres para formata��o de data:

	    d: dia com 1 ou 2 d�gitos
       dd: dia com 2 d�gitos
      ddd: abrevia��o do dia da semana 
     dddd: nome do dia da semana 
        M: m�s com 1 ou 2 d�gitos
       MM: m�s com 2 d�gitos 
      MMM: abrevia��o do nome do m�s
     MMMM: nome do m�s 
       yy: ano com 2 d�gitos
     yyyy: ano com 4 d�gitos  
                  
       hh: hora de 1 a 12
       HH: hora de 0 a 23
       mm: minutos
       ss: segundos
      fff: mil�simos de segundo 
*/
GO
--------------------------------------------------------------------------
-- 7. Dada uma data, retorna com a primeira data do m�s
CREATE FUNCTION FN_PRIM_DATA(@DT DATETIME) RETURNS DATETIME
AS BEGIN
DECLARE @ANO INT = YEAR(@DT);
DECLARE @MES INT = MONTH(@DT);

RETURN DBO.FN_MONTA_DATA(@ANO, @MES, 1);
END
GO
-- Testando
SELECT NOME, DATA_ADMISSAO, DBO.FN_PRIM_DATA(DATA_ADMISSAO)
FROM EMPREGADOS
--
---------------------------------------------------------------
-- 8. EXERC�CIO: Criar fun��o que retorna com a �LTIMA data do m�s
-- Dica: Como a data � um n�mero onde cada dia corresponde a
--       1 unidade, podemos concluir que a �ltima data de um m�s
--       � igual a primeira data do m�s seguinte menos 1
-- Dica:
SELECT CAST(GETDATE() AS FLOAT)

DECLARE @DT DATETIME;
SET @DT = '2019.6.1';
SELECT @DT - 1
GO
---------------------------------------------------------------




-- Testando
SELECT DBO.FN_ULT_DATA( '2018.1.22' )
SELECT DBO.FN_ULT_DATA( '2016.2.22' )
SELECT DBO.FN_ULT_DATA( '2018.3.22' )
SELECT DBO.FN_ULT_DATA( '2018.4.22' )
---
SELECT DBO.FN_ULT_DATA( '2018.11.22' )
SELECT DBO.FN_ULT_DATA( '2018.12.22' )

-- No Sql 2012 use
SELECT EOMONTH(GETDATE(),0)
SELECT EOMONTH(GETDATE(),1)
SELECT EOMONTH(GETDATE(),-1)
GO
--
--------------------------------------------------------
-- 9. Calcula a N-�sima data �til a partir de uma data
--------------------------------------------------------
CREATE FUNCTION FN_N_ESIMA_DATA_UTIL(@DT DATETIME, @N INT) RETURNS DATETIME
AS BEGIN
-- contador de dias �teis
DECLARE @DIAS INT = 0;
-- desconsiderar a parte da hora
SET @DT = DBO.FN_TRUNCA_DATA(@DT);
-- enquanto o contador de dias �teis for menor que a quantidade de dias
-- que queremos contar
WHILE @DIAS < @N
   BEGIN
   -- somar 1 na data
   SET @DT = @DT + 1;
   -- se for s�bado ou domingo, voltar para o in�cio do loop
   IF DATEPART(WEEKDAY, @DT) IN (1,7) CONTINUE;
   -- caso contr�rio, incrementar o contador de dias �teis
   SET @DIAS = @DIAS + 1;
   END -- WHILE
-- retornar com a data
RETURN @DT;
END
GO
-- TESTANDO
SELECT DBO.FN_N_ESIMA_DATA_UTIL( GETDATE(), 6 );

--
CREATE TABLE FERIADOS
( DATA DATETIME, 
  MOTIVO VARCHAR(40)
  CONSTRAINT PK_FERIADOS PRIMARY KEY (DATA) )
GO  
--
INSERT INTO FERIADOS VALUES ('2019.12.16','DIA DA RESSACA')


GO
----------------------------------------------------------
-- 10. EXERC�CIO: Altere a fun��o anterior de modo que sejam
--            considerados tamb�m os feriados
-- Dica: SE O DIA DA SEMANA DA DATA FOR 1 OU 7 (***)
--       OU
--       A DATA ESTIVER CADASTRADA (EXISTIR) NA TABELA FERIADOS
----------------------------------------------------------



-- Testando
SELECT DBO.FN_N_ESIMA_DATA_UTIL( GETDATE(), 6 )



