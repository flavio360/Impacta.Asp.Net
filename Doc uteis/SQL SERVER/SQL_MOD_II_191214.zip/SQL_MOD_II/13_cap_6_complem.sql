USE PEDIDOS
GO
/*
   Dado escalar: Composto de um �nico valor
   Dado tabular: Conjunto de valores organizados em linhas e colunas
*/
----------------------------------------------------
--- Devolvendo dado tabular com VIEW
----------------------------------------------------
CREATE VIEW VIE_MAIOR_PEDIDO AS
SELECT TOP 12 MONTH( DATA_EMISSAO ) AS MES,
       YEAR( DATA_EMISSAO ) AS ANO,
       MAX( VLR_TOTAL ) AS MAIOR_PEDIDO
FROM PEDIDOS
-- N�O ACEITA PAR�METRO. Trabalha somente com constantes
WHERE YEAR(DATA_EMISSAO) = 2006
GROUP BY MONTH(DATA_EMISSAO), YEAR(DATA_EMISSAO)
ORDER BY MES
GO
----------------------------------------------------
-- executa com SELECT
SELECT * FROM VIE_MAIOR_PEDIDO
-- Pode fazer ORDER BY
SELECT * FROM VIE_MAIOR_PEDIDO
ORDER BY MAIOR_PEDIDO DESC
-- Pode filtrar com WHERE
SELECT * FROM VIE_MAIOR_PEDIDO
WHERE MES > 6
-- Pode fazer JOIN
SELECT V.*, P.NUM_PEDIDO, C.NOME AS CLIENTE
FROM VIE_MAIOR_PEDIDO V JOIN PEDIDOS P
             ON V.MES = MONTH( P.DATA_EMISSAO ) AND
                V.ANO = YEAR( P.DATA_EMISSAO ) AND
                V.MAIOR_PEDIDO = P.VLR_TOTAL
     JOIN CLIENTES C ON P.CODCLI = C.CODCLI              
GO
----------------------------------------------------
--- Devolvendo dado tabular com STORED PROCEDURE
----------------------------------------------------
CREATE PROCEDURE STP_MAIOR_PEDIDO @ANO INT
AS BEGIN
SELECT MONTH( DATA_EMISSAO ) AS MES,
       YEAR( DATA_EMISSAO ) AS ANO,
       MAX( VLR_TOTAL ) AS MAIOR_PEDIDO
FROM PEDIDOS
-- Aceita par�metro. Trabalha com dados vari�veis
WHERE YEAR(DATA_EMISSAO) = @ANO
GROUP BY MONTH(DATA_EMISSAO), YEAR(DATA_EMISSAO)
ORDER BY MES
END
GO

-- executa com EXEC
-- N�o aceita ORDER BY
-- N�o aceita WHERE
-- N�o aceita JOIN, etc...
EXEC pedidos..STP_MAIOR_PEDIDO 2008
GO
----------------------------------------------------
SELECT * --INTO TAB_TEMP 
FROM OPENROWSET( 'SQLNCLI11',
  'Server=localhost;Trusted_Connection=yes',
   'EXEC pedidos..STP_MAIOR_PEDIDO 2008')

-- select * from tab_temp
----------------------------------------------------
go

----------------------------------------------------
--- Devolvendo dado tabular com FUN��O TABULAR
----------------------------------------------------
CREATE FUNCTION FN_MAIOR_PEDIDO( @ANO INT )
RETURNS TABLE
AS
RETURN ( SELECT MONTH( DATA_EMISSAO ) AS MES, 
                YEAR( DATA_EMISSAO ) AS ANO, 
                MAX( VLR_TOTAL ) AS MAIOR_VALOR
                FROM PEDIDOS
                -- Aceita par�metros. Trabalha com vari�veis
                WHERE YEAR(DATA_EMISSAO) = @ANO
                GROUP BY MONTH( DATA_EMISSAO ), 
                         YEAR( DATA_EMISSAO ) )
GO      



                   
----------------------------------------------------
-- Executa com SELECT
SELECT * FROM DBO.FN_MAIOR_PEDIDO( 2006)
ORDER BY ANO, MES
-- Aceita filtro
SELECT * FROM DBO.FN_MAIOR_PEDIDO( 2007)
WHERE MES > 6
ORDER BY ANO, MES
-- Aceita JOIN
SELECT F.MES, F.ANO, F.MAIOR_VALOR, P.NUM_PEDIDO
FROM FN_MAIOR_PEDIDO( 2006 ) F
     JOIN PEDIDOS P 
     ON F.MES = MONTH( P.DATA_EMISSAO ) AND
        F.ANO = YEAR( P.DATA_EMISSAO ) AND
        F.MAIOR_VALOR = P.VLR_TOTAL
ORDER BY F.ANO, F.MES

