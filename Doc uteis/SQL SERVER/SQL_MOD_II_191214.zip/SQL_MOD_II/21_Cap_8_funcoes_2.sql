USE PEDIDOS
---
----- Fun��es nativas para strings
--- C�digo de um dado caracter
SELECT ASCII( 'a' )
SELECT ASCII( 'B' )
SELECT ASCII( '0' )
--- Caracter que tem um determinado c�digo
SELECT CHAR(65)
--
DECLARE @COD INT;
SET @COD = 1;
WHILE @COD <= 255
   BEGIN
   PRINT CAST(@COD AS VARCHAR(3)) + ' - ' + CHAR(@COD);
   SET @COD = @COD + 1; 
   END
GO
---
--- O que faz ????
--		Param_1: ?
--		Param_2: ?
--		Retorno: ?
SELECT CHARINDEX( 'PA', 'IMPACTA' ) -- 3
SELECT CHARINDEX( 'MAGNO', 'CARLOS MAGNO' ) -- 8
SELECT CHARINDEX( 'MANO', 'CARLOS MAGNO' ) -- 0

--- Tamanho de um string
SELECT LEN( 'IMPACTA' ) 
SELECT LEN( 'IMPACTA TECNOLOGIA' )

--- O que faz?
--		Param_1: ?
--		Param_2: ?
--		Retorno: ?
SELECT LEFT( 'IMPACTA TECNOLOGIA', 5 )
SELECT LEFT( 'TREINAMENTO SQL', 3 )
SELECT LEFT( 'TREINAMENTO SQL', 6 )
--- O que faz?
--		Param_1: ?
--		Param_2: ?
--		Retorno: ?
SELECT RIGHT( 'IMPACTA TECNOLOGIA', 5 )
SELECT RIGHT( 'TREINAMENTO SQL', 3 )
SELECT RIGHT( 'TREINAMENTO SQL', 6 )

--- O que faz?
--		Param_1: ?
--		Param_2: ?
--		Param_3: ?
--		Retorno: ?
SELECT SUBSTRING( 'IMPACTA TECNOLOGIA', 5, 6 )
SELECT SUBSTRING( 'IMPACTA TECNOLOGIA', 3, 4 )
SELECT SUBSTRING( 'IMPACTA TECNOLOGIA', 10, 3 )

--- Eliminar espa�os em branco
SELECT 'IMPACTA     ' + '      TECNOLOGIA'
SELECT RTRIM('IMPACTA     ') + 'TECNOLOGIA'
SELECT 'IMPACTA' + LTRIM('      TECNOLOGIA')
SELECT RTRIM(LTRIM( '     TESTE      '))

--- O que faz?
--		Param_1: ?
--		Retorno: ?
SELECT REVERSE('IMPACTA')
SELECT REVERSE('MAGNO')
SELECT REVERSE('COMPUTADOR')

SELECT REVERSE('REVER')
SELECT REVERSE('MIRIM')
SELECT REVERSE('REVIVER')
SELECT REVERSE('OVO')
SELECT REVERSE('MUSSUM')

--- O que faz?
--		Param_1: ?
--		Param_2: ?
--		Retorno: ?
PRINT REPLICATE('IMPACTA ', 10)
PRINT REPLICATE('MAGNO', 5)

--- UPPER: O que faz?
--		Param_1: ?
--		Retorno: ?

--- LOWER: O que faz?
--		Param_1: ?
--		Retorno: ?

PRINT UPPER('impacta @#$81') + LOWER( 'TECNOLOGIA' )
-- se estivesse usando COLLATION Case Insensitive
-- deveriamos usar as fun��es UPPER/LOWER para fazer
-- busca por campos do tipo texto
SELECT * FROM EMPREGADOS WHERE upper(NOME) LIKE '%CARLOS%'
SELECT * FROM EMPREGADOS WHERE NOME LIKE '%Carlos%'
SELECT * FROM EMPREGADOS WHERE lower(NOME) LIKE '%carlos%'
SELECT * FROM EMPREGADOS WHERE NOME LIKE '%CaRloS%'

--- O que faz?
--		Param_1: ?
--		Param_2: ?
--		Param_3: ?
--		Retorno: ?
PRINT REPLACE( 'JOS�,CARLOS,ROBERTO,FERNANDO,MARCO', ',', ' - ')
GO

-- SQL 2012 ---------------------------------------------------------
--- IIF, CHOOSE
SELECT CODFUN, NOME, 
       IIF(SINDICALIZADO = 'S', 'Sim', 'N�o') AS SINDICALIZADO,
       DATA_ADMISSAO,
	   CHOOSE(DATEPART(WEEKDAY,DATA_ADMISSAO),'Domingo','Segunda','Ter�a',
	          'Quarta','Quinta','Sexta','S�bado') AS DIA_SEMANA
FROM EMPREGADOS
--- FORMAT
SELECT FORMAT(ID_PRODUTO,'0000') AS ID_PRODUTO, 
       DESCRICAO, FORMAT(PRECO_VENDA,'R$ 0.000') AS PRECO_VENDA,
	   FORMAT((PRECO_VENDA - PRECO_CUSTO) / PRECO_CUSTO,'0.0000') AS FATOR_LUCRO,
       FORMAT((PRECO_VENDA - PRECO_CUSTO) / PRECO_CUSTO,'0.00%') AS PORC_LUCRO,
	   FORMAT(QTD_REAL, '#,##0') AS QUANTIDADE
FROM PRODUTOS
WHERE PRECO_CUSTO > 0
go

---------------------------------------------------------------
-- 1. EXERC�CIO: Criar fun��o que complete um string � direita
-- Exemplo: 
--            SELECT FN_FILL_RIGHT( 'MAGNO', '.' , 10 )
--            MAGNO.....
--            SELECT FN_FILL_RIGHT( 'IMPACTA', '*' , 15 )
--            IMPACTA********
-- Par�metros:
--            @S VARCHAR(100)  : texto que ser� completado
--            @C CHAR(1)       : caracter usado para completar
--            @T TINYINT       : tamanho do texto resultante              
---------------------------------------------------------------
CREATE FUNCTION FN_FILL_RIGHT( @S VARCHAR(255), 
                               @C CHAR(1),
                               @T TINYINT )
   RETURNS VARCHAR(255)
AS BEGIN
-- Complete
RETURN @S + REPLICATE(@C, @T - LEN(@S))
END
GO
-- Testando
SELECT DBO.FN_FILL_RIGHT( 'IMPACTA', '*' , 15 )
GO

-- Exercicio: Completar o string � esquerda
CREATE FUNCTION FN_FILL_LEFT( @S VARCHAR(255), 
                               @C CHAR(1),
                               @T TINYINT )
   RETURNS VARCHAR(255)
AS BEGIN
-- Complete
RETURN REPLICATE(@C, @T - LEN(@S)) + @S;
END
GO

-- Testando
SELECT DBO.FN_FILL_LEFT(CODFUN, '0', 5), NOME FROM EMPREGADOS

SELECT DBO.FN_FILL_LEFT( 'IMPACTA', '*' , 15 )
GO

----------------------------------------------------------
-- 2. Fun��o para retornar somente com a primeira palavra 
--     de um nome
----------------------------------------------------------
CREATE FUNCTION FN_PRIM_NOME( @S VARCHAR(200) )
   RETURNS VARCHAR(200)
AS BEGIN
-- 1. declarar vari�vel de retorno e iniciar com vazio
DECLARE @RET VARCHAR(200) = '';
-- 2. eliminar os espa�os em branco � esquerda de @S
SET @S =  LTRIM(@S);
-- 3. declarar contador e iniciar com 1
DECLARE @CONT INT = 1;
-- 4. Enquanto o contador for menor ou igua a quantidade
--    de caracteres de @S
WHILE @CONT <= LEN(@S)
   BEGIN
   -- 4.1. Se o caractere que esta na posi��o @CONT
   --      de @S for um espa�o, abandonar o loop while
   IF SUBSTRING(@S, @CONT, 1) = ' ' BREAK;
   -- 4.2. Concatenar em @RET o caractere que est� na
   -- posi��o @CONT de @S
   SET @RET = @RET + SUBSTRING(@S, @CONT, 1);
   -- 4.3. incrementar o contador de 1 unidade
   SET @CONT = @CONT + 1;
   END
RETURN @RET;
END
GO
-- TESTANDO
SELECT DBO.FN_PRIM_NOME( '  CARLOS  MAGNO' )
SELECT NOME, DBO.FN_PRIM_NOME( NOME ) FROM EMPREGADOS
GO
----------------------------------------------------------
-- 3. Fun��o para retornar somente com a �ltima palavra 
--     de um nome
----------------------------------------------------------
-- Dica: O loop deve percorrer o nome da �ltima letra at� a primeira
--       Se encontrar espa�o, abandona o loop
CREATE FUNCTION FN_ULT_NOME( @S VARCHAR(200) )
   RETURNS VARCHAR(200)
AS BEGIN
-- 1. declarar vari�vel de retorno e iniciar com vazio

-- 2. eliminar os espa�os em branco � DIREITA de @S

-- 3. declarar contador e iniciar com O TAMANHO DE @S

-- 4. Enquanto o contador for MAIOR QUE ZERO

   -- 4.1. Se o caractere que esta na posi��o @CONT
   --      de @S for um espa�o, abandonar o loop while

   -- 4.2. Concatenar em @RET o caractere que est� na
   -- posi��o @CONT de @S

   -- 4.3. DEcrementar o contador de 1 unidade

-- 5. retornar com o valor

END
GO


--
SELECT DBO.FN_ULT_NOME( '  CARLOS  MAGNO   ' )
SELECT NOME, DBO.FN_ULT_NOME(NOME) FROM EMPREGADOS
GO
----------------------------------------------------------
-- 4. Fun��o para formatar nomes pr�prios com as primeiras
--     letras de cada nome em mai�sculo
----------------------------------------------------------
CREATE FUNCTION FN_PROPER( @S VARCHAR(200) )
   RETURNS VARCHAR(200)
AS BEGIN
DECLARE @RET VARCHAR(200);
DECLARE @CONT INT;
-- 1. Colocar na vari�vel @RET o primeiro caractere de @S
--    j� convertido para mai�sculo (complete)
SET @RET = UPPER( LEFT(@S,1) );
-- 2. Iniciar @CONT com 2 (complete)
SET @CONT = 2;
-- 3. Enquanto o contador for menor ou igua a quantidade
--    de caracteres de @S
WHILE @CONT <= LEN(@S)
   BEGIN
   -- 3.1. Se o caractere que estiver na posi��o @CONT - 1 
   --      for um espa�o em branco (complete)
   IF SUBSTRING( @S, @CONT-1, 1) = ' '
      -- 3.1.1 Concatenar em @RET o caractere que est� na
      -- posi��o @CONT convertido para mai�sculo
      SET @RET += UPPER( SUBSTRING( @S, @CONT, 1) )
   -- 3.2. SEN�O   
   ELSE      
      -- 3.1.1 Concatenar em @RET o caractere que est� na
      -- posi��o @CONT convertido para min�sculo
      SET @RET += LOWER( SUBSTRING( @S, @CONT, 1) )

   -- 3.3. Incrementar o contador
   SET @CONT += 1;
   END -- FECHA O WHILE
-- 4. Retornar com o resultado
RETURN @RET
END
GO
-- Testando
SELECT NOME, DBO.FN_PROPER( NOME ) FROM EMPREGADOS
----------------------------------------------------------------
SELECT * FROM EMPREGADOS WHERE NOME LIKE '%JOSE%'
SELECT * FROM EMPREGADOS WHERE NOME LIKE '%JOS�%'
GO
-----------------------------------------------------------------
-- 5. Substituir todos os caracteres acentuados de um 
-- texto pelo correspondente caracter n�o acentuado
-----------------------------------------------------------------
CREATE FUNCTION FN_TIRA_ACENTO( @S VARCHAR(200) )
  RETURNS VARCHAR( 200 )
AS BEGIN
DECLARE @I INT, @RET VARCHAR(200), @C CHAR(1);
SET @I = 1;
SET @RET = '';
-- Enquanto @I for menor que o tamanho de @S
WHILE @I <= LEN(@S)
   BEGIN
   SET @C = SUBSTRING( @S, @I, 1 );
   SET @RET = @RET + CASE 
                     --WHEN @C IN ('�','�','�','�') THEN 'A'  
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'A'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'a'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'E'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'e'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'), ASCII('�'),ASCII('�')) THEN 'I'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'i'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'O'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'o'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�')) THEN 'U'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�')) THEN 'u'
					   WHEN ASCII(@C) = ASCII('�') THEN 'N'
					   WHEN ASCII(@C) = ASCII('�') THEN 'n'
                       WHEN ASCII(@C) = ASCII('�') THEN 'C'
                       WHEN ASCII(@C) = ASCII('�') THEN 'c'
                       ELSE @C
                     END -- CASE   
    SET @I = @I + 1 
    END  
RETURN (@RET);
END
GO
---
SELECT NOME FROM EMPREGADOS
WHERE DBO.FN_TIRA_ACENTO( NOME ) LIKE '%JOSE%'

SELECT NOME FROM EMPREGADOS
WHERE DBO.FN_TIRA_ACENTO( NOME ) LIKE '%JOAO%'
GO
-------------------------------------------------------
-- 6. Criar fun��o FN_SO_NUMEROS, que recebe um VARCHAR
--    e retorna outro VARCHAR contendo apenas os caracteres
--    num�ricos do string recebido. �til para retirar a 
--    pontua��o de dados como CPF e CNPJ 
CREATE FUNCTION FN_SO_NUMEROS(@S VARCHAR(200)) RETURNS VARCHAR(200)
AS BEGIN
DECLARE @RET VARCHAR(200) = '';
DECLARE @CONT INT = 1;
-- complete --------------------------------------------

--------------------------------------------------------
RETURN @RET;
END
GO
---- TESTANDO
SELECT NOME, INSCRICAO, DBO.FN_SO_NUMEROS(INSCRICAO)
FROM CLIENTES;
GO

-- 7. Validar CPF ou CNPJ
CREATE FUNCTION [dbo].[FN_ValidaCpfCnpj] (@CPF_CNPJ VARCHAR(20))
RETURNS BIT
AS
BEGIN
    SET @CPF_CNPJ = DBO.FN_SO_NUMEROS(@CPF_CNPJ);
    DECLARE
        @I INT,
        @J INT = 1,
        @N INT = LEN(@CPF_CNPJ),
        @DIGITO1 INT = SUBSTRING(@CPF_CNPJ, LEN(@CPF_CNPJ) - 1, 1),
        @DIGITO2 INT = SUBSTRING(@CPF_CNPJ, LEN(@CPF_CNPJ), 1),
        @TOTAL_TMP INT,
        @COEFICIENTE_TMP INT,
        @DIGITO_TMP INT,
        @VALOR_TMP INT,
        @VALOR1 INT,
        @VALOR2 INT
  
    WHILE @J <= 2
    BEGIN
        SELECT
            @TOTAL_TMP = 0,
            @COEFICIENTE_TMP = 2,
            @I = @N + @J - 3
     
        WHILE @I >= 0
        BEGIN
            SELECT
                @DIGITO_TMP = SUBSTRING(@CPF_CNPJ, @I, 1),
                @TOTAL_TMP += @DIGITO_TMP * @COEFICIENTE_TMP,
                @COEFICIENTE_TMP = @COEFICIENTE_TMP + 1,
                @I -= 1
  
            IF @COEFICIENTE_TMP > 9 AND @N = 14
                SET @COEFICIENTE_TMP = 2
        END
  
        SET @VALOR_TMP = 11 - (@TOTAL_TMP % 11)
  
        IF (@VALOR_TMP >= 10)
            SET @VALOR_TMP = 0
  
        IF @J = 1
            SET @VALOR1 = @VALOR_TMP
        ELSE
            SET @VALOR2 = @VALOR_TMP
 
        SET @J += 1
    END
  
    RETURN
        CASE WHEN @VALOR1 = @DIGITO1 AND @VALOR2 = @DIGITO2
            THEN 1
            ELSE 0
        END
END   
GO
---- TESTANDO
SELECT DBO.FN_ValidaCpfCnpj('65564296000119')
SELECT DBO.FN_ValidaCpfCnpj('65.564.296/0001-19')

SELECT NOME, CNPJ, DBO.FN_ValidaCpfCnpj(CNPJ) AS [� V�LIDO]
FROM CLIENTES