-- EXERC�CIOS ADICIONAIS
/*
	OBSERVA��ES IMPORTANTE

	
	1. Uma VIEW n�o pode gerar 2 campos com o mesmo nome
	2. Um campo calculado gerado por uma VIEW tem que ter nome
	3. Uma view com SCHEMABINDING n�o pode usar "*" para trazer todos os campos
	4. Uma view com SCHEMABINDING precisa colocar "dbo." antes de cada tabela
		CREATE VIEW VIE_EMP6
			WITH ENCRYPTION, SCHEMABINDING
		AS
			SELECT CODFUN, NOME, DATA_ADMISSAO, 
			COD_DEPTO, COD_CARGO, SALARIO,
			SALARIO + PREMIO_MENSAL AS RENDA_MES
		FROM DBO.EMPREGADOS	
*/
USE PEDIDOS;
GO
-- 1. Criar VIEW (VIE_TOTAL_VENDIDO) para mostrar o total vendido (soma de PEDIDOS.VLR_TOTAL)
-- em cada m�s do ano. Deve mostrar o m�s, o ano e o total vendido ORDENADo por ANO, MES
-- O c�digo fonte deve ser protegido contra consulta de outras pessoas

SELECT MONTH( DATA_EMISSAO ),
       YEAR( DATA_EMISSAO ),
       SUM( VLR_TOTAL )
FROM PEDIDOS
GROUP BY MONTH(DATA_EMISSAO), YEAR(DATA_EMISSAO)
ORDER BY 2,1
GO

--- TESTANDO
SELECT * FROM VIE_TOTAL_VENDIDO
WHERE ANO = 2006
GO
-- 2. Criar VIEW (VIE_MENOR_PEDIDO) para mostrar valor do menor pedido (MIN de PEDIDOS.VLR_TOTAL)
-- vendido em cada m�s do ano. Deve mostrar o m�s, o ano e menor pedido e ordenar
-- os dados por ANO e MES


GO

--- TESTANDO
SELECT * FROM VIE_MENOR_PEDIDO WHERE ANO = 2006
GO
-- 3. Criar uma VIEW (VIE_PRODUTOS)que mostre todos os campos da tabela PRODUTOS
--    e tamb�m os campos TIPO de TIPOPRODUTO e UNIDADE de UNIDADES.
--    Crie uma depend�ncia que impe�a a altera��o de estrutura das 
--    tabelas usadas pela VIEW
SELECT 
  PR.* ,  T.TIPO, U.UNIDADE
FROM PRODUTOS PR 
     JOIN TIPOPRODUTO T ON PR.COD_TIPO = T.COD_TIPO
	 JOIN UNIDADES U ON PR.COD_UNIDADE = U.COD_UNIDADE
GO
---- TESTANDO
SELECT * FROM VIE_PRODUTOS
GO
-- 4. Criar uma VIEW (VIE_ITENS_PEDIDO) que mostre todos os campos da tabela ITENSPEDIDO mais
--    DATA_EMISSAO do pedido, NOME do cliente que comprou e NOME do 
--    vendedor que vendeu. 
--    Crie uma depend�ncia que impe�a a altera��o de estrutura das 
--    tabelas usadas pela VIEW
SELECT 
  I.*, Pe.DATA_EMISSAO, C.NOME, V.NOME
FROM ITENSPEDIDO I
  JOIN PEDIDOS Pe ON I.NUM_PEDIDO = Pe.NUM_PEDIDO
  JOIN CLIENTES C ON Pe.CODCLI = C.CODCLI
  JOIN VENDEDORES V ON Pe.CODVEN = V.CODVEN
GO
--- TESTANDO
SELECT * FROM VIE_ITENS_PEDIDO
GO
-- 5. Criar uma VIEW que mostre todos os campos de VIE_ITENS_PEDIDO
--    e tambem todos os campos da tabela PRODUTOS seguidos de
--    TIPOPRODUTO.TIPO e UNIDADES.UNIDADE (VIE_PRODUTOS)
-- fazer join entre VIE_ITENS_PEDIDO e VIE_PRODUTO


GO
--- TESTANDO
SELECT * FROM VIE_ITENS_PRODUTOS
GO
-- 6. Criar uma VIEW que mostre os seguintes campos:
      -- COD_FORNECEDOR, NOME, CNPJ, FONE1, FONE2 e E_MAIL de FORNECEDORES
      -- Todos os campos da tabela PRODUTOS incluindo
      -- os campos TIPO de TIPOPRODUTO e UNIDADE de UNIDADES.
	  -- Proteja o c�digo fonte desta VIEW para que ningu�m possa
	  -- consult�-lo


GO

--- TESTANDO
SELECT * FROM VIE_FORNECEDORES_PRODUTOS
go
-- 7. Altere a VIEW VIE_ITENS_PEDIDO incluindo nela o campo VALOR que ser� calculado
--    I.QUANTIDADE * I.PR_UNITARIO * (1 - I.DESCONTO / 100)
ALTER VIEW VIE_ITENS_PEDIDO WITH SCHEMABINDING AS
SELECT 
  -- N�o pode usar *
  -- I.*, 
  I.NUM_PEDIDO, I.NUM_ITEM, I.ID_PRODUTO, I.COD_PRODUTO, I.CODCOR, 
  I.QUANTIDADE, I.PR_UNITARIO, I.DATA_ENTREGA, I.SITUACAO, I.DESCONTO,
  Pe.DATA_EMISSAO, 
  -- n�o pode gerar 2 colunas com o mesmo nome
  C.NOME AS CLIENTE, V.NOME AS VENDEDOR,
  I.QUANTIDADE * I.PR_UNITARIO * (1 - I.DESCONTO / 100) AS VALOR
-- tem que colocar o schema antes de cada tabela (dbo.)
FROM dbo.ITENSPEDIDO I
  JOIN dbo.PEDIDOS Pe ON I.NUM_PEDIDO = Pe.NUM_PEDIDO
  JOIN dbo.CLIENTES C ON Pe.CODCLI = C.CODCLI
  JOIN dbo.VENDEDORES V ON Pe.CODVEN = V.CODVEN
GO

-- 7.1. Crie para VIE_ITENS_PEDIDO, um �ndice que ordene pelo campo VALOR
-- �ndice chave prim�ria (NUM_PEDIDO, NUM_ITEM)
CREATE UNIQUE CLUSTERED INDEX IX_VIE_ITENS_PEDIDO_PK
                     ON VIE_ITENS_PEDIDO(NUM_PEDIDO, NUM_ITEM)

-- �ndice pela coluna VALOR
CREATE INDEX IX_VIE_ITENS_PEDIDO_VALOR ON VIE_ITENS_PEDIDO(VALOR)





