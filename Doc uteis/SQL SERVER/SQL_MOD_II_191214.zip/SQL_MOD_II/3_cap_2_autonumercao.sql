--==============================================================================
-- Fun��es associadas a IDENTITY - Cap 2 - P�G 50
--------------------------------------------
-- Criar banco de dados de teste
CREATE DATABASE TESTE_IDENTITY
GO
-- Colocar o banco de dados em uso
USE TESTE_IDENTITY
GO
-- Criar tabela PROFESSOR com campo identidade iniciando em 1 e incrementando 1
CREATE TABLE PROFESSOR
( COD_PROF		INT IDENTITY,
  NOME			VARCHAR(30)
  CONSTRAINT PK_PROFESSOR PRIMARY KEY (COD_PROF) )
GO
-- Criar tabela ALUNO com campo identidade iniciando em 10 e incrementando 2
CREATE TABLE ALUNO
( COD_ALUNO		INT IDENTITY(10,2),
  NOME			VARCHAR(30)
  CONSTRAINT PK_ALUNO PRIMARY KEY (COD_ALUNO) );
GO  
/*
    -- DECLARATIVO
	INSERT INTO <nomeTabela> (<lista de campos>)
	VALUES (<lista de valores na mesma ordem da lista de campos>)

	-- OU

	-- POSICIONAL
	INSERT INTO <nomeTabela>
	VALUES (<lista de valores com TODOS os campos na ordem do create table>)
    
	*** em qualquer dos dois casos, VALUES pode ser substituido por
	    um comando SELECT
*/

-- Inserir dados na tabela PROFESSOR
INSERT PROFESSOR (NOME)
VALUES ('MAGNO'),('AGNALDO'),('ROBERTO'),
       ('RENATA'),('EDUARDO'),('MARCIO');

-- Inserir dados na tabela ALUNO
INSERT ALUNO VALUES ('Z� DA SILVA'),('CARLOS P. D. KANA'),
                    ('ITAMAR E VAI PIORAR');
-- Consultar as tabelas
SELECT * FROM PROFESSOR;
SELECT * FROM ALUNO;

-- Criar tabela chamada MATERIAS com os campos
/*
 COD_MATERIA inteiro auto numera��o
              deve come�ar do 100 somando 5
 MATERIA      alfanumerico tamanho 30
 CARGA_HORARIA inteiro
*/
-- COMPLETE
CREATE TABLE MATERIAS
(
	COD_MATERIA			INT			IDENTITY(100,5),
	MATERIA				VARCHAR(30),
	CARGA_HORARIA		INT
	CONSTRAINT PK_MATERIAS	PRIMARY KEY (COD_MATERIA)
)
-- Inserir 5 linhas na tabela MATERIAS
-- COMPLETE
INSERT INTO MATERIAS (MATERIA, CARGA_HORARIA)
VALUES ('PORTUGU�S', 40), ('MATEM�TICA', 40), ('F�SICA', 40), 
       ('GEOGRAFIA', 20), ('HIST�RIA', 20)

-- Consultar a tabela MATERIAS
-- COMPLETE
SELECT * FROM MATERIAS


         
-- Excluir o professor C�digo 2
DELETE FROM PROFESSOR WHERE COD_PROF = 2;
-- Consultar
SELECT * FROM PROFESSOR;

-- LIGA a possibilidade de inserir dados no campo IDENTITY
SET IDENTITY_INSERT PROFESSOR ON;
-- OBS.: N�o aceita INSERT posicional
--       TEM QUE SER INSERT DECLARATIVO
INSERT PROFESSOR (COD_PROF, NOME)
VALUES (2,'GODOFREDO');
-- DESLIGA possibilidade de inserir dados no campo IDENTITY
SET IDENTITY_INSERT PROFESSOR OFF;
-- N�o podemos ter 2 tabelas com IDENTITY_INSERT ON simultaneamente

-- Consulta
SELECT * FROM PROFESSOR;

-- Qual � a coluna IDENTITY da tabela ?
SELECT IDENTITYCOL FROM PROFESSOR;
SELECT IDENTITYCOL FROM ALUNO;

-- tabela de sistema que contem todos os campos identidade
-- existentes no banco de dados
SELECT * FROM SYS.identity_columns
WHERE OBJECT_ID = OBJECT_ID('MATERIAS')

-- Qual � o valor inicial do IDENTITY?
SELECT IDENT_SEED('PROFESSOR');
SELECT IDENT_SEED('ALUNO');
-- Qual � o incremento do IDENTITY ?
SELECT IDENT_INCR('PROFESSOR');
SELECT IDENT_INCR('ALUNO');

-- Qual foi o �ltimo valor de IDENTITY gerado
-- pelo SQL para o usu�rio atual ?
SELECT @@IDENTITY;
INSERT PROFESSOR VALUES ('XXXX');
SELECT @@IDENTITY;
INSERT ALUNO VALUES ('XXXX');
SELECT @@IDENTITY;
-- Esta fun��o deve ser utilizada pelos aplicativos que 
-- precisarem saber qual foi o c�digo gerado para o �ltimo
-- INSERT executado.

-- Qual foi o �ltimo valor de IDENTITY gerado
-- pelo SQL para o usu�rio atual ?
SELECT SCOPE_IDENTITY();
INSERT ALUNO VALUES ('TESTE');
SELECT SCOPE_IDENTITY();
-- Esta fun��o "N�O PODE" (mas pode) ser utilizada pelos aplicativos porque
-- neles ela retorna sempre NULL. 
-- Ela deve ser utilizada dentro de stored procedures e triggers
-- do banco de dados quando for necess�rio saber qual foi o c�digo 
-- gerado para o �ltimo INSERT executado executado dentro da procedure
-- ou do trigger.
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'TR'
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'U'
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'PK'
SELECT * FROM SYS.OBJECTS 
/*
                           |  DELETE
                           |
TABELA ---------> TRIGGER -   INSERT 
                           |
						   |  UPDATE 


TABELA1 (tem trigger de insert)

                             | dispara o trigger
INSERT INTO TABELA1... ----->| que executa
SELECT @@IDENTITY **         | INSERT INTO TABELA2
select scope_identity()

*/


-- Qual foi o �ltimo valor de IDENTITY gerado
-- para uma determinada tabela
SELECT IDENT_CURRENT('PROFESSOR');
SELECT IDENT_CURRENT('ALUNO');

-- Excluir todos os registros da tabela PROFESSOR
DELETE FROM PROFESSOR;
-- "zera" o contador do IDENTITY
TRUNCATE TABLE PROFESSOR

-- Inserir um novo registro
INSERT INTO PROFESSOR VALUES ('MAGNO');
-- Consultar
SELECT * FROM PROFESSOR;
/*
   Observe que o c�digo gerado seguiu a mesma sequ�ncia anterior
*/

-- Exclua novamente os registros da tabela PROFESSOR
DELETE FROM PROFESSOR;
-- "Zerar" o contador do IDENTITY
DBCC CHECKIDENT( 'PROFESSOR', RESEED, 49 );

-- Inserir novos dados
INSERT PROFESSOR VALUES ('MAGNO'),('AGNALDO'),('ROBERTO'),
                        ('RENATA'),('EDUARDO'),('MARCIO');
-- Consultar
SELECT * FROM PROFESSOR

-- N�O RESPEITA TRANSA��O
BEGIN TRAN

INSERT PROFESSOR VALUES ('MAGNO'),('AGNALDO'),('ROBERTO'),
                        ('RENATA'),('EDUARDO'),('MARCIO');

SELECT * FROM PROFESSOR

ROLLBACK

INSERT PROFESSOR VALUES ('CARLOS')

SELECT * FROM PROFESSOR


------------------------------------------- USANDO SEQUENCE (SOMENTE SQL 2012) Cap 3 - 104
DROP TABLE PROFESSOR
DROP TABLE ALUNO

-- cria um contador com valor inicial 1 e incremento 1
CREATE SEQUENCE SEQ_PROFESSOR START WITH 1 INCREMENT BY 1
-- cria um contador com valor inicial 10 e incremento 2
CREATE SEQUENCE SEQ_ALUNO START WITH 10 INCREMENT BY 2
--**** NOTE QUE NO COMANDO QUE CRIA A SEQU�NCIA N�O EXISTE QUALQUER REFER�NCIA A UMA TABELA

-- consutando as sequences existentes no banco
SELECT * FROM SYS.SEQUENCES                        

-- criar a tabela
--**** NOTE QUE NO COMANDO QUE CRIA A TABELA N�O EXISTE QUALQUER REFER�NCIA � SEQU�NCIA
CREATE TABLE PROFESSOR 
( COD_PROF		INT,
  NOME_PROF     VARCHAR(30),
  CPF			CHAR(11) NOT NULL
  CONSTRAINT PK_PROFESSOR PRIMARY KEY (COD_PROF))

-- constraint para impedir duplicidade de CPF
ALTER TABLE PROFESSOR ADD CONSTRAINT UQ_PROFESSOR_CPF UNIQUE(CPF)

-- inserindo dados na tabela
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, -- pega o valor da sequ�ncia e incrementa
       'JOS� CARLOS', '11111111111')
-- consultado a tabela
SELECT * FROM PROFESSOR

-- inserindo dados na tabela
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, 
       'CARLOS MAGNO', '22222222222')
-- consultado a tabela
SELECT * FROM PROFESSOR

-- inserindo dados na tabela
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, 
       'MARIA LUIZA', '33333333333')
-- consultado a tabela
SELECT * FROM PROFESSOR

-- isso � permitido, mas vai deixar a sequ�ncia desatualizada
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (4, 'PEDRO PAULO', '44444444444')
-- consultado a tabela
SELECT * FROM PROFESSOR
-- observe que a sequ�ncia N�O foi incrementada
SELECT NAME, START_VALUE, INCREMENT, CURRENT_VALUE FROM SYS.sequences


-- se for usar NEXT VALUE agora, vai dar erro de viola��o de PK
-- MAS VAI INCREMENTAR A SEQU�NCIA
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, 
       'Z� ROSCA', '55555555555')

-- mas o SQL j� incrementou a sequ�ncia
SELECT NAME, START_VALUE, INCREMENT, CURRENT_VALUE FROM SYS.sequences
-- se executar o insert novamente, vai funcionar
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, -- soma increment em current_value e retorna o resultado
       'Z� ROSCA', '53335')
-- consultar a tabela
SELECT * FROM PROFESSOR

-- for�ando um erro de viola��o de chave �nica
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, 
       'Z� PARAFUSO', '44444444444')
-- consultar a tabela (N�O INSERIU)
SELECT * FROM PROFESSOR

-- observe que mesmo com o erro a sequ�ncia foi incrementada
SELECT NAME, START_VALUE, INCREMENT, CURRENT_VALUE FROM SYS.sequences

-- o pr�ximo INSERT vai pular 1 n�mero na sequ�ncia
-- porque sequ�ncia n�o respeita processo de transa��o
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, -- soma increment em current_value e retorna o resultado
       'Z� PARAFUSO', '66666666666')
--
SELECT * FROM PROFESSOR

-- abrir transa��o expl�cita 
BEGIN TRAN
-- inserindo dados na tabela
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, 
       'JOS� CARLOS', '77777777777')
-- descartar a transa��o
ROLLBACK

-- inserir novamente
INSERT INTO PROFESSOR (COD_PROF, NOME_PROF, CPF)
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, 
       'JOS� CARLOS', '77777777777')
-- veja que pulou a sequ�ncia novamente
SELECT * FROM PROFESSOR

-- Erro �ltimo par�grafo da p�g 104
----------------------
-- podemos fazer UPDATE no campo auto-numera��o
UPDATE PROFESSOR SET COD_PROF = 20 WHERE COD_PROF = 2

SELECT * FROM PROFESSOR

-- alterar o valor do contador
ALTER SEQUENCE SEQ_PROFESSOR RESTART WITH 100

INSERT INTO PROFESSOR 
VALUES (NEXT VALUE FOR SEQ_PROFESSOR, -- retorna o valor atual e depois incrementa
       'ROBERTO', '88888888888')

SELECT * FROM PROFESSOR


