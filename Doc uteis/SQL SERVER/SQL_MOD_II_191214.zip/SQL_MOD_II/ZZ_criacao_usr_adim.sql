DECLARE @MAQ VARCHAR(200) = HOST_NAME();
DECLARE @COMANDO VARCHAR(1000);
SET @COMANDO = 'CREATE LOGIN ['+@MAQ+'\Administrator] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]';
EXEC(@COMANDO);
SET @COMANDO = 'exec sp_addsrvrolemember '''+@MAQ+'\Administrator'',sysadmin;'
EXEC ( @COMANDO );
