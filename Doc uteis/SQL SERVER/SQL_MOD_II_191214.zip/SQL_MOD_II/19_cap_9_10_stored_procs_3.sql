--=========================================================================
USE PEDIDOS
GO
-------------------------------------------------------------------
-- 1.  Criar procedure para efetuar a c�pia de um produto existente
--     Ela recebe como par�metro a vari�vel @ID_PRODUTO_FONTE INT,
--     gera um produto novo fazendo uma c�pia do existente e 
--     returna com o ID_PRODUTO do novo produto que foi criado.
CREATE PROCEDURE STP_COPIA_PRODUTO @ID_PRODUTO_FONTE INT
AS BEGIN
-- inserir na tabela produtos uma c�pia do produto j� existente

INSERT INTO PRODUTOS (COD_PRODUTO, DESCRICAO, COD_UNIDADE, COD_TIPO, PRECO_CUSTO, PRECO_VENDA, QTD_ESTIMADA, QTD_REAL, QTD_MINIMA, CLAS_FISC, IPI, PESO_LIQ)
SELECT COD_PRODUTO, DESCRICAO, COD_UNIDADE, COD_TIPO, PRECO_CUSTO, PRECO_VENDA, QTD_ESTIMADA, QTD_REAL, QTD_MINIMA, CLAS_FISC, IPI, PESO_LIQ
FROM PRODUTOS WHERE ID_PRODUTO = @ID_PRODUTO_FONTE;
-- descobrir qual foi o novo ID_PRODUTO gerado
DECLARE @ID_PRODUTO_NOVO INT = SCOPE_IDENTITY();
-- se existissem outras tabelas armazenando dados do produto
-- os outros INSERTS viriam aqui
-- ...

-- retornar com o novo ID_PRODUTO gerado
SELECT @ID_PRODUTO_NOVO AS ID_PRODUTO_NOVO;
END
GO
-- TESTANDO
SELECT * FROM PRODUTOS ORDER BY ID_PRODUTO DESC

EXEC STP_COPIA_PRODUTO 1
GO


SELECT * FROM PEDIDOS where num_pedido <= 10
SELECT * FROM ITENSPEDIDO where num_pedido <= 10
go
-------------------------------------------------------------------
-- 2. Criar uma procedure que gere a c�pia de um pedido (tabela
--     PEDIDOS e ITENSPEDIDO). A procedure recebe o n�mero do pedido q
--     que ser� copiado, efetua a c�pia nas 2 tabelas, PEDIDOS e
--     ITENSPEDIDO e retorna com n�mero do pedido que foi gerado.
CREATE PROCEDURE STP_COPIA_PEDIDO @NUM_PEDIDO_FONTE INT
AS BEGIN
-- fazer SELECT do pedido com NUM_PEDIDO = @NUM_PEDIDO_FONTE e
-- inserir na pr�pria tabela PEDIDOS o resultado desse SELECT
-- SEM O CAMPO NUM_PEDIDO que � IDENTITY
INSERT INTO PEDIDOS (CODCLI, CODVEN, DATA_EMISSAO, VLR_TOTAL, 
                     SITUACAO, OBSERVACOES )
SELECT CODCLI, CODVEN, GETDATE(), VLR_TOTAL, 
       'P', OBSERVACOES
FROM PEDIDOS WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;

-- descobrir o NUM_PEDIDO gerado pelo insert e armazenar na 
-- vari�vel @NUM_PEDIDO_NOVO
DECLARE @NUM_PEDIDO_NOVO INT = SCOPE_IDENTITY();

-- fazer SELECT dos itens do pedido (ITENSPEDIDO) com 
-- NUM_PEDIDO = @NUM_PEDIDO_FONTE. Inserir o resultado desse SELECT
-- na pr�pria tabela ITENSPEDIDO, mas com NUM_PEDIDO = @NUM_PEDIDO_NOVO
INSERT INTO ITENSPEDIDO (NUM_PEDIDO, NUM_ITEM, ID_PRODUTO, 
    COD_PRODUTO, CODCOR, QUANTIDADE, PR_UNITARIO, DATA_ENTREGA, 
	SITUACAO, DESCONTO )
SELECT @NUM_PEDIDO_NOVO, NUM_ITEM, ID_PRODUTO, 
    COD_PRODUTO, CODCOR, QUANTIDADE, 
	
	  (SELECT PRECO_VENDA FROM PRODUTOS
	   WHERE ID_PRODUTO = ITENSPEDIDO.ID_PRODUTO)
	
	, GETDATE() + 10, 
	'P', DESCONTO
FROM ITENSPEDIDO
WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;

-- retornar SELECT com @NUM_PEDIDO_NOVO
SELECT @NUM_PEDIDO_NOVO AS NUM_PEDIDO_NOVO;

END
GO

SELECT * FROM ITENSPEDIDO WHERE NUM_PEDIDO = 5137

UPDATE PRODUTOS SET PRECO_VENDA = 2
WHERE ID_PRODUTO = 3
--- testando
EXEC STP_COPIA_PEDIDO 5136

SELECT * FROM PEDIDOS ORDER BY NUM_PEDIDO DESC
SELECT * FROM ITENSPEDIDO ORDER BY NUM_PEDIDO DESC

-- Essa constraint impede cadastrar um item de pedido com quantidade <= 0
ALTER TABLE ITENSPEDIDO WITH NOCHECK
ADD CONSTRAINT CH_ITENSPEDIDO_QUANTIDADE
CHECK( QUANTIDADE > 0 )
--
EXEC STP_COPIA_PEDIDO 999
GO

SELECT * FROM ITENSPEDIDO WHERE NUM_PEDIDO = 999
GO
--=========================================================
-- 2.1. Tratamento de erro vers�o 1 - @@ERROR (SQL 2000)
ALTER PROCEDURE STP_COPIA_PEDIDO @NUM_PEDIDO_FONTE INT
AS BEGIN

-- abrir transa��o
BEGIN TRAN;

-- fazer SELECT do pedido com NUM_PEDIDO = @NUM_PEDIDO_FONTE e
-- inserir na pr�pria tabela PEDIDOS o resultado desse SELECT
-- SEM O CAMPO NUM_PEDIDO que � IDENTITY
INSERT INTO PEDIDOS (CODCLI, CODVEN, DATA_EMISSAO, VLR_TOTAL, 
                     SITUACAO, OBSERVACOES )
SELECT CODCLI, CODVEN, GETDATE(), VLR_TOTAL, 
       'P', OBSERVACOES
FROM PEDIDOS WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;
-- logo ap�s cada comando que altere dados (e possa provocar erro)
IF @@ERROR <> 0
   BEGIN
   ROLLBACK;
   RETURN;
   END

-- descobrir o NUM_PEDIDO gerado pelo insert e armazenar na 
-- vari�vel @NUM_PEDIDO_NOVO
DECLARE @NUM_PEDIDO_NOVO INT = SCOPE_IDENTITY();

-- fazer SELECT dos itens do pedido (ITENSPEDIDO) com 
-- NUM_PEDIDO = @NUM_PEDIDO_FONTE. Inserir o resultado desse SELECT
-- na pr�pria tabela ITENSPEDIDO, mas com NUM_PEDIDO = @NUM_PEDIDO_NOVO
INSERT INTO ITENSPEDIDO (NUM_PEDIDO, NUM_ITEM, ID_PRODUTO, 
    COD_PRODUTO, CODCOR, QUANTIDADE, PR_UNITARIO, DATA_ENTREGA, 
	SITUACAO, DESCONTO )
SELECT @NUM_PEDIDO_NOVO, NUM_ITEM, ID_PRODUTO, 
    COD_PRODUTO, CODCOR, QUANTIDADE, 
	
	  (SELECT PRECO_VENDA FROM PRODUTOS
	   WHERE ID_PRODUTO = ITENSPEDIDO.ID_PRODUTO)
	
	, GETDATE() + 10, 
	'P', DESCONTO
FROM ITENSPEDIDO
WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;
-- logo ap�s cada comando que altere dados (e possa provocar erro)
IF @@ERROR <> 0
   BEGIN
   ROLLBACK;
   RETURN;
   END

-- retornar SELECT com @NUM_PEDIDO_NOVO
SELECT @NUM_PEDIDO_NOVO AS NUM_PEDIDO_NOVO;
-- confirmar as alter��es
COMMIT;
END
GO


-- TESTANDO
SELECT * FROM PEDIDOS ORDER BY NUM_PEDIDO DESC
SELECT * FROM ITENSPEDIDO ORDER BY NUM_PEDIDO DESC

EXEC STP_COPIA_PEDIDO 5136

EXEC STP_COPIA_PEDIDO 999
GO
--=========================================================
-- 2.2. Tratamento de erro vers�o 2 - TRY...CATCH (2005)
--------------------
ALTER PROCEDURE STP_COPIA_PEDIDO @NUM_PEDIDO_FONTE INT
AS BEGIN

-- abrir transa��o
BEGIN TRAN;

-- abre bloco de comandos protegidos de erro
BEGIN TRY

    IF NOT EXISTS(SELECT NUM_PEDIDO FROM PEDIDOS
	              WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE)
	   RAISERROR('PEDIDO N�O EXISTE', 16, 1); 

	-- fazer SELECT do pedido com NUM_PEDIDO = @NUM_PEDIDO_FONTE e
	-- inserir na pr�pria tabela PEDIDOS o resultado desse SELECT
	-- SEM O CAMPO NUM_PEDIDO que � IDENTITY
	INSERT INTO PEDIDOS (CODCLI, CODVEN, DATA_EMISSAO, VLR_TOTAL, 
						 SITUACAO, OBSERVACOES )
	SELECT CODCLI, CODVEN, GETDATE(), VLR_TOTAL, 
		   'P', OBSERVACOES
	FROM PEDIDOS WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;

	-- descobrir o NUM_PEDIDO gerado pelo insert e armazenar na 
	-- vari�vel @NUM_PEDIDO_NOVO
	DECLARE @NUM_PEDIDO_NOVO INT = SCOPE_IDENTITY();

	-- fazer SELECT dos itens do pedido (ITENSPEDIDO) com 
	-- NUM_PEDIDO = @NUM_PEDIDO_FONTE. Inserir o resultado desse SELECT
	-- na pr�pria tabela ITENSPEDIDO, mas com NUM_PEDIDO = @NUM_PEDIDO_NOVO
	INSERT INTO ITENSPEDIDO (NUM_PEDIDO, NUM_ITEM, ID_PRODUTO, 
		COD_PRODUTO, CODCOR, QUANTIDADE, PR_UNITARIO, DATA_ENTREGA, 
		SITUACAO, DESCONTO )
	SELECT @NUM_PEDIDO_NOVO, NUM_ITEM, ID_PRODUTO, 
		COD_PRODUTO, CODCOR, QUANTIDADE, 
	
		  (SELECT PRECO_VENDA FROM PRODUTOS
		   WHERE ID_PRODUTO = ITENSPEDIDO.ID_PRODUTO)
	
		, GETDATE() + 10, 
		'P', DESCONTO
	FROM ITENSPEDIDO
	WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;

	-- retornar SELECT com @NUM_PEDIDO_NOVO
	SELECT @NUM_PEDIDO_NOVO AS NUM_PEDIDO_NOVO,
	       'SUCESSO' AS ERRO_MSG,
		    0 AS ERRO_COD;
	-- confirmar transa��o
	COMMIT;
END TRY -- fecha bloco de comandos protegidos
-- abrir bloco de tratamento de erro
BEGIN CATCH
	ROLLBACK;
	SELECT -1 AS NUM_PEDIDO_NOVO,
	        ERROR_MESSAGE() AS ERRO_MSG,
			ERROR_NUMBER() AS ERRO_COD;
END CATCH

END
GO


/*
	...
	string msg = ....
	if msg.Contanis("CH_ITENSPEDIDO_QUANTIDADE")
	   msg = "A quantidade do pedido original n�o est� correta";
*/

-----------------
EXEC STP_COPIA_PEDIDO 9999
EXEC STP_COPIA_PEDIDO 999

--- PEDIDO N�O EXISTE
EXEC STP_COPIA_PEDIDO 9999999
-- testando
SELECT * FROM PEDIDOS ORDER BY NUM_PEDIDO DESC
SELECT * FROM ITENSPEDIDO ORDER BY NUM_PEDIDO DESC

GO
--------------------------------------------------------------
-- 2.3. Criar uma nova procedure STP_COPIA_PEDIDO_P, mas que invez de 
--    retornar SELECT, retorne par�metros de OUTPUT
CREATE PROCEDURE STP_COPIA_PEDIDO_P @NUM_PEDIDO_FONTE INT,
                                    @ERRO_MSG VARCHAR(1000) OUTPUT,
									@ERRO_COD INT OUTPUT,
									@NUM_PEDIDO_NOVO INT OUTPUT
AS BEGIN

-- abrir transa��o
BEGIN TRAN;

-- abre bloco de comandos protegidos de erro
BEGIN TRY

    IF NOT EXISTS(SELECT NUM_PEDIDO FROM PEDIDOS
	              WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE)
	   RAISERROR('PEDIDO N�O EXISTE', 16, 1); 

	-- fazer SELECT do pedido com NUM_PEDIDO = @NUM_PEDIDO_FONTE e
	-- inserir na pr�pria tabela PEDIDOS o resultado desse SELECT
	-- SEM O CAMPO NUM_PEDIDO que � IDENTITY
	INSERT INTO PEDIDOS (CODCLI, CODVEN, DATA_EMISSAO, VLR_TOTAL, 
						 SITUACAO, OBSERVACOES )
	SELECT CODCLI, CODVEN, GETDATE(), VLR_TOTAL, 
		   'P', OBSERVACOES
	FROM PEDIDOS WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;

	-- descobrir o NUM_PEDIDO gerado pelo insert e armazenar na 
	-- vari�vel @NUM_PEDIDO_NOVO
	SET @NUM_PEDIDO_NOVO = SCOPE_IDENTITY();

	-- fazer SELECT dos itens do pedido (ITENSPEDIDO) com 
	-- NUM_PEDIDO = @NUM_PEDIDO_FONTE. Inserir o resultado desse SELECT
	-- na pr�pria tabela ITENSPEDIDO, mas com NUM_PEDIDO = @NUM_PEDIDO_NOVO
	INSERT INTO ITENSPEDIDO (NUM_PEDIDO, NUM_ITEM, ID_PRODUTO, 
		COD_PRODUTO, CODCOR, QUANTIDADE, PR_UNITARIO, DATA_ENTREGA, 
		SITUACAO, DESCONTO )
	SELECT @NUM_PEDIDO_NOVO, NUM_ITEM, ID_PRODUTO, 
		COD_PRODUTO, CODCOR, QUANTIDADE, 
	
		  (SELECT PRECO_VENDA FROM PRODUTOS
		   WHERE ID_PRODUTO = ITENSPEDIDO.ID_PRODUTO)
	
		, GETDATE() + 10, 
		'P', DESCONTO
	FROM ITENSPEDIDO
	WHERE NUM_PEDIDO = @NUM_PEDIDO_FONTE;

	-- retornar SELECT com @NUM_PEDIDO_NOVO
	--SELECT @NUM_PEDIDO_NOVO AS NUM_PEDIDO_NOVO,
	--       'SUCESSO' AS ERRO_MSG,
	--	    0 AS ERRO_COD;

	SET @ERRO_COD = 0;
	SET @ERRO_MSG = 'SUCESSO';

	-- confirmar transa��o
	COMMIT;
END TRY -- fecha bloco de comandos protegidos
-- abrir bloco de tratamento de erro
BEGIN CATCH
	ROLLBACK;
	--SELECT -1 AS NUM_PEDIDO_NOVO,
	--        ERROR_MESSAGE() AS ERRO_MSG,
	--		ERROR_NUMBER() AS ERRO_COD;
	SET @NUM_PEDIDO_NOVO = -1;
	SET @ERRO_MSG = ERROR_MESSAGE();
	SET @ERRO_COD = ERROR_NUMBER();
END CATCH

END
GO

-- TESTANDO
DECLARE @NP INT, @EM VARCHAR(1000), @EC INT
EXEC STP_COPIA_PEDIDO_P 9999, @EM OUTPUT, @EC OUTPUT, @NP OUTPUT
IF @NP < 0
   PRINT 'ERRO: ' + @EM
ELSE
   PRINT 'GERADO PEDIDO ' + CAST(@NP AS VARCHAR(10))   
GO   

-- 3. Procedures de manuten��o de tabela 
-- Para a tabela PRODUTOS
-- 3.1. STP_PRODUTOS_CONSULTA
/*
SELECT PR.ID_PRODUTO, PR.COD_PRODUTO, PR.DESCRICAO, 
       T.TIPO, U.UNIDADE, PR.PRECO_VENDA, PR.QTD_REAL,
       PR.QTD_MINIMA  
FROM PRODUTOS PR 
     JOIN TIPOPRODUTO T ON PR.COD_TIPO = T.COD_TIPO 
     JOIN UNIDADES U ON PR.COD_UNIDADE = U.COD_UNIDADE 
WHERE DESCRICAO LIKE @descricao AND TIPO LIKE @tipo 
ORDER BY DESCRICAO
*/
CREATE PROCEDURE STP_PRODUTOS_CONSULTA @DESCRICAO VARCHAR(40),
                                       @TIPO VARCHAR(20)
AS BEGIN
SELECT PR.ID_PRODUTO, PR.COD_PRODUTO, PR.DESCRICAO, 
       T.TIPO, U.UNIDADE, PR.PRECO_VENDA, PR.QTD_REAL,
       PR.QTD_MINIMA  
FROM PRODUTOS PR 
     JOIN TIPOPRODUTO T ON PR.COD_TIPO = T.COD_TIPO 
     JOIN UNIDADES U ON PR.COD_UNIDADE = U.COD_UNIDADE 
WHERE DESCRICAO LIKE @descricao AND TIPO LIKE @tipo 
ORDER BY DESCRICAO
END
GO
--- TESTANDO
EXEC STP_PRODUTOS_CONSULTA '%CANETA%', '%'
GO

-- 3.2. STP_PRODUTOS_DELETE
-- ela recebe a chave prim�ria da tabela
CREATE PROCEDURE STP_PRODUTOS_DELETE @ID_PRODUTO INT
AS BEGIN
-- deleta filtrando pela chave prim�ria
DELETE FROM PRODUTOS WHERE ID_PRODUTO = @ID_PRODUTO;
END
GO
-- TESTANDO
SELECT * FROM PRODUTOS ORDER BY ID_PRODUTO DESC

EXEC STP_PRODUTOS_DELETE 72
EXEC STP_PRODUTOS_DELETE 1 -- viola��o de chave estrangeira
GO

-- 3.3. STP_PRODUTOS_INSERT
/*
   @COD_PRODUTO VARCHAR(13), @DESCRICAO VARCHAR(50), @COD_UNIDADE INT, 
   @COD_TIPO INT, @PRECO_CUSTO NUMERIC(10,4), @PRECO_VENDA NUMERIC(10,4), 
   @QTD_ESTIMADA INT, @QTD_REAL INT, @QTD_MINIMA INT, 
   @CLAS_FISC VARCHAR(10), @IPI INT, @PESO_LIQ NUMERIC(10,2)
*/
CREATE PROCEDURE STP_PRODUTOS_INSERT
   -- recebe uma vari�vel para cada campo da tabela, MENOS CAMPO IDENTIDADE 
   @COD_PRODUTO VARCHAR(13), @DESCRICAO VARCHAR(50), @COD_UNIDADE INT, 
   @COD_TIPO INT, @PRECO_CUSTO NUMERIC(10,4), @PRECO_VENDA NUMERIC(10,4), 
   @QTD_ESTIMADA INT, @QTD_REAL INT, @QTD_MINIMA INT, 
   @CLAS_FISC VARCHAR(10), @IPI INT, @PESO_LIQ NUMERIC(10,2)
AS BEGIN
-- executa o INSERT inserindo as vari�veis nos campos da tabela, MENOS CAMPO IDENTIDADE
INSERT INTO PRODUTOS (COD_PRODUTO, DESCRICAO, COD_UNIDADE, COD_TIPO, PRECO_CUSTO, PRECO_VENDA, QTD_ESTIMADA, QTD_REAL, QTD_MINIMA, CLAS_FISC, IPI, PESO_LIQ )
VALUES (@COD_PRODUTO, @DESCRICAO, @COD_UNIDADE, @COD_TIPO,  
        @PRECO_CUSTO, @PRECO_VENDA, @QTD_ESTIMADA, @QTD_REAL, 
		@QTD_MINIMA, @CLAS_FISC, @IPI, @PESO_LIQ );
-- se a tabela tem campo identidade, retornar com o valor gerado para ele
SELECT SCOPE_IDENTITY() AS ID_PRODUTO_NOVO;
END
GO
--- TESTANDO
EXEC STP_PRODUTOS_INSERT '999','TESTE INCLUS�O', 1, 1, 1.00, 1.50, 10, 10,
                          5, '123456', 5, 1;
GO

-- 3.4. STP_PRODUTOS_UPDATE
-- recebe TODOS os campos da tabela, inclusive identidade
CREATE PROCEDURE STP_PRODUTOS_UPDATE @ID_PRODUTO INT,
   @COD_PRODUTO VARCHAR(13), @DESCRICAO VARCHAR(50), @COD_UNIDADE INT, 
   @COD_TIPO INT, @PRECO_CUSTO NUMERIC(10,4), @PRECO_VENDA NUMERIC(10,4), 
   @QTD_ESTIMADA INT, @QTD_REAL INT, @QTD_MINIMA INT, 
   @CLAS_FISC VARCHAR(10), @IPI INT, @PESO_LIQ NUMERIC(10,2)
AS BEGIN

UPDATE PRODUTOS SET
           COD_PRODUTO		= @COD_PRODUTO, 
		   DESCRICAO		= @DESCRICAO, 
		   COD_UNIDADE		= @COD_UNIDADE, 
		   COD_TIPO			= @COD_TIPO,  
		   PRECO_CUSTO		= @PRECO_CUSTO, 
		   PRECO_VENDA		= @PRECO_VENDA, 
		   QTD_ESTIMADA		= @QTD_ESTIMADA,
		   QTD_REAL			= @QTD_REAL, 
		   QTD_MINIMA		= @QTD_MINIMA, 
		   CLAS_FISC		= @CLAS_FISC, 
		   IPI				= @IPI, 
		   PESO_LIQ         = @PESO_LIQ
-- usar a chave prim�ria para filtrar o UPDATE
WHERE ID_PRODUTO = @ID_PRODUTO;

END
GO

--	STP_PRODUTOS_CONSULTA_POR_ID
CREATE PROCEDURE STP_PRODUTOS_CONSULTA_POR_ID @ID_PRODUTO INT
AS BEGIN
-- deleta filtrando pela chave prim�ria
SELECT * FROM PRODUTOS WHERE ID_PRODUTO = @ID_PRODUTO;
END
GO

--------------------------------------------------------
-- 3.5. Para a tabela TABELACAR, crie as procedures de 
--      DELETE, INSERT e UPDATE

--      STP_TABELACAR_DELETE
CREATE PROCEDURE STP_TABELACAR_DELETE @COD_CARGO INT
AS BEGIN

DELETE FROM TABELACAR WHERE COD_CARGO = @COD_CARGO;

END
GO
--      STP_TABELACAR_INSERT
CREATE PROCEDURE STP_TABELACAR_INSERT @CARGO VARCHAR(30),
                                      @SALARIO_INIC FLOAT
AS BEGIN									   

INSERT INTO TABELACAR (CARGO, SALARIO_INIC)
VALUES (@CARGO, @SALARIO_INIC)
-- como a tabela tem campo IDENTITY
SELECT SCOPE_IDENTITY() AS COD_CARGO_NOVO;

END
GO

--      STP_TABELACAR_UPDATE
CREATE PROCEDURE STP_TABELACAR_UPDATE @COD_CARGO INT,
                                      @CARGO VARCHAR(30),
                                      @SALARIO_INIC FLOAT
AS BEGIN

UPDATE TABELACAR SET CARGO = @CARGO,
                     SALARIO_INIC = @SALARIO_INIC
WHERE COD_CARGO = @COD_CARGO;
					  
END
GO

--      STP_TABELACAR_CONSULTA
/*
	SELECT * FROM TABELACAR
	WHERE CARGO LIKE @CARGO
	ORDER BY CARGO
*/
CREATE PROCEDURE STP_TABELACAR_CONSULTA @CARGO VARCHAR(30) = '%'
AS BEGIN

	SELECT * FROM TABELACAR
	WHERE CARGO LIKE @CARGO
	ORDER BY CARGO;

END
GO

--      STP_TABELACAR_CONSULTA_POR_ID
CREATE PROCEDURE STP_TABELACAR_CONSULTA_POR_ID @COD_CARGO INT
AS BEGIN

SELECT * FROM TABELACAR WHERE COD_CARGO = @COD_CARGO;

END
GO

--------- TESTANDO
EXEC STP_TABELACAR_INSERT 'TESTANDO', 1000
-- gerou COD_CARGO = 18
SELECT * FROM TABELACAR

EXEC STP_TABELACAR_UPDATE 18, 'ALTERANDO', 1500
SELECT * FROM TABELACAR

EXEC STP_TABELACAR_DELETE 18
SELECT * FROM TABELACAR


--------------------------------------------------------
EXEC sp_configure 'show advanced option', '1';
reconfigure

exec sp_configure 'xp_cmdshell',1
reconfigure
GO

exec xp_cmdshell 'dir *.*'
go
-------------------------------------------------------------
-- 4. Cria��o de CURSOR - Exemplo 1 -
--    A partir do resultado desta instru��o
--      SELECT NOME FROM CLIENTES 
--      WHERE ESTADO = 'SC'
--    Gerar um texto (que possa ser salvo pelo SSMS) onde apare�a
--    1 nome por linha
CREATE PROCEDURE STP_GERA_TEXTO @UF CHAR(2), @ARQUIVO VARCHAR(1000)
AS BEGIN
-- criar vari�vel do tipo CURSOR para percorrer as linhas
-- do SELECT
DECLARE CR_CLIENTES CURSOR FOR SELECT NOME FROM CLIENTES 
                               WHERE ESTADO = @UF
							   ORDER BY NOME;
-- declarar uma vari�vel para cada campo do cursor
DECLARE @NOME VARCHAR(50);
-- vari�vel para armazenar o comando do DOS que vamos executar
DECLARE @CMD VARCHAR(1000) = 'DEL ' + @ARQUIVO;
-- executar o comando que est� na vari�vel @ECHO. 
-- A cl�usula NO_OUTPUT n�o mostra o resultado retornado
-- pelo comando
EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
-- "abrir" o cursor. Isso executa o SELECT e armazena os
-- dados em uma �rea do servidor
OPEN CR_CLIENTES;
-- ler a primeira linha do SELECT, e avan�a para a pr�xima
FETCH NEXT FROM CR_CLIENTES INTO @NOME;
-- enquanto n�o chegar na �ltima linha de dados
WHILE @@FETCH_STATUS = 0
   BEGIN
   -- colocar na vari�vel o comando DOS que queremos executar
   SET @CMD = 'ECHO ' + @NOME + ' >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
   -- ler a pr�xima linha do cursor
   FETCH NEXT FROM CR_CLIENTES INTO @NOME;
   END -- WHILE @@FETCH_STATUS
-- fechar o cursor. Elimina qualque bloqueio imposto �s
-- linhas do select
CLOSE CR_CLIENTES;
-- retirar a vari�vel clientes da mem�ria
DEALLOCATE CR_CLIENTES;
END
GO
-- Testando
EXEC STP_GERA_TEXTO 'MG', 'C:\DADOS\TESTE_MG.TXT'
EXEC STP_GERA_TEXTO 'RJ', 'C:\DADOS\TESTE_RJ.TXT'
EXEC STP_GERA_TEXTO 'SC', 'C:\DADOS\TESTE_SC.TXT'
GO
-------------------------------------------------------------
-- 4. Altere a procedure anterior de modo que apare�am 3 nomes por linha
--    separados um do outro pelo caractere "#"
ALTER PROCEDURE STP_GERA_TEXTO @UF CHAR(2), @ARQUIVO VARCHAR(1000)
AS BEGIN
-- criar vari�vel do tipo CURSOR para percorrer as linhas
-- do SELECT
DECLARE CR_CLIENTES CURSOR FOR SELECT NOME FROM CLIENTES 
                               WHERE ESTADO = @UF
							   ORDER BY NOME;
-- declarar uma vari�vel para cada campo do cursor
DECLARE @NOME VARCHAR(50);
-- vari�vel para armazenar o comando do DOS que vamos executar
DECLARE @CMD VARCHAR(1000) = 'DEL ' + @ARQUIVO;
-- executar o comando que est� na vari�vel @ECHO. 
-- A cl�usula NO_OUTPUT n�o mostra o resultado retornado
-- pelo comando
EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
-- "abrir" o cursor. Isso executa o SELECT e armazena os
-- dados em uma �rea do servidor
OPEN CR_CLIENTES;
-- ler a primeira linha do SELECT, e avan�a para a pr�xima
FETCH NEXT FROM CR_CLIENTES INTO @NOME;
-- enquanto n�o chegar na �ltima linha de dados
WHILE @@FETCH_STATUS = 0
   BEGIN
   -- vari�vel para armazenar os 3 nomes concatenados
   DECLARE @TRES_NOMES VARCHAR(150) = '';
   -- contador para 3 voltas de loop
   DECLARE @CONT INT = 1;
   -- loop para concatenar os 3 nomes
   WHILE @CONT <= 3 AND @@FETCH_STATUS = 0
      BEGIN
	  -- concatenar @NOME em @TRES_NOMES
	  SET @TRES_NOMES += @NOME + '#';
      -- ler a pr�xima linha do cursor
      FETCH NEXT FROM CR_CLIENTES INTO @NOME;
	  -- incrementar o contador
	  SET @CONT += 1;
	  END -- WHILE @CONT <= 3
   
   -- retira o �ltimo caractere
   SET @TRES_NOMES = LEFT(@TRES_NOMES, LEN(@TRES_NOMES) - 1);

   -- colocar na vari�vel o comando DOS que queremos executar
   SET @CMD = 'ECHO ' + @TRES_NOMES + ' >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
   END -- WHILE @@FETCH_STATUS
-- fechar o cursor. Elimina qualque bloqueio imposto �s
-- linhas do select
CLOSE CR_CLIENTES;
-- retirar a vari�vel clientes da mem�ria
DEALLOCATE CR_CLIENTES;
END
GO
-- Testando
EXEC STP_GERA_TEXTO 'MG', 'C:\DADOS\TESTE_MG.TXT'
EXEC STP_GERA_TEXTO 'RJ', 'C:\DADOS\TESTE_RJ.TXT'
EXEC STP_GERA_TEXTO 'SC', 'C:\DADOS\TESTE_SC.TXT'
GO
-------------------------------------------------
-- 5. Altere a procedure anterior incluindo um par�metro
--    @TAM_FIXO CHAR(1)
--    Se @TAM_FIXO for igual a 'S' os nomes dever�o ser completados
--    com espa�os at� o tamanho 50
/*
SET @NOME = @NOME + SPACE( 50 - LEN(@NOME))


ANTONIO M.DE SOUZA                                CELSO PEREIRA                                     CANUTO REPRESENTACOES COMERCIAIS LTDA.            
CAMSID REPRESENTACOES COMERCIAIS LTDA.            DEMERALDO T. GOMES DA SILVA                       ELETRO DIZEL BOA VISTA LTDA                       
EDSON TARIFA VARGAS                               EMILIO GRAFICA KEMBEC LTDA                        HIRAFUJI COM REPRRES DE BRINDES LTDA              
*/
--    Se @TAM_FIXO for igual a 'N' os nomes ser�o separados por "#"
/*
ANTONIO M.DE SOUZA#CELSO PEREIRA#CANUTO REPRESENTACOES COMERCIAIS LTDA.
CAMSID REPRESENTACOES COMERCIAIS LTDA.#DEMERALDO T. GOMES DA SILVA#ELETRO DIZEL BOA VISTA LTDA
EDSON TARIFA VARGAS#EMILIO GRAFICA KEMBEC LTDA#HIRAFUJI COM REPRRES DE BRINDES LTDA
*/
ALTER PROCEDURE STP_GERA_TEXTO @UF CHAR(2), @ARQUIVO VARCHAR(1000), 
                               @TAM_FIXO CHAR(1) = 'N'
AS BEGIN
-- criar vari�vel do tipo CURSOR para percorrer as linhas
-- do SELECT
DECLARE CR_CLIENTES CURSOR FOR SELECT NOME FROM CLIENTES 
                               WHERE ESTADO = @UF
							   ORDER BY NOME;
-- declarar uma vari�vel para cada campo do cursor
DECLARE @NOME VARCHAR(50);
-- vari�vel para armazenar o comando do DOS que vamos executar
DECLARE @CMD VARCHAR(1000) = 'DEL ' + @ARQUIVO;
-- executar o comando que est� na vari�vel @ECHO. 
-- A cl�usula NO_OUTPUT n�o mostra o resultado retornado
-- pelo comando
EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
-- "abrir" o cursor. Isso executa o SELECT e armazena os
-- dados em uma �rea do servidor
OPEN CR_CLIENTES;
-- ler a primeira linha do SELECT, e avan�a para a pr�xima
FETCH NEXT FROM CR_CLIENTES INTO @NOME;
-- enquanto n�o chegar na �ltima linha de dados
WHILE @@FETCH_STATUS = 0
   BEGIN
   -- vari�vel para armazenar os 3 nomes concatenados
   DECLARE @TRES_NOMES VARCHAR(150) = '';
   -- contador para 3 voltas de loop
   DECLARE @CONT INT = 1;
   -- loop para concatenar os 3 nomes
   WHILE @CONT <= 3 AND @@FETCH_STATUS = 0
      BEGIN
	  -- concatenar @NOME em @TRES_NOMES
	  IF @TAM_FIXO = 'N'
	     SET @TRES_NOMES += @NOME + '#'
	  ELSE
	     SET @TRES_NOMES += @NOME + SPACE(50 - LEN(@NOME));

      -- ler a pr�xima linha do cursor
      FETCH NEXT FROM CR_CLIENTES INTO @NOME;
	  -- incrementar o contador
	  SET @CONT += 1;
	  END -- WHILE @CONT <= 3
   
   -- retira o �ltimo caractere
   SET @TRES_NOMES = LEFT(@TRES_NOMES, LEN(@TRES_NOMES) - 1);

   -- colocar na vari�vel o comando DOS que queremos executar
   SET @CMD = 'ECHO ' + @TRES_NOMES + ' >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
   END -- WHILE @@FETCH_STATUS
-- fechar o cursor. Elimina qualque bloqueio imposto �s
-- linhas do select
CLOSE CR_CLIENTES;
-- retirar a vari�vel clientes da mem�ria
DEALLOCATE CR_CLIENTES;
END
GO

--- TESTANDO
EXEC STP_GERA_TEXTO 'MG', 'C:\DADOS\TESTE_MG.TXT', 'S'
EXEC STP_GERA_TEXTO 'RJ', 'C:\DADOS\TESTE_SC.TXT'
EXEC STP_GERA_TEXTO 'SC', 'C:\DADOS\TESTE_PR.TXT'
GO

SELECT FORMAT(CODFUN,'00000') +
       NOME + SPACE(50-LEN(NOME)) +
	   FORMAT(DATA_ADMISSAO,'yyyyMMdd') +
	   FORMAT(SALARIO*100,'0000000000') 
FROM EMPREGADOS     
GO

-- EXTRA ---------------------------------------------------------
CREATE PROCEDURE STP_GERA_ETIQUETA @UF CHAR(2), @ARQUIVO VARCHAR(1000)
AS BEGIN
-- criar vari�vel do tipo CURSOR para percorrer as linhas
-- do SELECT
DECLARE CR_CLIENTES CURSOR FOR SELECT NOME, ENDERECO, CIDADE, ESTADO 
                               FROM CLIENTES 
                               WHERE ESTADO = @UF
							   ORDER BY NOME;
-- declarar uma vari�vel para cada campo do cursor
DECLARE @NOME VARCHAR(50);
DECLARE @ENDERECO VARCHAR(60);
DECLARE @CIDADE VARCHAR(20);
DECLARE @ESTADO CHAR(2);
-- vari�vel para armazenar o comando do DOS que vamos executar
DECLARE @CMD VARCHAR(1000) = 'DEL ' + @ARQUIVO;
-- executar o comando que est� na vari�vel @ECHO. 
-- A cl�usula NO_OUTPUT n�o mostra o resultado retornado
-- pelo comando
EXEC XP_CMDSHELL @CMD, NO_OUTPUT;
-- "abrir" o cursor. Isso executa o SELECT e armazena os
-- dados em uma �rea do servidor
OPEN CR_CLIENTES;
-- ler a primeira linha do SELECT, e avan�a para a pr�xima
FETCH NEXT FROM CR_CLIENTES INTO @NOME, @ENDERECO, @CIDADE, @ESTADO;
-- enquanto n�o chegar na �ltima linha de dados
WHILE @@FETCH_STATUS = 0
   BEGIN
   -- colocar na vari�vel o comando DOS que queremos executar
   SET @CMD = 'ECHO ' + @NOME + ' >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;

   SET @CMD = 'ECHO ' + @ENDERECO + ' >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;

   SET @CMD = 'ECHO ' + @CIDADE + ' - ' + @ESTADO + ' >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;

   SET @CMD = 'ECHO . >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;

   SET @CMD = 'ECHO . >> ' + @ARQUIVO;
   -- executar o comando
   EXEC XP_CMDSHELL @CMD, NO_OUTPUT;

   -- ler a pr�xima linha do cursor
   FETCH NEXT FROM CR_CLIENTES INTO @NOME, @ENDERECO, @CIDADE, @ESTADO;
   END -- WHILE @@FETCH_STATUS
-- fechar o cursor. Elimina qualque bloqueio imposto �s
-- linhas do select
CLOSE CR_CLIENTES;
-- retirar a vari�vel clientes da mem�ria
DEALLOCATE CR_CLIENTES;
END

---
EXEC STP_GERA_ETIQUETA 'RJ', 'C:\DADOS\ETIQUETA_RJ.TXT'
GO

-- 6 - Gerar script para criar novo campo em todas as 
--     tabelas do banco de dados
--	   Par�metros: 
--         @CAMPO VARCHAR(1000): Nome e tipo do campo
/*
	ALTER TABLE nome_tabela ADD nome_campo tipo_campo
*/
CREATE PROCEDURE STP_CRIA_CAMPO @CAMPO VARCHAR(1000)
AS BEGIN
-- criar cursor para percorrer a tabela SYSOBJECTS
DECLARE CR_TABELAS CURSOR FOR SELECT NAME FROM SYSOBJECTS              
                              WHERE XTYPE = 'U'
							  ORDER BY NAME;
-- criar vari�vel para receber o nome da tabela
DECLARE @NAME VARCHAR(200);
-- abrir o cursor
OPEN CR_TABELAS;
-- ler a primeira linha
FETCH NEXT FROM CR_TABELAS INTO @NAME;
-- enquanto n�o terminarem as linhas
WHILE @@FETCH_STATUS = 0
   BEGIN
   -- montar o comando ALTER TABLE
   DECLARE @COMANDO VARCHAR(1000) = 'ALTER TABLE ' +
           @NAME + ' ADD ' + @CAMPO;
   -- mostrar o comando na �rea de texto do SSMS
   PRINT @COMANDO;
   -- tamb�m � poss�vel executar um comando que esteja
   -- em uma vari�vel
   -- EXEC( @COMANDO );
   -- ler a pr�xima linha
   FETCH NEXT FROM CR_TABELAS INTO @NAME;
   END -- WHILE @@FETCH_STATUS = 0
-- fechar o cursor e retirar da mem�ria
CLOSE CR_TABELAS;
-- NUNCA, JAMAIS, DE JEITO NENHUM, ESQUE�A DISSO!!!
DEALLOCATE CR_TABELAS;
END
GO
----
EXEC STP_CRIA_CAMPO 'DATA_ALTERACAO DATETIME NOT NULL DEFAULT GETDATE()'
GO


-- 5. Criar procedure STP_HABILITA_FK que desabilita '0' ou habilita '1' todas as
--    chaves estrangeiras do banco de dados.
--
--    Obs.1: para desabilitar uma FK
--    ALTER TABLE PRODUTOS NOCHECK CONSTRAINT FK_PRODUTOS_UNIDADES

--    Obs.2: para habilitar uma FK
--    ALTER TABLE PRODUTOS CHECK CONSTRAINT FK_PRODUTOS_UNIDADES
--
--    Obs.3: para obter os nomes de todas as FKs e suas tabelas, fa�a:

--    SELECT F.NAME AS NOME_FK, T.NAME AS NOME_TABELA
--    FROM SYSOBJECTS F JOIN SYSOBJECTS T ON F.parent_obj = T.id
--    WHERE F.XTYPE = 'F'
CREATE PROCEDURE STP_HABILITA_FK @STATUS CHAR(1) = '0'
AS BEGIN
-- 1. declarar cursor para o SELECT que le as FKs de cada tabela
DECLARE CR_FKS CURSOR FOR 
               SELECT F.NAME AS NOME_FK, T.NAME AS NOME_TABELA
			   FROM SYSOBJECTS F JOIN SYSOBJECTS T ON F.parent_obj = T.id
			   WHERE F.XTYPE = 'F';
-- 2. declarar uma vari�vel para cada campo do cursor
DECLARE @NOME_FK VARCHAR(200), @NOME_TABELA VARCHAR(200);
-- 3. abrir o cursor
OPEN CR_FKS;
-- 4. ler a primeira linha
FETCH NEXT FROM CR_FKS INTO @NOME_FK, @NOME_TABELA;
-- 5. loop para ler as linhas
WHILE @@FETCH_STATUS = 0
   BEGIN
   -- 5.1. montar o comando ALTER TABLE em vari�vel (@CMD VARCHAR(1000))
   -- se @STATUS = '0' -> ALTER nome_tabela NOCHECK CONSTRAINT nome_FK
   -- se @STATUS = '1' -> ALTER nome_tabela CHECK CONSTRAINT nome_FK
   DECLARE @CMD VARCHAR(1000) = 'ALTER TABLE ' + @NOME_TABELA +
                   IIF(@STATUS = '0', ' NO', ' ') + 'CHECK CONSTRAINT ' +
				   @NOME_FK + ';';  
   -- 5.2. mostrar o comando na �rea de texto do SSMS (PRINT @CMD)
   PRINT @CMD;
   -- EXEC( @CMD );
   -- 5.3. ler a pr�xima linha do cursor
   FETCH NEXT FROM CR_FKS INTO @NOME_FK, @NOME_TABELA;
   END -- WHILE @@FETCH_STATUS

-- 6. fechar o cursor
CLOSE CR_FKS;
-- 7. desalocar o cursor da mem�ria
DEALLOCATE CR_FKS;
END
GO
--
EXEC STP_HABILITA_FK '0'
EXEC STP_HABILITA_FK '1'

SELECT * FROM sys.foreign_keys 

SELECT * FROM PEDIDOS ORDER BY NUM_PEDIDO DESC
SELECT * FROM ITENSPEDIDO ORDER BY NUM_PEDIDO DESC


DELETE FROM PEDIDOS WHERE NUM_PEDIDO = 10941

DELETE FROM ITENSPEDIDO WHERE NUM_PEDIDO = 10941

SELECT * FROM PEDIDOS ORDER BY NUM_PEDIDO DESC
GO
-----------------------------------------------------------------------------------------
----------------------------------------------------------------
-- GERA��O DE PROCEDURES PARA MANUTEN��O DE TABELAS
----------------------------------------------------------------
-- UPDATE ------------------------------------------------------
create procedure stp_gera_proc_update_tabela @tabela varchar(200)
as begin
-- cursor para ler a estrutura da tabeLa
declare cr_estrutura cursor for 
    SELECT C.NAME AS campo, DT.NAME tipo,
           C.length AS tamanho, C.xprec AS PRECISAO, C.xscale AS DECIMAIS
    FROM SYSOBJECTS T 
	     JOIN SYSCOLUMNS C ON T.id = C.id
         JOIN SYSTYPES DT ON C.xtype = DT.xtype
    WHERE T.XTYPE = 'U' AND T.name = @tabela
	ORDER BY C.colid;

-- cursor para ler os campos que formam a chave prim�ria da tabela
declare  cr_campos_pk cursor for
			select sc.name
			from sysobjects so 
				 join sys.indexes si on so.id = si.object_id
				 join sys.index_columns ic on ic.object_id = si.object_id and
															ic.index_id = si.index_id
				 join syscolumns sc on ic.object_id = sc.id and ic.column_id = sc.colid
			where so.xtype = 'U' 
				  and si.is_primary_key = 1
				  and so.name = @tabela;

-- vari�veis que ser�o lidas por CR_ESTRUTURA
declare @campo varchar(100), @tipo varchar(50), @tamanho int, @precisao int,
        @decimais int;

-- vari�veis auxiliares para montagem do comando UPDATES
declare @campos_tipos varchar(8000) = '', @set_campos varchar(8000) = '';

-- armazena o nome do campo identidade da tabela, ou NULL se n�o existir campo identidade
declare @campo_identity varchar(100);
-- l� o nome do campo identidade da tabela
select @campo_identity = name from sys.identity_columns
where object_id = OBJECT_ID(@tabela);
-- se for nulo troca por vazio
set @campo_identity = isnull(@campo_identity,'');

-- armazena os campos da PK
declare @campo_pk varchar(500);
-- onde ser� montada a cl�usula WHERE do comando UPDATE 
declare @where varchar(1000) = 'WHERE ';
-- l� os nomes dos campos que formam a PK e monta a cl�usula WHERE do comando UPDATE
open cr_campos_pk
fetch next from cr_campos_pk into @campo_pk;
while @@FETCH_STATUS = 0
   begin
   set @where += @campo_pk + ' = ' + ' @' + @campo_pk;
   fetch next from cr_campos_pk into @campo_pk;
   if @@FETCH_STATUS = 0 set @where  += ' AND ';
   end
close cr_campos_pk;
deallocate cr_campos_pk;

-- L� a estrutura da tabela para montar o SET do UPDATE
open cr_estrutura
fetch next from cr_estrutura into @campo, @tipo, @tamanho, @precisao, @decimais;
while @@FETCH_STATUS = 0
   begin
   set @campos_tipos += '@' + @campo + ' ' + @tipo;
   if @tipo in ('char', 'varchar','nchar', 'nvarchar')
	  set @campos_tipos += concat('(', @tamanho, ')')
   else if @tipo in ('decimal', 'numeric')
      set @campos_tipos += concat('(', @precisao,', ', @decimais, ')')

   if @campo <> @campo_identity
	  set @set_campos += @campo + ' = ' + '@' + @campo;

   fetch next from cr_estrutura into @campo, @tipo, @tamanho, @precisao, @decimais; 
   if @@FETCH_STATUS = 0
      begin
	  set @campos_tipos += ', ';
	  set @set_campos += iif(@set_campos <> '', ', ', '');
	  end
   end
close cr_estrutura;
deallocate cr_estrutura;
-- monta o comando UPDATE
print 'CREATE PROCEDURE STP_' + @tabela + + '_UPDATE ';
print '    ' + @campos_tipos;
print 'AS BEGIN'
print 'UPDATE ' + @tabela; 
print 'SET ' + @set_campos;
print @where + ';';
print 'END'
end
go
-----
exec stp_gera_proc_update_tabela 'produtos'
exec stp_gera_proc_update_tabela 'itenspedido'
GO

-- INSERT ------------------------------------------------------
create procedure stp_gera_proc_insert_tabela @tabela varchar(200)
as begin
declare cr_estrutura cursor for 
    SELECT C.NAME AS campo, DT.NAME tipo,
           C.length AS tamanho, C.xprec AS PRECISAO, C.xscale AS DECIMAIS
    FROM SYSOBJECTS T 
	     JOIN SYSCOLUMNS C ON T.id = C.id
         JOIN SYSTYPES DT ON C.xtype = DT.xtype
    WHERE T.XTYPE = 'U' AND T.name = @tabela
	ORDER BY C.colid;


declare @campo varchar(100), @tipo varchar(50), @tamanho int, @precisao int,
        @decimais int;

declare @campos_tipos varchar(8000) = '', 
        @campos_lista  varchar(8000) = '',
        @campos_values varchar(8000) = '';

declare @campo_identity varchar(100);
select @campo_identity = name from sys.identity_columns
where object_id = OBJECT_ID(@tabela);

set @campo_identity = isnull(@campo_identity,'');

open cr_estrutura
fetch next from cr_estrutura into @campo, @tipo, @tamanho, @precisao, @decimais;
while @@FETCH_STATUS = 0
   begin
   if @campo <> @campo_identity
      begin
      set @campos_tipos += '@' + @campo + ' ' + @tipo;
      if @tipo in ('char', 'varchar','nchar', 'nvarchar')
	     set @campos_tipos += concat('(', @tamanho, ')')
      else if @tipo in ('decimal', 'numeric')
         set @campos_tipos += concat('(', @precisao,', ', @decimais, ')')


	  set @campos_lista += @campo;
	  set @campos_values += '@' + @campo;
	  end
   fetch next from cr_estrutura into @campo, @tipo, @tamanho, @precisao, @decimais; 
   if @@FETCH_STATUS = 0
      begin
	  set @campos_tipos += iif(@campos_tipos <> '', ', ', '');
	  set @campos_lista += iif(@campos_lista <> '', ', ', '');
	  set @campos_values += iif(@campos_values <> '', ', ', '');
	  end
   end
close cr_estrutura;
deallocate cr_estrutura;

print 'CREATE PROCEDURE STP_' + @tabela + + '_INSERT ';
print '    ' + @campos_tipos;
print 'AS BEGIN'
print 'INSERT INTO ' + @tabela; 
print '(' + @campos_lista + ')';
print 'VALUES( ' + @campos_values + ');'
if @campo_identity <> ''
   print 'SELECT SCOPE_IDENTITY() AS ' + @campo_identity + '_NOVO';
print 'END';
end
go
-----
exec stp_gera_proc_INSERT_tabela 'PRODUTOS'

exec stp_gera_proc_insert_tabela 'itenspedido'
GO

-- DELETE ------------------------------------------------------
create procedure stp_gera_proc_delete_tabela @tabela varchar(200)
as begin

declare  cr_campos_pk cursor for
			select sc.name, st.name tipo,
			    sc.length AS tamanho, sc.xprec AS PRECISAO, 
				sc.xscale AS DECIMAIS 
			from sysobjects so 
				 join sys.indexes si on so.id = si.object_id
				 join sys.index_columns ic on ic.object_id = si.object_id and
															ic.index_id = si.index_id
				 join syscolumns sc on ic.object_id = sc.id and ic.column_id = sc.colid
				 join systypes st on sc.xtype = st.xusertype
			where so.xtype = 'U' 
				  and si.is_primary_key = 1
				  and so.name = @tabela;

declare @campo varchar(100), @tipo varchar(50), @tamanho int, @precisao int,
        @decimais int;

declare @campos_tipos varchar(8000) = ''
declare @campo_pk varchar(500); 
declare @where varchar(1000) = '';
open cr_campos_pk
fetch next from cr_campos_pk into @campo_pk, @tipo, @tamanho, @precisao, @decimais;
while @@FETCH_STATUS = 0
   begin
   set @campos_tipos += '@' + @campo_pk + ' ' + @tipo;
   if @tipo in ('char', 'varchar','nchar', 'nvarchar')
      set @campos_tipos += concat('(', @tamanho, ')')
   else if @tipo in ('decimal', 'numeric')
      set @campos_tipos += concat('(', @precisao,', ', @decimais, ')')

   set @where += @campo_pk + ' = ' + ' @' + @campo_pk;
   fetch next from cr_campos_pk into @campo_pk, @tipo, @tamanho, @precisao, @decimais;
   if @@FETCH_STATUS = 0 
      begin 
      set @where  += ' AND ';
	  set @campos_tipos += ', '
	  end
   end
close cr_campos_pk;
deallocate cr_campos_pk;

print 'CREATE PROCEDURE STP_' + @tabela + + '_DELETE ' + @campos_tipos;

print 'AS BEGIN'
print 'DELETE FROM ' + @tabela; 
print 'WHERE ' + @where + ';';
print 'END'
end
go

---
exec stp_gera_proc_update_tabela 'produtos'
exec stp_gera_proc_update_tabela 'itenspedido'

exec stp_gera_proc_INSERT_tabela 'PRODUTOS'
exec stp_gera_proc_insert_tabela 'itenspedido'

EXEC stp_gera_proc_delete_tabela produtos
exec stp_gera_proc_delete_tabela 'itenspedido'

