/*
    GRANULARIDADE (recursos)
    ------------------------
         
        (*) Linha (ROW): Uma linha de uma tabela
             RID (Row ID): Identificador de linha de tabela quando esta n�o possui chave prim�ria
             KEY         : Linha da tabela associada ao �ndice chave prim�ria
        (*) P�gina(PAGE): Um bloco de dados contendo 8K
            Bloco de p�ginas (EXTENT): Bloco cont�guo de 8 p�ginas.
        (*) Tabela (TABLE): Uma tabela do banco de dados. 
            Banco de dados
    

    TIPOS DE BLOQUEIO
    -----------------
    
		SHARED (S): 
			.� aplicado quando uma transa��o l� dados do banco de dados.
			.V�rias transa��es podem aplicar shared lock em um mesmo recurso.
		UPDATE (U):
			.Aplicado quando lemos dados que iremos alterar
			.Duas transa��es N�O PODEM colocar update lock em um mesmo recurso
			.No momento em que os dados s�o lidos por um comando UPDATE, por exemplo
			 os registros recebem um UPDATE LOCK.
			.Logo em seguida o UPDATE LOCK � promovido a EXCLUSIVE LOCK     
		EXCLUSIVE (X):
			.O bloqueio exclusivo garante que somente uma transa��o tem acesso ao registro   
			.N�o � compat�vel com outros tipos de bloqueio.
		INTENT (IS, IU, IX): 
			.Marca um determinado recurso sinalizando que nele existem bloqueios.  
        SCHEMA (Sch-M, Sch-S): 
            .Controla atualiza��es de estrutura das tabelas. 
            .Evitam que uma tabela que est� sendo utilizada em produ��o seja alterada 
            (Schema Modification Locks ou Sch-M), ou que algum processo acesse uma tabela 
             cuja estrutura est� em modifica��o (Schema Stability Locks ou Sch-S).
        Key-Range:
            .Bloqueia contra altera��o aquilo que estamos consultando
			  
*/

--=====================================================
-- CONCORR�NCIA - JANELA 1
--=====================================================
USE PEDIDOS

-- situa��o de bloqueio dos bancos de dados, tabelas, p�ginas e linhas
SELECT * FROM master.SYS.DM_TRAN_LOCKS -- (banco MASTER)
GO
   -- resource_database_id:  ID do database que est� bloqueado

   -- resource_associated_entity_id: 
   --   Em muitos casos, o bloqueio n�o est� ligado diretamente
   --   a um objeto (tabela) mas sim a uma linha ou p�gina de 
   --   uma tabela. Quando isso ocorre, o campo resource_associated_entity_id
   --   aponta para a tabela SYS.PARTITIONS apontando para o
   --   campo HOBT_ID desta �ltima.
   --   Isso pode ser �til para, a partir de SYS.PARTITIONS, descobrir
   --   a qual tabela pertence aquela linha ou p�gina bloqueada
-- Consultar bloqueios
-- Observe a coluna RESOURCE_TYPE e veja que o bloqueio ocorreu atravez
-- do Row ID das linhas da tabela
CREATE VIEW VIE_BLOQUEIOS AS
SELECT 
  L.RESOURCE_TYPE, L.REQUEST_MODE, L.REQUEST_TYPE, 
  PR.loginame, PR.hostname, PR.program_name,  
  D.NAME AS BANCO_DADOS, O.NAME NOME_OBJETO, 
  O2.NAME NOME_OBJETO_RELAC, L.REQUEST_STATUS, 
  L.REQUEST_SESSION_ID
FROM master.SYS.DM_TRAN_LOCKS L 
  JOIN master.SYS.DATABASES D ON L.RESOURCE_DATABASE_ID = D.DATABASE_ID
  LEFT JOIN pedidos.sys.SYSOBJECTS O ON O.ID = L.RESOURCE_ASSOCIATED_ENTITY_ID
  LEFT JOIN pedidos.SYS.PARTITIONS P ON L.RESOURCE_ASSOCIATED_ENTITY_ID = P.HOBT_ID
  LEFT JOIN pedidos.sys.SYSOBJECTS O2 ON P.OBJECT_ID = O2.ID
  JOIN master.SYS.sysprocesses PR ON L.request_session_id = PR.spid
WHERE D.NAME = 'PEDIDOS'
GO

-- EXEMPLO 1 ---------------------------------------------------------------------
-- A tabela PRODUTOS_TMP n�o possui chave prim�ria ou nenhum
-- outro �ndice clusterizado

SELECT * INTO PRODUTOS_TMP FROM PRODUTOS
-- Abrir transa��o
BEGIN TRAN
--SELECT @@TRANCOUNT
-- Executar update
UPDATE PRODUTOS_TMP SET PRECO_VENDA = 15
WHERE COD_TIPO = 1

SELECT * FROM VIE_BLOQUEIOS

SELECT * FROM PRODUTOS_TMP ORDER BY COD_TIPO
                         
-- V� at� a janela 2 e execute o comando correspondente ao EXEMPLO 1...
--
-- Descartar altera��es
ROLLBACK

-- EXEMPLO 2 ---------------------------------------------------------------------------
BEGIN TRAN

UPDATE PRODUTOS SET PRECO_VENDA = 5
WHERE COD_TIPO = 1

-- Observe a coluna RESOURCE_TYPE. Como a tabela possui chave prim�ria
-- o bloqueio ocorreu atravez da chave prim�ria
SELECT * FROM VIE_BLOQUEIOS
     
USE PEDIDOS
select * from PRODUTOS
-- Depois de executar o UPDATE v� para a janela 2 e execute o comando referente
-- ao exemplo 2...
--
-- Descartar altera��es
ROLLBACK

-- EXEMPLO 3 ---------------------------------------------------------------------------
BEGIN TRAN

UPDATE PEDIDOS WITH (ROWLOCK) -- WITH (ROWLOCK) � default
SET SITUACAO = 'E' WHERE NUM_PEDIDO < 1000

-- Observe o recurso bloqueado (KEY): Bloqueio de linha atravez da chave prim�ria
SELECT * FROM VIE_BLOQUEIOS


-- v� at� a janela 2 e exeute o EXEMPLO 3...
--
-- Descartar altera��es
ROLLBACK

-- EXEMPLO 4 ---------------------------------------------------------------------------
BEGIN TRAN

UPDATE PEDIDOS WITH (PAGLOCK) 
SET SITUACAO = 'X' WHERE NUM_PEDIDO < 1000

-- Observe o recurso bloqueado (PAGE): 
-- BOM  -> Menor n�mero de bloqueios, menos processamento, menor quantidade de mem�ria utilizada
-- RUIM -> Menor concorr�ncia. S�o bloqueados mais registros do que o necess�rio
SELECT * FROM VIE_BLOQUEIOS


-- V� at� a janela 2...
--
-- Descartar as altera��es
ROLLBACK


-- EXEMPLO 5 ---------------------------------------------------------------------------
BEGIN TRAN

UPDATE PEDIDOS WITH (TABLOCK) 
SET SITUACAO = 'X' WHERE NUM_PEDIDO < 1000

-- Observe o recurso bloqueado o o nome do objeto (OBJECT, PEDIDOS): 
-- BOM  -> Menor n�mero de bloqueios, menos processamento, menor quantidade de mem�ria utilizada
-- RUIM -> Menor concorr�ncia. S�o bloqueados mais registros do que o necess�rio
SELECT * FROM VIE_BLOQUEIOS


-- Descartar altera��es
ROLLBACK

--------------------------------------------------------
-- N�veis de isolamento entre os processos de transa��o
--------------------------------------------------------
-- O n�vel padr�o � READ COMMITTED 
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

-- EXEMPLO 6 ---------------------------------------------------------------------------
-- para esta sess�o (enquanto estiver aberta)
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN TRAN

-- V� at� a outra janela e inicie processo de transa��o
-- e fa�a update em produtos.
--
-- Depois volte para c� e execute este SELECT
-- Vai funcionar porque configuramos "Dirty-read" como padr�o
-- Estamos consultando dados n�o confirmados
SELECT * FROM PRODUTOS ORDER BY COD_TIPO
--
ROLLBACK
-- Finalize a transa��o da outra janela



SET TRANSACTION ISOLATION LEVEL READ COMMITTED


