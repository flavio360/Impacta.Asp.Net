/*------------------------------------------------------------------
            BUILD-IN DATA TYPES - P�G 90

    Alfanum�ricos de 1 byte por caractere (Padr�o ANSI)
    
		CHAR( T ):		Alfanum�rico de tamanho T. Sempre ocupar� T bytes.
		VARCHAR( T ):	Alfanum�rico de tamanho m�ximo T. A quantidade de 
						bytes ocupada depender� do dado armazenado no campo.
		VARCHAR( max ):	Texto de tamanho ilimitado ( 2GB ou 2 bilh�es de caracteres)
		antigo TEXT, genericamente conhecido como MEMO
		

        Exemplo: Imagine um campo do tipo CHAR(2) e que nele tenhamos gravado a 
                 palavra 'OI'. Seu conte�do ser�
				 select ascii('O')
                 1o. Byte   2o. Byte
                 01001111   01001001
                    |          |
                    |          +----------- C�digo ASCII da letra I (73)
                    +---------------------- C�digo ASCII da letra O (79)
                  
    Alfanum�ricos de 2 bytes por caractere (Padr�o UNICODE)
    
		NCHAR( T ):		Alfanum�rico de tamanho T. Sempre ocupar� T bytes.
		NVARCHAR( T ):	Alfanum�rico de tamanho m�ximo T. A quantidade de 
						bytes ocupada depender� do dado armazenado no campo.
		NVARCHAR(MAX):	Texto de tamanho ilimitado ( 2GB ou 1 bilh�o de caracteres)		
		antigo NTEXT, genericamente conhecido como MEMO

        Exemplo: Imagine um campo do tipo NCHAR(2) e que nele tenhamos gravado a 
                 palavra 'OI'. Seu conte�do ser�

                   1o. Caractere          2o. Caractere
                 00000000 01001111      00000000 01001001
                         |                      |
                         |                      +----------- C�digo ASCII da letra I
                         +---------------------------------- C�digo ASCII da letra O


    Bin�rios
    
		BINARY( T ):	Bin�rio de tamanho T. Sempre ocupar� T bytes.
		VARBINARY( T ):	Bin�rio de tamanho m�ximo T. A quantidade de 
						bytes ocupada depender� do dado armazenado no campo.
		VARBINARY(MAX):	Bin�rio de tamanho ilimitado ( 2GB )		
		antigo IMAGE, genericamente conhecido como BLOB - Binary Large OBject
		
		Obs.: N�o existe uma forma padr�o para leitura e grava��o dos bytes para
		      este dipo de campo.
    
    Num�ricos inteiros

		TINYINT:		Inteiro de 0 a 255. Ocupa 1 byte.
		SMALLINT:		Inteiro de -32000 at� +32000. Ocupa 2 bytes.
		INT:			N�mero inteiro no intervalo de -2 bilh�es at� +2 bilh�es. Ocupa 4 bytes.
		BIGINT:			Inteiro de -9E18 at� +9E18. Ocupa 8 bytes.
    
    Num�ricos decimais    

		NUMERIC(4,2) --> 99.99

		NUMERIC( T,D ): N�mero com T algarismos e D casas decimais
		DECIMAL( T,D ): Id�ntico ao anterior
        FLOAT:          Armazena dados num�ricos de ponto flutuante sem permitir limitar
                        a quantidade de casas depois da v�rgula. Pode provocar erros de aproxima��o.
        REAL:           Armazena dados num�ricos de ponto flutuante sem permitir limitar
                        a quantidade de casas depois da v�rgula. Pode provocar erros de aproxima��o.
        MONEY:          Valores monet�rios no intervalo de -9E18 at� +9E18
        SMALLMONEY:     Valores monet�rios no intervalo de -2 bilh�es at� +2 bilh�es                   
                           
    Data e Hora:		
    
		DATETIME:		Data e hora no intervalo de 1/1/1753 at� 31/12/9999.
						Precis�o de 3.33 milisegundos.
		SMALLDATETIME:  Data e hora no intervalo de 1/1/1900 at� 1/6/2079
						Precis�o de 1 minuto.

		DATE:			Somente data no intervalo de 1/1/0001 at� 31/12/9999.
		TIME:			Somente hora
		DATETIME2:		Data e hora no intervalo de 1/1/0001 at� 31/12/9999.
						Precis�o de 100 nanosegundo.
-------------------------------------------------------------
/*
	NOME_PESSOA		VARCHAR(60,40,30,100) -- CHAR(50)
	CEP				VARCHAR/CHAR/INT/NUMERIC -> CHAR(8,9)
	CPF
	CNPJ
*/


