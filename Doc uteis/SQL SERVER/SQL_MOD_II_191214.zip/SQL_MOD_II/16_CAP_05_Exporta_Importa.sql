CREATE DATABASE CAP_5
GO
USE CAP_5

CREATE TABLE PESSOA 
(
	COD INT, 
	NOME VARCHAR(50)
)
GO

/*
	ODBC
	ADO - drivers OleDB
	ADO.Net
*/

--HABILITAR OPENROWSET COM SURFACE AREA CONFIGURATION!!!
EXEC sp_configure 'show advanced option', '1';
reconfigure
-- Habilita o uso das fun��es que acessam dados usando ADO
exec sp_configure 'Ad Hoc Distributed Queries',1
reconfigure
-- habilita o uso da procedure xp_cmdshell
exec sp_configure 'xp_cmdshell',1
reconfigure

EXEC xp_cmdshell 'dir *.*'

Select name, value_in_use
From sys.configurations
Where name = 'xp_cmdshell';
--OPENROWSET(DRIVER, STRING DE CONEX�O, SELECT)
--==================================================================
-- EXCEL
SELECT * FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'Excel 12.0;Database=C:\DADOS\PESSOA.XLS',
'SELECT COD, NOME FROM [NOMES$]')

SELECT * FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'Excel 12.0;Database=C:\DADOS\PESSOA.XLSX',
'SELECT  * FROM [NOMES$]')

SELECT * FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'Excel 8.0;Database=C:\DADOS\PESSOA.XLS',
'SELECT COD, NOME FROM [NOMES$]')

SELECT * FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'Excel 8.0;Database=C:\DADOS\PESSOA.XLSX',
'SELECT COD, NOME FROM [NOMES$]')

--IMPORTAR DADOS
INSERT INTO PESSOA (COD, NOME) output inserted.*
SELECT * FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'Excel 8.0;Database=C:\DADOS\PESSOA.XLS',
'SELECT COD, NOME FROM [NOMES$]')
WHERE COD NOT IN (SELECT COD FROM PESSOA)

SELECT * FROM PESSOA


--EXPORTAR DADOS
INSERT INTO OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'Excel 8.0;Database=C:\DADOS\PESSOA.XLSX',
'SELECT COD, NOME FROM [NOMES$]')
SELECT * FROM PESSOA

--==================================================================
-- MS-ACCESS

SELECT *
FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
-- nome do arquivo do access
'C:\Dados\Pedidos.accdb';
-- usu�rio, senha, nome_tabela
'admin';'',PEDIDOS)

-- join entre PEDIDOS do access e CLIENTES do SQL
SELECT P.*, C.NOME
   FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'C:\Dados\Pedidos.accdb';
'admin';'',PEDIDOS) P
   JOIN PEDIDOS.DBO.CLIENTES C ON P.CODCLI = C.CODCLI
WHERE P.NUM_PEDIDO > 1000

-- importar a tabela TIPOPRODUTO do access
CREATE TABLE TIPOPRODUTO (COD_TIPO INT PRIMARY KEY, TIPO VARCHAR(30))

INSERT INTO TIPOPRODUTO output inserted.*
SELECT *
   FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'C:\Dados\Pedidos.accdb';
      'admin';'',TIPOPRODUTO) 

SELECT * FROM TIPOPRODUTO
    
-- SELECT EM STORED PROCEDURE ===========
SELECT * 
FROM OPENROWSET( 'SQLNCLI11',
  'Server=localhost;Trusted_Connection=yes',
   'EXEC pedidos..STP_MAIOR_PEDIDO 2008')
WHERE MES > 6
ORDER BY MAIOR_PEDIDO DESC

SELECT * INTO PRODUTOS
   FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
'C:\Dados\Pedidos.accdb';
      'admin';'',PRODUTOS) 

	  
SELECT * FROM PRODUTOS

--http://www.connectionstrings.com -> STRINGS DE CONEX�O
--==============================================================
/*
CRIE UM ARQUIVO CHAMADO BULK_INSERT.TXT COM O SEGUINTE CONTE�DO

1;CARLOS MAGNO P SOUZA;1959.11.12
2;SONIA REGINA;1964.7.1
3;PEDRO PAULO;1994.2.5
4;MARIA LUIZA;1997.10.29

*/
--DROP TABLE TESTE_BULK_INSERT
CREATE TABLE TESTE_BULK_INSERT
( CODIGO		INT, 
  NOME		VARCHAR(40),
  DATA_NASCIMENTO DATETIME )

SET DATEFORMAT YMD

BULK INSERT TESTE_BULK_INSERT
   -- caminho e arquivo na m�quina servidora
   FROM 'c:\DADOS\BULK_INSERT.txt'
   WITH
     (
        FIELDTERMINATOR =';',
        ROWTERMINATOR = '\n' -- ENTER
      )

SELECT * FROM TESTE_BULK_INSERT

-- Exportar para arquivo texto
-- com login do SQL
exec xp_cmdshell 'bcp "Select * from pedidos.dbo.produtos" queryout "c:\Dados\produtos.txt" -U sa -P Imp@ct@ -c'
-- com login do Windows
exec xp_cmdshell 'bcp "Select * from pedidos.dbo.produtos" queryout "c:\Dados\produtos2.txt" -w -T'

exec xp_cmdshell 'dir c:\Dados\*.txt'

-- com login do SQL
exec xp_cmdshell 'bcp "Select id_produto, cod_produto, descricao from pedidos.dbo.produtos" queryout "c:\Dados\produtos.csv" -U sa -P Imp@ct@ -c -t ;'
-- com login do Windows
exec xp_cmdshell 'bcp "Select * from pedidos.dbo.produtos" queryout "c:\Dados\produtos2.csv" -c -T -t ;'
exec xp_cmdshell 'dir c:\*.csv'

--- ALTERANDO O NOME DO ARQUIVO COM DATA/HORA -------------
declare @cmd varchar(2000) = 
   'bcp "Select * from pedidos.dbo.produtos" ' + 
   'queryout "c:\Dados\prod_' + format(getdate(),'yyMMdd_HHmmss') + 
   '.csv" -c -T -t ;'
exec xp_cmdshell @cmd;
go


/*
-c : Caracteres de 1 byte (ANSI)
-w : Caracteres de 2 bytes (UNICODE)
-T : Utiliza login do Windows
-U : Login do SQL
-P : senha do sql
-t : Especifica o delimitador de campo
-f : Expecifica um arquivo de formato

00001MAGNO         20191207
*/
-- Exportando para arquivo bin�rio
USE PEDIDOS
GO


-------------------------------------------------------------
-- trabalhando com campos BLOB (VARBINARY(max))
-------------------------------------------------------------
--TRUNCATE TABLE TABELACOMDOCSDENTRO
--Cria��o da tabela
CREATE TABLE TABELACOMDOCSDENTRO
( ID	INT	IDENTITY	PRIMARY KEY,
  DESCRICAO	VARCHAR(40),
  TIPO VARCHAR(5),
  DOCTO VARBINARY(MAX)
  )  

INSERT INTO TABELACOMDOCSDENTRO
Values ('Figura JPG', '.jpg', 
  (SELECT * FROM OPENROWSET(BULK 'C:\Dados\Figura.jpg', 
   SINGLE_BLOB) AS CategoryImage))

Insert Into TABELACOMDOCSDENTRO(DESCRICAO,TIPO, DOCTO)
Select 'Planilha Excel','.xls', 
    BulkColumn from Openrowset (Bulk 'C:\DADOS\PESSOA.XLS', Single_Blob) as Image

INSERT INTO TABELACOMDOCSDENTRO
Values ('Arquivo PDF', '.pdf', 
   (SELECT * FROM OPENROWSET(BULK 'C:\Dados\ANTES_DE_ATACHAR.pdf', SINGLE_BLOB) AS CategoryImage))

Insert Into TABELACOMDOCSDENTRO(DESCRICAO,TIPO, DOCTO)
Select 'Arquivo Texto','.txt', 
   BulkColumn from Openrowset (Bulk 'C:\DADOS\Bulk_insert.txt', Single_Blob) as Image

SELECT * FROM TABELACOMDOCSDENTRO

-- criando arquivo de formato para exporta��o
/*
https://msdn.microsoft.com/en-us/library/ms191479(v=sql.120).aspx
*/
declare @formatFile varchar(1000) = 'c:\dados\image_export.fmt'
DECLARE @command NVARCHAR(4000)
-- First write a format file which allows us to dump the image column without column 
SELECT @command = 'echo 9.0 >> '+ @formatFile
EXEC xp_cmdshell @command
SELECT @command = 'echo 1 >> '+ @formatFile
EXEC xp_cmdshell @command
SELECT @command = 'echo 1       SQLBINARY     0       0       ""   1     blob_data              "" >> '+ @formatFile
EXEC xp_cmdshell @command
go

DECLARE @CMD VARCHAR(2000) =
'BCP "SELECT DOCTO FROM pedidos.[dbo].TABELACOMDOCSDENTRO WHERE ID = 1" queryout "C:\DADOS\FiguraExp.jpg" -T -f "c:\dados\image_export.fmt"';
exec xp_cmdshell @cmd;
go

DECLARE @CMD VARCHAR(2000) =
'BCP "SELECT DOCTO FROM pedidos.[dbo].TABELACOMDOCSDENTRO WHERE ID = 2" queryout "C:\DADOS\PessoaExp.xls" -T -f "c:\dados\image_export.fmt"';

exec xp_cmdshell @cmd;
go

DECLARE @CMD VARCHAR(2000) =
'BCP "SELECT DOCTO FROM pedidos.[dbo].TABELACOMDOCSDENTRO WHERE ID = 3" queryout "C:\DADOS\AntesDeAtacharExp.pdf" -T -f "c:\dados\image_export.fmt"';

exec xp_cmdshell @cmd;
GO

--=================================================================                       
EXEC SP_HELPSERVER     
-- Acesso simult�neo a 2 servidores SQL
EXEC SP_ADDLINKEDSERVER '172.16.20.93'
--EXEC SP_ADDLINKEDSERVER 'P47_INSTRUTOR'
EXEC SP_HELPSERVER     

--update PEDIDOS..CLIENTES set FANTASIA = 'MAGNO TESTE'
--WHERE CODCLI = 3

SELECT * FROM [172.16.20.93].PEDIDOS.DBO.CLIENTES

SELECT P.NUM_PEDIDO, P.DATA_EMISSAO, C.NOME, c.FANTASIA
FROM PEDIDOS.DBO.PEDIDOS P 
     JOIN [172.16.20.93].PEDIDOS.DBO.CLIENTES C
     ON P.CODCLI = C.CODCLI

SELECT * FROM [172.16.16.46].PEDIDOS.DBO.CLIENTES

UPDATE [172.16.16.46].PEDIDOS.DBO.PRODUTOS
SET PRECO_VENDA = 2*PRECO_CUSTO

SELECT * FROM [172.16.16.46].PEDIDOS.DBO.PRODUTOS


EXEC SP_HELPSERVER 

EXEC SP_DROPSERVER '172.16.16.46'    

EXEC SP_HELPSERVER 

-- Usando login do SQL

EXEC SP_ADDLINKEDSERVER '172.16.16.46'

/*
EXEC SP_ADDLINKEDSRVLOGIN @RmtSrvName = '172.16.16.46',
                          @UseSelf = 'false',
                          @localLogin = 'sa',
                          @rmtUser = 'sa',
                          @rmtPassword = 'Imp@ct@'
*/                          

/*
	<alunos>
		<aluno nome="magno" cpf="ksdjfsdlk" email="kfjsdlfkj" />
		<aluno nome="magno" cpf="ksdjfsdlk" email="kfjsdlfkj" />

		<aluno>
			<nome>magno</nome>
			<cpf>lskadjlasdj</cpf>
			...
		</aluno>
	</alunos>
*/
---------------------------------------------------------------USANDO XML RAW
USE PEDIDOS

-- 1. Exercicio: A Partir da tabela EMPREGADOS, gerar o XML a seguir (sem tag principal)
/*
<row CODFUN="1" NOME="OLAVO C. PASSA" DATA_ADMISSAO="1986-10-05T00:00:00" SALARIO="1234.00" />
<row CODFUN="2" NOME="JOSE H. ROMEU LEITAO" DATA_ADMISSAO="1987-05-02T00:00:00" SALARIO="600.00" />
<row CODFUN="3" NOME="Euvira Loka" DATA_ADMISSAO="1986-10-05T00:00:00" SALARIO="2400.00" />
...
*/
SELECT CODFUN, NOME, DATA_ADMISSAO, SALARIO
FROM EMPREGADOS
FOR XML RAW

-- 2. A partir da tabela CLIENTES, gerar o XML a seguir (sem tag principal)
/*
<row CODCLI="3" NOME="AUGUSTO'S FOLHINHAS LTDA" ENDERECO="RODOVIA SP 294 KM 453" ESTADO="SP" />
<row CODCLI="4" NOME="ASSIS BRINDES COMERCIO INDUSTRIA LTDA" ENDERECO="R.COMENDADOR JOSE ZILLO,401" ESTADO="SP" />
<row CODCLI="5" NOME="AVEL APOLIMARIO VEICULOS S.A" ENDERECO="AV.DR JOSE FORMARI,550" ESTADO="SP" />
<row CODCLI="6" NOME="ANTONIO M.DE SOUZA" ENDERECO="R.RONDINIA,71" ESTADO="PR" />
*/


-- 3. A partir da tabela EMPREGADOS, gere o XML a seguir
/*
<Empregados>
  <Empregado CODFUN="1" NOME="OLAVO C. PASSA" DATA_ADMISSAO="1986-10-05T00:00:00" SALARIO="1234.00" />
  <Empregado CODFUN="2" NOME="JOSE H. ROMEU LEITAO" DATA_ADMISSAO="1987-05-02T00:00:00" SALARIO="600.00" />
  <Empregado CODFUN="3" NOME="Euvira Loka" DATA_ADMISSAO="1986-10-05T00:00:00" SALARIO="2400.00" />
  <Empregado CODFUN="4" NOME="PAULO CESAR JUNIOR" DATA_ADMISSAO="1987-05-06T00:00:00" SALARIO="600.00" />
  ...
</Empregados>  
*/
SELECT CODFUN, NOME, DATA_ADMISSAO, SALARIO
FROM EMPREGADOS
FOR XML RAW('Empregado'), ROOT('Empregados')
--
SELECT *
FROM EMPREGADOS Funcionario
FOR XML AUTO, ROOT('Funcionarios')
GO
-----------------------------------------------------------------
--             GRAVANDO O RESULTADO EM ARQUIVO .XML            --
-----------------------------------------------------------------
-- Criar uma view contendo o SELECT que gera o XML
CREATE VIEW VIE_XML_EMPREGADOS(COLUNA_XML) AS
SELECT CODFUN, NOME, DATA_ADMISSAO, SALARIO
FROM EMPREGADOS Funcionario
FOR XML AUTO, ROOT('Empregados')
GO
-- use o comando bcp para gerar o xml
DECLARE @CMD varchar(1000) = 
 'bcp "select * from pedidos..vie_xml_empregados" queryout C:\dados\empregados.xml -w -T'
exec xp_cmdshell @cmd 


-- 4. A partir da tabela CLIENTES, gerar o XML a seguir
/*
<Clientes>
  <Cliente CODCLI="3" NOME="AUGUSTO'S FOLHINHAS LTDA" ENDERECO="RODOVIA SP 294 KM 453" ESTADO="SP" />
  <Cliente CODCLI="4" NOME="ASSIS BRINDES COMERCIO INDUSTRIA LTDA" ENDERECO="R.COMENDADOR JOSE ZILLO,401" ESTADO="SP" />
  <Cliente CODCLI="5" NOME="AVEL APOLIMARIO VEICULOS S.A" ENDERECO="AV.DR JOSE FORMARI,550" ESTADO="SP" />
  ...
</Clientes>  
*/




-- 5. Usando a tabela EMPREGADOS, gere o XML a seguir (um elemento para cada campo)
/*
<Empregados xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Empregado>
    <CODFUN>1</CODFUN>
    <NOME>OLAVO C. PASSA</NOME>
    <DATA_ADMISSAO>1986-10-05T00:00:00</DATA_ADMISSAO>
    <SALARIO>1234.00</SALARIO>
  </Empregado>
  ...
  <Empregado>
    <CODFUN>44</CODFUN>
    <NOME>JORGE DOS SANTOS ROCHA JUNIOR</NOME>
    <DATA_ADMISSAO>2000-07-01T00:00:00</DATA_ADMISSAO>
    <SALARIO xsi:nil="true" />
  </Empregado>
  ...
</Empregados>  
*/
insert into empregados (nome) values ('TESTE NULO')

SELECT CODFUN, NOME, DATA_ADMISSAO, SALARIO
FROM EMPREGADOS
FOR XML RAW('Empregado'), ROOT('Empregados'), ELEMENTS XSINIL

-- XSINIL garante que todos os campos aparecer�o no XML.
-- sem isso, campos com conte�do NULL n�o s�o exportados

-- 6. Usando a tabela CLIENTES, gere o XML a seguir (um elemento para cada campo)
/*
<Clientes>
  <Cliente>
    <CODCLI>3</CODCLI>
    <NOME>AUGUSTO'S FOLHINHAS LTDA</NOME>
    <ENDERECO>RODOVIA SP 294 KM 453</ENDERECO>
    <ESTADO>SP</ESTADO>
  </Cliente>
  <Cliente>
    <CODCLI>4</CODCLI>
    <NOME>ASSIS BRINDES COMERCIO INDUSTRIA LTDA</NOME>
    <ENDERECO>R.COMENDADOR JOSE ZILLO,401</ENDERECO>
    <ESTADO>SP</ESTADO>
  </Cliente>
  ...
</ClienteS>  
*/



-- 7. Hierarquia (EMPREGADOS e seus DEPENDENTES) - 1 tag todos os campos
/*
<Empregados>
  <Empregado CODFUN="1" NOME="OLAVO C. PASSA" DATA_ADMISSAO="1986-10-05T00:00:00" SALARIO="1234.00">
    <Dependente CODDEP="1" NOME="C. COZINHA" />
  </Empregado>
  <Empregado CODFUN="2" NOME="JOSE H. ROMEU LEITAO" DATA_ADMISSAO="1987-05-02T00:00:00" SALARIO="600.00">
    <Dependente CODDEP="1" NOME="C. ENXUGA" />
    <Dependente CODDEP="2" NOME="Leit�ozinho" />
    <Dependente CODDEP="3" NOME="Romeuzinho" />
    <Dependente CODDEP="4" NOME="H.zinho" />
    <Dependente CODDEP="5" NOME="Mariazinha" />
    <Dependente CODDEP="6" NOME="Teste" />
  </Empregado>
  <Empregado CODFUN="3" NOME="Euvira Loka" DATA_ADMISSAO="1986-10-05T00:00:00" SALARIO="2400.00">
    <Dependente CODDEP="1" NOME="Dois Berto" />
  </Empregado>
  ...
</Empregados>
*/
--------------------------------------------------------------USANDO XML AUTO
SELECT Empregado.CODFUN, Empregado.NOME, Empregado.DATA_ADMISSAO, Empregado.SALARIO, 
       Dependente.CODDEP, Dependente.NOME, Dependente.DATA_NASCIMENTO
FROM EMPREGADOS Empregado JOIN DEPENDENTES Dependente 
     ON Empregado.CODFUN = Dependente.CODFUN
-- ordernar por coluna que mantenha todos os dependentes
-- de um mesmo empregado JUNTOS
ORDER BY Empregado.CODFUN
FOR XML AUTO, ROOT('Empregados')

-- 8. Hierarquia (EMPREGADOS e seus DEPENDENTES) - 1 tag para cada campo
/*
<Empregados xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Empregado>
    <CODFUN>1</CODFUN>
    <NOME>OLAVO C. PASSA</NOME>
    <DATA_ADMISSAO>1986-10-05T00:00:00</DATA_ADMISSAO>
    <SALARIO>1234.00</SALARIO>
    <Dependente>
      <CODDEP>1</CODDEP>
      <NOME>C. COZINHA</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
  </Empregado>
  <Empregado>
    <CODFUN>2</CODFUN>
    <NOME>JOSE H. ROMEU LEITAO</NOME>
    <DATA_ADMISSAO>1987-05-02T00:00:00</DATA_ADMISSAO>
    <SALARIO>600.00</SALARIO>
    <Dependente>
      <CODDEP>1</CODDEP>
      <NOME>C. ENXUGA</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
    <Dependente>
      <CODDEP>2</CODDEP>
      <NOME>Leit�ozinho</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
    <Dependente>
      <CODDEP>3</CODDEP>
      <NOME>Romeuzinho</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
    <Dependente>
      <CODDEP>4</CODDEP>
      <NOME>H.zinho</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
    <Dependente>
      <CODDEP>5</CODDEP>
      <NOME>Mariazinha</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
    <Dependente>
      <CODDEP>6</CODDEP>
      <NOME>Teste</NOME>
      <DATA_NASCIMENTO xsi:nil="true" />
    </Dependente>
  </Empregado>
  ...
</Empregados>  
*/
SELECT Empregado.CODFUN Codigo, Empregado.NOME, Empregado.DATA_ADMISSAO, Empregado.SALARIO, 
       Dependente.CODDEP, Dependente.NOME, Dependente.DATA_NASCIMENTO
FROM EMPREGADOS Empregado JOIN DEPENDENTES Dependente ON Empregado.CODFUN = Dependente.CODFUN
ORDER BY Empregado.CODFUN
FOR XML AUTO, ROOT('Empregados'), ELEMENTS XSINIL

-- 9. Hierarquia (TIPOPRODUTO e seus PRODUTOS) - 1 tag para cada campo
/*
<Tipos>
  <Tipo>
    <COD_TIPO>1</COD_TIPO>
    <TIPO>ABRIDOR</TIPO>
    <Produto>
      <ID_PRODUTO>1</ID_PRODUTO>
      <DESCRICAO>ABRIDOR SACA &amp; ROLHA</DESCRICAO>
      <PRECO_VENDA>0.1081</PRECO_VENDA>
    </Produto>
  </Tipo>
  <Tipo>
    <COD_TIPO>2</COD_TIPO>
    <TIPO>PORTA LAPIS</TIPO>
    <Produto>
      <ID_PRODUTO>2</ID_PRODUTO>
      <DESCRICAO>PORTA-LAPIS COM PEZINHO</DESCRICAO>
      <PRECO_VENDA>2.4171</PRECO_VENDA>
    </Produto>
  </Tipo>
  <Tipo>
    <COD_TIPO>3</COD_TIPO>
    <TIPO>REGUA</TIPO>
    <Produto>
      <ID_PRODUTO>3</ID_PRODUTO>
      <DESCRICAO>REGUA DE 20 CM</DESCRICAO>
      <PRECO_VENDA>1.5151</PRECO_VENDA>
    </Produto>
  </Tipo>
  ...
</Tipos>  
*/
SELECT Tipo.COD_TIPO, Tipo.TIPO, Produto.ID_PRODUTO, Produto.DESCRICAO,
       Produto.PRECO_VENDA
FROM TIPOPRODUTO Tipo 
     JOIN PRODUTOS Produto ON Tipo.COD_TIPO = Produto.COD_TIPO
-- IMPORTANTE ordenar pelo campo que liga as duas tabelas
-- para manter mestre e detalhe juntos
ORDER BY Tipo.COD_TIPO
FOR XML AUTO, ROOT('Tipos'), ELEMENTS XSINIL;

-- 10. Idem anterior mas mudando os nomes das Tags
/*
<Tipos xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Tipo>
    <Codigo>1</Codigo>
    <Tipo>ABRIDOR</Tipo>
    <Produto>
      <Id>1</Id>
      <NomeProduto>ABRIDOR SACA &amp; ROLHA</NomeProduto>
      <PrecoVenda>0.1081</PrecoVenda>
    </Produto>
  </Tipo>
  <Tipo>
    <Codigo>2</Codigo>
    <Tipo>PORTA LAPIS</Tipo>
    <Produto>
      <Id>2</Id>
      <NomeProduto>PORTA-LAPIS COM PEZINHO</NomeProduto>
      <PrecoVenda>2.4171</PrecoVenda>
    </Produto>
  </Tipo>
  <Tipo>
    <Codigo>3</Codigo>
    <Tipo>REGUA</Tipo>
    <Produto>
      <Id>3</Id>
      <NomeProduto>REGUA DE 20 CM</NomeProduto>
      <PrecoVenda>1.5151</PrecoVenda>
    </Produto>
  </Tipo>
  ...
</Tipos>  
*/
SELECT Tipo.COD_TIPO Codigo, Tipo.TIPO Tipo, Produto.ID_PRODUTO Id, 
       Produto.DESCRICAO NomeProduto, Produto.PRECO_VENDA PrecoVenda
FROM TIPOPRODUTO Tipo 
     JOIN PRODUTOS Produto ON Tipo.COD_TIPO = Produto.COD_TIPO
ORDER BY Tipo.COD_TIPO
FOR XML AUTO, ROOT('Tipos'), ELEMENTS XSINIL;

--==========================================================
-- Ler dados de XML
--==========================================================
-- Declarando uma vari�vel XML 
DECLARE @XML XML
-- Carrega as informa��es da consulta para a vari�vel XML, utilizando o FOR XML:
-- na apostila, o XML lido N�O TEM ELEMENTO RAIZ, o que na pr�tica n�o existe
SET @XML = 
	(
	SELECT	CODFUN, NOME, DATA_ADMISSAO 
	FROM EMPREGADOS AS EMPREGADO
	FOR XML AUTO, root('EMPREGADOS'), ELEMENTS
    )

--print cast(@xml as varchar(8000))

SELECT @XML.query('EMPREGADOS/EMPREGADO')
SELECT @XML.query('EMPREGADOS/EMPREGADO/NOME')
SELECT @XML.query('EMPREGADOS/EMPREGADO[1]/NOME')
SELECT @XML.query('EMPREGADOS/EMPREGADO[10]/NOME')
SELECT @XML.query('EMPREGADOS/EMPREGADO[NOME=''OLAVO C. PASSA'']')
SELECT @XML.query('EMPREGADOS/EMPREGADO[NOME=''OLAVO C. PASSA'']/DATA_ADMISSAO')
GO
---

DECLARE @XML XML
SET @XML = 
	(SELECT	CODFUN, NOME, DATA_ADMISSAO FROM EMPREGADOS AS EMPREGADO
	FOR XML AUTO,root('EMPREGADOS'), ELEMENTS )
	
SELECT @XML.value('(EMPREGADOS/EMPREGADO/NOME)[1]', 'varchar(100)')
SELECT @XML.value('(EMPREGADOS/EMPREGADO/CODFUN)[15]', 'INT')
GO

DECLARE @XML XML
SET @XML = 
	(SELECT	CODFUN, NOME, DATA_ADMISSAO FROM EMPREGADOS AS EMPREGADO
	FOR XML AUTO, ELEMENTS )
	
SELECT @XML.exist('EMPREGADO/CODFUN' )
SELECT @XML.exist('(EMPREGADO/CODFUN)[35]' )
SELECT @XML.exist('(EMPREGADO/CODFUN)[3500]' )

SELECT	CASE  @XML.exist('(EMPREGADO/CODFUN)[3500]' )
		WHEN 0 THEN 'N�o EXISTE'
		WHEN 1 THEN 'EXISTE' END 
GO








