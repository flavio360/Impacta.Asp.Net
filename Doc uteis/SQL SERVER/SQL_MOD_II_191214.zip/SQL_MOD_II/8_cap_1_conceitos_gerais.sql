/*
   Arquitetura CLIENTE / SERVIDOR
      .Bancos de dados locais (ACCESS, DBASE, PARADOX...)
      .Bancos de dados cliente x servidor     (SGBD)
      .thin client - fat server
      .thin server - fat client
--------------------------------------------------
   OLTP (On-Line Transaction Processing): Banco de dados operacional, aquele que est�
      diariamente sofrendo processos de inclus�o, exclus�o e altera��o. Os dados precisam
      ser din�micos, uma altera��o feita por um usu�rio precisa estar imediatamente
      dispon�vel para os outros usu�rios. Altamente normalizado.

   OLAP (On-Line Analytical Processing): Banco de dados utilizado para extra��o de 
      dados estat�siticos, relat�rios de desempenho etc... Gera informa��es gereinciais
      e estrat�gicas para a diretoria da empresa. Pouco normalizado.
      Periodicamente os dados do banco de dados OLTP s�o transferidos para o banco de
      dados OLAP num processo chamado de CARGA.
-------------------------------------------------------------------------------------------

   Bancos de dados do sistema
      .Resource: N�o temos acesso direto a este banco. Possui tabelas de sistema
                 e � utilizado quando atualizamos vers�o do MS-SQL   
      .Master: Registra contas de usu�rio, bancos de dados de usu�rio.
      .TempDB: Armazena informa��es tempor�rias.
      .Model: Modelos para cria��o dos bancos de dados de usu�rio
      .MSDB: Armazena informa��es sobre tarefas pr�-programadas como backup, por exemplo.
*/

/*
	METADADOS 
	
	S�o os dados que comp�em toda a estrutura de um banco de dados. 
	Quando vemos os campos que formam a estrutura de uma tabela estamos vendo uma parte 
	dos metadados do banco de dados. Quando vemos quais s�o as constraints, 
	as stored procedures etc... estamos vendo parte dos metadados do banco de dados. 
	Os metadados ficam armazenados em tabelas de sistema como SYSOBJECTS, SYSCOLUMNS etc...
 
	S�o chamados de cat�logos os recursos existentes para extrairmos os metadados 
	do banco de dados (Tabelas de cat�logo, Views de cat�logo e procedures de cat�logo:
*/
-- TABELAS DE SISTEMA
-- 1.
CREATE DATABASE TESTE
GO
USE TESTE
-- tabela de sistema
SELECT * FROM SYSOBJECTS ORDER BY NAME
-- view de catalogo
SELECT * FROM sys.objects
-- No Object explorer consulte TESTE->VIEWS->SYSTEM VIEWS
-- No Object explorer consulte TESTE->PROGRAMMABILITY->STORED PROCEDURES->SYSTEM STORED PROCEDURES
   -- Obs.: Utiliza click-direito para ver o c�digo fonte da procedure
-- No Object explorer consulte TESTE->PROGRAMMABILITY->FUNCTIONS->SYSTEM FUNCTIONS

-----------------------------------------------------------------
-- 2.
USE PEDIDOS
-- Armazena todos os objetos do banco de dados
SELECT * FROM SYSOBJECTS
--
SELECT * FROM SYS.OBJECTS

-- Tabelas de usu�rios
-- 3.
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'U' -- 1861581670
-- Chaves estrangeiras
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'F'
-- Chaves prim�rias
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'PK'

-- 4.
-- gerando um script
SELECT 'ALTER TABLE ' + NAME + ' ADD DATA_ALTERACAO DATETIME'
FROM SYSOBJECTS WHERE XTYPE = 'U'

-- 5.
-- SELF-JOIN
SELECT CODFUN, NOME, COD_SUPERVISOR
FROM EMPREGADOS

SELECT F.CODFUN, F.NOME, F.COD_SUPERVISOR, 
       S.CODFUN, S.NOME AS SUPERVISOR
FROM EMPREGADOS F 
     JOIN EMPREGADOS S ON F.COD_SUPERVISOR = S.CODFUN

-- 5.1
SELECT ID, NAME, PARENT_OBJ FROM SYSOBJECTS
WHERE XTYPE = 'PK'

SELECT * FROM SYSOBJECTS WHERE ID = 5575058

-- 5.2
-- Tabelas e suas chaves prim�rias
SELECT T.NAME AS TABELA, PK.NAME AS CHAVE_PRIMARIA
FROM SYSOBJECTS T 
   JOIN SYSOBJECTS PK ON T.id = PK.parent_obj
WHERE T.xtype = 'U'

-- 6.
-- Colunas existentes nas tabelas do banco de dados
SELECT * FROM SYSCOLUMNS -- Observe a coluna ID

-- 6.1
-- Colunas das tabelas do banco de dados
SELECT T.NAME AS TABELA, C.NAME AS COLUNAS
FROM SYSOBJECTS T JOIN SYSCOLUMNS C ON T.id = C.id
WHERE T.XTYPE = 'U'
ORDER BY T.NAME, C.COLID

-- 6.2
-- Colunas de uma tabela do banco de dados
SELECT T.NAME AS TABELA, C.NAME AS COLUNAS, C.xtype
FROM SYSOBJECTS T JOIN SYSCOLUMNS C ON T.id = C.id
WHERE T.XTYPE = 'U' AND T.name = 'PEDIDOS'
ORDER BY T.NAME, COLID

-- 6.3.
-- Tabelas que t�m um determinado campo
SELECT T.NAME AS TABELA, C.NAME AS COLUNAS, C.xtype
FROM SYSOBJECTS T JOIN SYSCOLUMNS C ON T.id = C.id
WHERE T.XTYPE = 'U' AND C.name = 'NOME'
ORDER BY T.NAME, COLID

-- 6.4
select * from systypes

-- Mostrar tamb�m o tipo de cada coluna
SELECT T.NAME AS TABELA, C.NAME AS COLUNAS, C.xtype, DT.NAME
FROM SYSOBJECTS T JOIN SYSCOLUMNS C ON T.id = C.id
                  JOIN SYSTYPES DT ON C.xtype = DT.xusertype
WHERE T.XTYPE = 'U' AND T.name = 'TABELACAR'
ORDER BY C.COLID

-- 6.5
-- Mais informa��es sobre a estrutura da tabela
SELECT T.NAME AS TABELA, C.NAME AS COLUNAS, C.xtype, DT.NAME,
       C.length AS BYTES, C.xprec AS PRECISAO, C.xscale AS DECIMAIS
FROM SYSOBJECTS T JOIN SYSCOLUMNS C ON T.id = C.id
                  JOIN SYSTYPES DT ON C.xtype = DT.xusertype
WHERE T.XTYPE = 'U' AND T.name = 'PEDIDOS'

EXEC sp_help PEDIDOS

-- 7
-- VIEWS DE CAT�LOGO
SELECT * FROM sys.tables

EXEC sp_helptext 'sys.foreign_keys'

-- chaves �nicas e chaves prim�rias
SELECT * FROM sys.key_constraints
-- chaves chaves estrangeiras
SELECT * FROM sys.foreign_keys
-- check constraints
SELECT * FROM sys.check_constraints
-- defaults
SELECT * FROM sys.default_constraints

-- colunas de cada tabela
SELECT * FROM sys.columns
-- tipos de dados
SELECT * FROM sys.types

-- 8.
-- Tabelas e suas chaves estrangeiras
SELECT * FROM SYSOBJECTS 
WHERE XTYPE = 'F'
-- observe a coluna parent_id de FK_PRODUTOS_UNIDADES = 357576312
SELECT * FROM SYSOBJECTS 
WHERE ID = 357576312

-- 8.1
SELECT F.NAME AS NOME_FK, T.NAME AS NOME_TABELA
FROM SYSOBJECTS F JOIN SYSOBJECTS T ON F.parent_obj = T.id
WHERE F.XTYPE = 'F'

-- 8.2 
8
/*
constraint_object_id constraint_column_id parent_object_id parent_column_id referenced_object_id referenced_column_id
-------------------- -------------------- ---------------- ---------------- -------------------- --------------------
2053582354           1                    1861581670       6                5575058              1
1957582012           1                    325576198        2                69575286             1

	constraint_object_id : ID da chave estrangeira
	constraint_column_id : Posi��o da coluna dentro da chave estrangeira
	parent_object_id     : ID da tabela dona da chave estrangeira (detalhe)
	parent_column_id     : ID da coluna da tabela que � chave estrangeira
	referenced_object_id : ID da tabela mestre da chave estrangeira
	referenced_column_id : ID da coluna da tabela mestre 
*/
-- nome da chave estrangeira
SELECT * FROM SYS.sysobjects WHERE ID = 2053582354
-- FK_EMPREGADOS_TABELACAR

-- tabela que � dona da chave estrangeira (filtra pelo PARENT_OBJ da consulta anterior)
SELECT * FROM SYS.sysobjects WHERE ID =1861581670
-- EMPREGADOS

-- campo de empregados que � chave estrangeira (ID da tabela EMPREGADOS e posi��o da coluna)
SELECT * FROM SYS.syscolumns WHERE ID =1861581670 and COLID = 6
-- COD_CARGO

-- tabela mestre da chave estrangeira (parent_object_id)
SELECT * FROM SYS.sysobjects WHERE ID = 5575058
-- TABELACAR

-- campo da tabela mestre
SELECT * FROM SYS.syscolumns WHERE ID =5575058 and COLID = 1
-- COD_CARGO

-- juntando tudo...
SELECT FK.NAME AS FK_NAME, FKT.NAME AS FK_TABLE,
FKCL.name AS FK_COLUMN, 
       FKR.NAME AS FK_REFER_TABLE ,
	   RCL.NAME AS FK_REFER_COLUMN
FROM SYS.foreign_key_columns FKC
JOIN SYSOBJECTS FK ON FKC.constraint_object_id = FK.id
JOIN SYSOBJECTS FKT ON FKC.parent_object_id = FKT.id
JOIN SYSOBJECTS FKR ON FKC.referenced_object_id = FKR.id
JOIN SYSCOLUMNS FKCL ON FKC.parent_object_id = FKCL.ID AND
                        FKC.parent_column_id = FKCL.colid
JOIN SYSCOLUMNS RCL ON FKC.referenced_object_id = RCL.ID AND
                       FKC.referenced_column_id = RCL.colid
ORDER BY 2

-- PROCEDURES DE CAT�LOGO
-- tabelas do banco de dados
exec sp_tables
-- constraints de uma tabela
exec sp_helpconstraint PEDIDOS

-- colunas de uma tabela
exec sp_columns pedidos
-- Campos que formam a chave prim�ria de uma tabela
exec sp_pkeys ITENSPEDIDO
-- Estrutura de uma tabela
exec sp_help PEDIDOS

-- c�digo fonte que gerou uma view
exec sp_helptext 'sys.all_objects'
exec sp_helptext 'sys.objects'
exec sp_helptext 'sys.key_constraints'

exec sp_helptext 'sp_help'

-- guarda o c�digo de programa��o de procedures,
-- views, functions etc
SELECT * FROM SYSCOMMENTS

SELECT * FROM SYSCOMMENTS
WHERE text LIKE '%PEDIDOS%'


------------------------------------------------------
-- Grupos de comandos da linguagem T-SQL
------------------------------------------------------
-- DML - Data Manipulation Language (Comandos de Manipula��o de dados)
	-- SELECT, INSERT, DELETE, UPDATE
-- DDL - Data Definition Language (Comandos de defini��o de estrutura dos dados)
	-- CREATE, ALTER, DROP
-- DCL - Data Control Language (Comandos que controlam direitos dos usu�rios)
	-- GRANT, REVOKE, DENY
	
-----------------------------------------------------
-- Nomes dos objetos
-----------------------------------------------------
USE PEDIDOS
-- Nome parcialmente qualificado
SELECT * FROM EMPREGADOS
-----------------------------

USE master -- PEDIDOS N�O EST� MAIS EM USO
-- Nome parcialmente qualificado
SELECT * FROM PEDIDOS.DBO.EMPREGADOS
SELECT * FROM PEDIDOS..EMPREGADOS
-----------------------------

EXEC sp_addlinkedserver [21P8_INSTRUTOR]

SELECT * FROM sys.servers
-- Nome totalmente qualificado
SELECT * FROM [21P8_INSTRUTOR].PEDIDOS.DBO.EMPREGADOS

