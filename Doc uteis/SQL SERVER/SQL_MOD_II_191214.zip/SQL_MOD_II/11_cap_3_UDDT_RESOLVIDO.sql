-- UDDT - User Defined Data Types - 94
CREATE DATABASE TESTE_UDDT
GO
USE TESTE_UDDT
GO


SELECT * FROM SYSTYPES

-- UDDT - User Defined Data Types
-- 1o. Passo: Criar os UDDTs
-- a. Para campos NOME (pessoa). Deve ser VARCHAR(40) e n�o eceitar nulo
EXEC SP_ADDTYPE 'TYPE_NOME_PESSOA', 'VARCHAR(40)','NOT NULL'
-- b. Para campos NOME (empresa). Deve ser VARCHAR(60) e n�o eceitar nulo
--    TYPE_NOME_EMPRESA
EXEC SP_ADDTYPE 'TYPE_NOME_EMPRESA', 'VARCHAR(60)','NOT NULL'
-- c. Para armazenar pre�os de produtos ou servi�os.
--    TYPE_PRECO: Deve ser NUMERIC( 12,2 ) e n�o aceitar nulo
EXEC SP_ADDTYPE 'TYPE_PRECO', 'NUMERIC(12,2)','NOT NULL'
-- d. Para armazenar 'S' (sim) ou 'N' (n�o). Pode ser nulo
--    TYPE_SN
EXEC SP_ADDTYPE 'TYPE_SN', 'CHAR(1)','NULL'
-- e. Para armazenar a data de cadastro de um registro de uma tabela
--    TYPE_DATA_CAD: pode ser nulo
EXEC SP_ADDTYPE 'TYPE_DATA_CAD', 'DATETIME'
/*
   -- exclui um UDDT criado anteriormente
   EXEC SP_DROPTYPE 'TYPE_SN'
*/
-- Consultando os DATATYPES
SELECT * FROM SYSTYPES
--
SELECT * FROM SYSTYPES WHERE UID = 1
GO
-- 2o Passo: Criar regras de valida��o
-- a. Para pre�os (TYPE_PRECO). O pre�o n�o pode ser negativo.
--    Portanto tem que ser um n�mero maior ou igual a zero
CREATE RULE R_PRECOS  AS @PRECO >= 0
GO
-- b. Para campos que devam aceitar somente 'S' ou 'N' (TYPE_SN)
--    R_SN
CREATE RULE R_SN  AS @SN IN ('S','N')
GO
-- c. Para campos do tipo dada de cadastro TYPE_DATA_CAD
--    R_DATA_CAD: N�o deve aceitar uma data futura 
CREATE RULE R_DATA_CAD  AS @DT <= GETDATE()
GO


-- Consultando as regras de valida��o na tabela SYSOBJECTS
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'R'
SELECT * FROM SYSTYPES WHERE uid = 1

-- 3o. Passo: Associar as regras de valida��o
--            aos UDDTs
-- a. Associar R_PRECOS a TYPE_PRECO
EXEC SP_BINDRULE 'R_PRECOS' , 'TYPE_PRECO'
--                nome regra,  nome UDDT
-- b. Associar R_SN a TYPE_SN
EXEC SP_BINDRULE 'R_SN' , 'TYPE_SN'
-- c. Associar R_DATA_CAD a TYPE_DATA_CAD
EXEC SP_BINDRULE 'R_DATA_CAD' , 'TYPE_DATA_CAD'

-- Consultar os UDDTs
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'R'
SELECT * FROM SYSTYPES WHERE UID = 1

----------------------------- Simula a corre��o da regra
-- desligar a regra do UDDT
EXEC SP_UNBINDRULE 'TYPE_PRECO';
-- Apago a regra
DROP RULE R_PRECOS;
GO
-- Criar novamente a regra
CREATE RULE R_PRECOS  AS @PRECO >= 0
GO
-- Associar novamente
EXEC SP_BINDRULE 'R_PRECOS','TYPE_PRECO'
--------------------------------------------------------

GO
-- 4o. Passo: Cria��o de DEFAULTS
-- a. Criar DEFAULT para assumir a letra 'S' como padr�o
CREATE DEFAULT DEF_SN AS 'S'
GO
-- b. Criar DEFAULT para assumir a data e hora atual como padr�o
--    DEF_DATA_CAD
CREATE DEFAULT DEF_DATA_CAD AS GETDATE()
GO

-- Consultar os DEFAULTS
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'D'
SELECT * FROM SYSTYPES WHERE uid=1

-- 5o. Passo: Associar os DEFAULTS aos UDDTs
-- a. Associar DEF_SN a TYPE_SN
EXEC SP_BINDEFAULT 'DEF_SN', 'TYPE_SN'
-- b. Associar DEF_DATA_CAD a TYPE_DATA_CAD
EXEC SP_BINDEFAULT 'DEF_DATA_CAD', 'TYPE_DATA_CAD'

-- Consultar UDDTs
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'D'
SELECT * FROM SYSTYPES WHERE uid=1
/*
EXEC SP_UNBINDEFAULT 'TYPE_DATA_CAD'
*/

-- Comandos de programa��o ficam armazenados na tabela SYSCOMMENTS
SELECT * FROM SYSCOMMENTS WHERE ID = OBJECT_ID('DEF_SN')
SELECT * FROM SYSCOMMENTS WHERE ID = OBJECT_ID('R_PRECOS')

EXEC SP_HELPTEXT 'R_PRECOS'



-- TESTANDO
CREATE TABLE PRODUTOS
( COD_PROD		INT IDENTITY,
  DESCRICAO		VARCHAR(80),
  PRECO_CUSTO	TYPE_PRECO,
  PRECO_VENDA	TYPE_PRECO,
  DATA_CADASTRO TYPE_DATA_CAD,
  SN_ATIVO		TYPE_SN,
  CONSTRAINT PK_PRODUTOS PRIMARY KEY (COD_PROD) )
--
-- Vai gerar os valores de SN_ATIVO e DATA_CADASTRO
-- porque estes UDDT possuem valor default
INSERT INTO PRODUTOS ( DESCRICAO, PRECO_CUSTO, PRECO_VENDA )
VALUES ( 'TESTE 1', 1, 2 )
--
SELECT * FROM PRODUTOS

-- VAI DAR ERRO -> Pre�o NEGATIVO
INSERT INTO PRODUTOS ( DESCRICAO, PRECO_CUSTO, PRECO_VENDA )
VALUES ( 'TESTE 2', -1, 2 )
-----------------------------------------
SELECT * FROM SYSTYPES WHERE UID = 1

-- Tabelas de sistema
-- Armazena todos os datatypes dispon�veis
SELECT * FROM SYSTYPES
   -- name     : Nome do datatype
   -- domain   : ID da regra de valida��o associada ao datatype
   -- tdefault : ID do default associado ao datatype
   -- xtype    : ID do datatype nativo do MS-SQL
   -- xusertype: ID do datatype do usu�rio. Neste caso, quando
   --            � um datatype nativo, fica igual ao xtype 
SELECT UDDT.NAME, UDDT.XUSERTYPE, BIDT.NAME 
FROM SYSTYPES UDDT 
     JOIN SYSTYPES BIDT ON UDDT.XTYPE = BIDT.XUSERTYPE
WHERE UDDT.UID = 1
-- Armazena todos os objetos do banco de dados
SELECT * FROM SYSOBJECTS
   -- name     : Nome do objeto
   -- id       : N�mero identificador
   -- xtype    : Tipo do objeto
SELECT UDDT.NAME, UDDT.XUSERTYPE, BIDT.NAME, 
       R.name AS REGRA_VAL, D.name AS [DEFAULT]
FROM SYSTYPES UDDT 
     JOIN SYSTYPES BIDT ON UDDT.XTYPE = BIDT.XUSERTYPE
     LEFT JOIN SYSOBJECTS R ON UDDT.domain = R.ID
     LEFT JOIN SYSOBJECTS D ON UDDT.tdefault = D.ID
WHERE UDDT.UID = 1
-- Armazena o c�digo programavel dos objetos que possuem
-- c�digo de programa��o
SELECT * FROM SYSCOMMENTS
   -- id	   : ID do objeto dono do c�digo program�vel
   -- text     : C�digo program�vel ligado ao objeto 	

SELECT UDDT.NAME AS UDDT, UDDT.XUSERTYPE, BIDT.NAME AS TIPO_BASE, 
       R.name AS REGRA_VAL, D.name AS [DEFAULT],
       CM_R.TEXT AS CMD_RULE,
       CM_D.TEXT AS CMD_DEFAULT
FROM SYSTYPES UDDT 
     JOIN SYSTYPES BIDT ON UDDT.XTYPE = BIDT.XUSERTYPE
     LEFT JOIN SYSOBJECTS R ON UDDT.domain = R.ID
     LEFT JOIN SYSOBJECTS D ON UDDT.tdefault = D.ID
     LEFT JOIN SYSCOMMENTS CM_R ON R.ID = CM_R.ID
     LEFT JOIN SYSCOMMENTS CM_D ON D.ID = CM_D.ID
WHERE UDDT.UID = 1

-------------------------------------------------------------
-- EXERC�CIOS
-- 1. Criar um novo banco de dados chamado EXERC_UDDT
CREATE DATABASE EXERC_UDDT
GO
-- 2. Colocar em uso o banco de dados EXERC_UDDT
USE EXERC_UDDT
-- 3. Criar os seguintes UDDTs
/*
	TIPO_CODIGO			INT				NOT NULL
	TIPO_ENDERECO		VARCHAR(60)		NULL
	TIPO_FONE			CHAR(14)		NULL
	TIPO_SEXO			CHAR(1)			NOT NULL
	TIPO_ALIQUOTA		NUMERIC(4,2)	NULL
	TIPO_PRAZO			INT				NOT NULL	
*/
EXEC SP_ADDTYPE	TIPO_CODIGO		,	'INT'			,	'NOT NULL'
EXEC SP_ADDTYPE	TIPO_ENDERECO	,	'VARCHAR(60)'	,	'NULL'
EXEC SP_ADDTYPE	TIPO_FONE		,	'CHAR(14)'		,	'NULL'
EXEC SP_ADDTYPE	TIPO_SEXO		,	'CHAR(1)'		,	'NOT NULL'
EXEC SP_ADDTYPE	TIPO_ALIQUOTA	,	'NUMERIC(4,2)'	,   'NULL'
EXEC SP_ADDTYPE	TIPO_PRAZO		,	'INT'			,	'NOT NULL'
-- Listar os UDDTs que voc� acabou de criar
SELECT * FROM SYSTYPES WHERE UID = 1
GO
-- 4. Criar as regras de valida��o
/*
	R_SEXO			Aceita somente 'F' e 'M'
	R_ALIQUOTA		N�meros n�o negativos
    R_PRAZO			N�meros no intervalo de 1 at� 60
*/
CREATE RULE R_SEXO AS @S IN ('F','M')
GO
CREATE RULE R_ALIQUOTA AS @AL >= 0
GO
CREATE RULE R_PRAZO AS @P BETWEEN 1 AND 60
GO
-- Listar as regras de valida��o que voc� acabou de criar
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'R'

-- 5. Associar a regras aos seus UDDTs
/*
    R_SEXO ao UDDT TIPO_SEXO
    R_ALIQUOTA ao UDDT TIPO_ALIQUOTA
    R_PRAZO	ao UDDT TIPO_PRAZO	
*/    
EXEC SP_BINDRULE R_SEXO, TIPO_SEXO
EXEC SP_BINDRULE R_ALIQUOTA, TIPO_ALIQUOTA
EXEC SP_BINDRULE R_PRAZO, TIPO_PRAZO
GO
-- 6. Criar os seguintes objetos DEFAULT
/*
	D_SEXO			"M"
	D_ALIQUOTA		0 (ZERO)
	D_PRAZO			1
*/
CREATE DEFAULT	D_SEXO		AS	'M'
GO
CREATE DEFAULT	D_ALIQUOTA	AS	0 
GO
CREATE DEFAULT	D_PRAZO		AS	1
GO
-- Listar os defaults que voc� acabou de criar
SELECT * FROM SYSOBJECTS WHERE XTYPE = 'D'

-- 7. Associar os defaults
/*
	D_SEXO a TIPO_SEXO
	D_ALIQUOTA a TIPO_ALIQUOTA
	D_PRAZO a TIPO_PRAZO
*/
EXEC SP_BINDEFAULT	D_SEXO, TIPO_SEXO
EXEC SP_BINDEFAULT	D_ALIQUOTA, TIPO_ALIQUOTA
EXEC SP_BINDEFAULT	D_PRAZO, TIPO_PRAZO

-- 8. Criar a tabela PESSOAS
/*
	PESSOAS
	
	Obs.: A numera��o do campo c�digo precisa iniciar em 10
	
	COD_PESSOA			TIPO_CODIGO		autonumera��o		chave prim�ria
	NOME				VARCHAR(30)
	ENDERECO			TIPO_ENDERECO
	SEXO				TIPO_SEXO
	------------------------------------------------------------------------
*/
CREATE TABLE PESSOAS
(
	COD_PESSOA			TIPO_CODIGO		IDENTITY(10,1),
	NOME				VARCHAR(30),
	ENDERECO			TIPO_ENDERECO,
	SEXO				TIPO_SEXO
	CONSTRAINT PK_PESSOAS PRIMARY KEY (COD_PESSOA)
)
-- 9. Criar a tabela CONTAS
/*	
	CONTAS

	COD_CONTA			TIPO_CODIGO		autonumera��o		chave prim�ria
	VALOR				NUMERIC(10,2)
	QTD_PARCELAS		TIPO_PRAZO
	PORC_MULTA			TIPO_ALIQUOTA
*/ 
CREATE TABLE CONTAS
(
	COD_CONTA			TIPO_CODIGO		IDENTITY,
	VALOR				NUMERIC(10,2),
	QTD_PARCELAS		TIPO_PRAZO,
	PORC_MULTA			TIPO_ALIQUOTA
	CONSTRAINT PK_CONTAS PRIMARY KEY (COD_CONTA)
)


