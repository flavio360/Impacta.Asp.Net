-- USANDO IDENTITY
-- 0. Criar banco de dados chamado EXERC_IDENTITY e coloc�-lo em uso
CREATE DATABASE EXERC_IDENTITY
GO
USE EXERC_IDENTITY
-- 1. Criar a tabela PESSOAS
/*
	PESSOAS
	
	Obs.: A numera��o do campo c�digo precisa iniciar em 10
	
	COD_PESSOA			INT		autonumera��o		chave prim�ria
	NOME				VARCHAR(30)
	ENDERECO			VARCHAR(50)
	SEXO				CHAR(1)
	------------------------------------------------------------------------
*/



-- 2. Insira 5 registros na tabela PESSOAS


-- Listar a tabela PESSOAS



-- 3. Apague os registros da tabela PESSOAS com c�digo 11 e 13


-- Listar a tabela PESSOAS


-- 4. Na tabela PESSOAS, insira os seguintes registros nos c�digos 11 e 13
    /*
       CODIGO		NOME				ENDERECO			SEXO
       11			PEDRO DE OLIVEIRA	AV. PAULISTA, 1009	M
       13			MARIA LUIZA			AV. PAULISTA, 1009	F
    */ 





-- Listar a tabela PESSOAS


-- 5. Alterar o contador de IDENTITY da tabela PESSOAS de modo que o pr�ximo INSERT.
--    gere o c�digo 100


-- 6. Insira mais 2 linhas na tabela PESSOAS 

-- 7. Consultar a tabela PESSOAS

-- USANDO SEQUENCE ----------------------------------------
DROP TABLE PESSOAS
-- 1. Criar a tabela PESSOAS
/*
	PESSOAS
	
	Obs.: A numera��o do campo c�digo precisa iniciar em 10
	
	COD_PESSOA			INT		chave prim�ria
	NOME				VARCHAR(30)
	ENDERECO			VARCHAR(50)
	SEXO				CHAR(1)
	------------------------------------------------------------------------
*/


-- 2. Insira 5 registros na tabela PESSOAS


-- Listar a tabela PESSOAS

-- 3. Apague os registros da tabela PESSOAS com c�digo 11 e 13

-- Listar a tabela PESSOAS

-- 4. Na tabela PESSOAS, insira os seguintes registros nos c�digos 11 e 13
    /*
       CODIGO		NOME				ENDERECO			SEXO
       11			PEDRO DE OLIVEIRA	AV. PAULISTA, 1009	M
       13			MARIA LUIZA			AV. PAULISTA, 1009	F
    */ 


-- 5. Alterar o contador da SEQUENCE de modo que o pr�ximo INSERT.
--    gere o c�digo 100

--     Insira mais 2 linhas na tabela PESSOAS 

--
SELECT * FROM PESSOAS
